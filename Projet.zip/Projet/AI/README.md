# Projet G1/G2 - Module IA Grok

Ce dossier contient le module IA du projet. Il lit la base nettoyee produite par CLEAN, puis utilise Grok API pour enrichir les entreprises avec des informations metier normalisees.

```text
DATA
-> CLEAN
-> IA Grok
-> companies_enriched + evidence
```

## Role du module IA

DATA collecte et structure les sources.

CLEAN construit un texte propre:

```text
ai_clean_text
```

IA lit ce texte et produit:

- secteur industriel;
- sous-secteur;
- domaine de production;
- position dans la chaine de valeur;
- produits et services;
- technologies;
- competences cles;
- parc machine;
- certifications;
- clients;
- marches;
- potentiel d'interet;
- niveau de priorite;
- justification;
- evidence textuelle.

## Entree recommandee

La base actuelle a utiliser est:

```text
Clean\output_clean_1000_latest\entreprises_clean.db
```

Cette base contient 1000 lignes:

- `ai_clean_text`: 1000/1000;
- `ai_cleaning_status = ok`: 998;
- `weak_text`: 2.

Le script conserve toutes les entreprises dans la sortie. Par defaut, les lignes `weak_text` ne sont pas envoyees a Grok pour eviter une analyse peu fiable; elles sont conservees avec un statut explicite `skipped_weak_input`. Si on veut quand meme les envoyer au modele, il faut ajouter `--process-weak`.

## Fichiers principaux

```text
AI/
  pipeline_ai_grok.py        script principal IA
  prompts/prompt_grok.md     prompt de reference
  schemas/schema_sortie_ia.json
  requirements.txt
  README.md
  README_CN.md
```

## Cle API

La cle Grok ne doit pas etre ecrite dans le code ni dans les fichiers du projet.

Sous PowerShell:

```powershell
[Environment]::SetEnvironmentVariable("XAI_API_KEY", "votre_cle", "User")
```

Fermer puis rouvrir le terminal si la variable n'est pas visible tout de suite.

Verification:

```powershell
[Environment]::GetEnvironmentVariable("XAI_API_KEY", "User")
```

## Tester sans consommer l'API

Pour verifier le pipeline sans appeler Grok:

```powershell
python AI\pipeline_ai_grok.py `
  --input-db "Clean\output_clean_1000_latest\entreprises_clean.db" `
  --output "AI\outputs_grok_dry_run_1000" `
  --limit 1000 `
  --dry-run `
  --overwrite
```

Le mode `--dry-run` ne fait pas d'analyse reelle. Il sert seulement a verifier que la base CLEAN est lisible et que les exports IA sont bien crees.

## Lancer avec Grok API

Pour traiter les 1000 lignes actuelles:

```powershell
python AI\pipeline_ai_grok.py `
  --input-db "Clean\output_clean_1000_latest\entreprises_clean.db" `
  --output "AI\outputs_grok_1000_latest" `
  --limit 1000 `
  --model "grok-4.3" `
  --reasoning-effort "none" `
  --overwrite
```

Par defaut:

- modele: `grok-4.3`;
- reasoning: `none`;
- temperature: `0`;
- texte maximum envoye par entreprise: 9000 caracteres;
- score minimum d'entree: 40.

Le modele peut etre change avec `--model` si le client demande un autre modele Grok non reasoning.

## Reprendre un run

Si le traitement est interrompu:

```powershell
python AI\pipeline_ai_grok.py `
  --input-db "Clean\output_clean_1000_latest\entreprises_clean.db" `
  --output "AI\outputs_grok_1000_latest" `
  --resume
```

`--resume` garde les lignes deja traitees et continue les suivantes.

## Traiter par blocs

Premier bloc:

```powershell
python AI\pipeline_ai_grok.py `
  --input-db "Clean\output_clean_1000_latest\entreprises_clean.db" `
  --output "AI\outputs_grok_1_500" `
  --start 1 `
  --limit 500 `
  --model "grok-4.3" `
  --reasoning-effort "none" `
  --overwrite
```

Deuxieme bloc:

```powershell
python AI\pipeline_ai_grok.py `
  --input-db "Clean\output_clean_1000_latest\entreprises_clean.db" `
  --output "AI\outputs_grok_501_1000" `
  --start 501 `
  --limit 500 `
  --model "grok-4.3" `
  --reasoning-effort "none" `
  --overwrite
```

## Sorties generees

Chaque run produit:

- `ia_results.db`: base SQLite IA;
- `companies_enriched.csv`;
- `companies_enriched.xlsx`;
- `evidence.csv`;
- `evidence.xlsx`;
- `run_report.md`;
- `logs/progress.jsonl`;
- `logs/errors.jsonl`.

## companies_enriched

Ce fichier contient une ligne par entreprise. Il conserve les champs utiles de CLEAN, puis ajoute les champs IA:

- `secteur_ia`;
- `sous_secteur_ia`;
- `domaine_production`;
- `chaine_valeur`;
- `produits_services`;
- `technologies`;
- `competences_cles`;
- `parc_machine`;
- `certifications_normes`;
- `clients`;
- `marches`;
- `potentiel_interet`;
- `niveau_priorite`;
- `justification_priorite`;
- `confidence`;
- `statut_ia`;
- `evidence_resume`.

## evidence

Ce fichier contient les preuves textuelles associees aux champs IA. Il sert a expliquer pourquoi le modele a produit une classification ou une extraction.

## Important

Le module IA ne doit pas inventer les informations absentes du texte. Si une information n'existe pas dans `ai_clean_text`, elle doit rester vide, `inconnu`, ou etre signalee avec une faible confiance.
