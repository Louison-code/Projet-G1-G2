# Projet G1/G2 - IA Grok 模块说明

这个文件夹是项目的 IA 部分。它读取 CLEAN 生成的清洗数据库，然后调用 Grok API，对企业进行业务增强分析。

```text
DATA
-> CLEAN
-> IA Grok
-> companies_enriched + evidence
```

## IA 模块的作用

DATA 负责抓取和结构化来源数据。

CLEAN 负责生成干净文本：

```text
ai_clean_text
```

IA 读取 `ai_clean_text`，输出：

- 行业；
- 子行业；
- 生产/业务领域；
- 产业链位置；
- 产品和服务；
- 技术方向；
- 关键能力；
- 机器设备；
- 认证和标准；
- 客户；
- 市场；
- 对 F-2049 的潜在价值；
- 优先级；
- 判断理由；
- 文字证据。

## 推荐输入

当前应该使用这个 CLEAN 数据库：

```text
Clean\output_clean_1000_latest\entreprises_clean.db
```

这个数据库有 1000 行：

- `ai_clean_text`：1000/1000；
- `ai_cleaning_status = ok`：998；
- `weak_text`：2。

脚本会保留所有企业。默认情况下，`weak_text` 行不会发送给 Grok，因为文本太弱，容易让模型乱猜；但这些行仍然会出现在输出里，状态是 `skipped_weak_input`。如果确实想把弱文本也发给模型，可以加 `--process-weak`。

## 主要文件

```text
AI/
  pipeline_ai_grok.py        IA 主脚本
  prompts/prompt_grok.md     prompt 参考
  schemas/schema_sortie_ia.json
  requirements.txt
  README.md
  README_CN.md
```

## API Key

不要把 Grok API key 写进代码或 README。

PowerShell 中设置：

```powershell
[Environment]::SetEnvironmentVariable("XAI_API_KEY", "你的key", "User")
```

如果当前终端读不到，关闭 PowerShell 再重新打开。

检查：

```powershell
[Environment]::GetEnvironmentVariable("XAI_API_KEY", "User")
```

## 不消耗 API 的测试

只测试流程，不调用 Grok：

```powershell
python AI\pipeline_ai_grok.py `
  --input-db "Clean\output_clean_1000_latest\entreprises_clean.db" `
  --output "AI\outputs_grok_dry_run_1000" `
  --limit 1000 `
  --dry-run `
  --overwrite
```

`--dry-run` 不会产生真实 AI 分析结果，只用于确认 CLEAN 数据库可读、IA 输出文件能正常生成。

## 调用 Grok API

处理当前 1000 条：

```powershell
python AI\pipeline_ai_grok.py `
  --input-db "Clean\output_clean_1000_latest\entreprises_clean.db" `
  --output "AI\outputs_grok_1000_latest" `
  --limit 1000 `
  --model "grok-4.3" `
  --reasoning-effort "none" `
  --overwrite
```

默认设置：

- 模型：`grok-4.3`;
- reasoning：`none`;
- temperature：`0`;
- 每家公司最多发送 9000 字符；
- 最低输入质量分：40。

如果客户要求其他 Grok non reasoning 模型，可以用 `--model` 修改。

## 中断后继续

如果运行中断：

```powershell
python AI\pipeline_ai_grok.py `
  --input-db "Clean\output_clean_1000_latest\entreprises_clean.db" `
  --output "AI\outputs_grok_1000_latest" `
  --resume
```

`--resume` 会跳过已经处理过的企业，继续后面的。

## 分批运行

前 500 条：

```powershell
python AI\pipeline_ai_grok.py `
  --input-db "Clean\output_clean_1000_latest\entreprises_clean.db" `
  --output "AI\outputs_grok_1_500" `
  --start 1 `
  --limit 500 `
  --model "grok-4.3" `
  --reasoning-effort "none" `
  --overwrite
```

第 501 到 1000 条：

```powershell
python AI\pipeline_ai_grok.py `
  --input-db "Clean\output_clean_1000_latest\entreprises_clean.db" `
  --output "AI\outputs_grok_501_1000" `
  --start 501 `
  --limit 500 `
  --model "grok-4.3" `
  --reasoning-effort "none" `
  --overwrite
```

## 输出文件

每次运行生成：

- `ia_results.db`：IA 结果数据库；
- `companies_enriched.csv`;
- `companies_enriched.xlsx`;
- `evidence.csv`;
- `evidence.xlsx`;
- `run_report.md`;
- `logs/progress.jsonl`;
- `logs/errors.jsonl`。

## companies_enriched

这个文件一家公司一行。它保留 CLEAN 的有用字段，并追加 IA 生成字段：

- `secteur_ia`;
- `sous_secteur_ia`;
- `domaine_production`;
- `chaine_valeur`;
- `produits_services`;
- `technologies`;
- `competences_cles`;
- `parc_machine`;
- `certifications_normes`;
- `clients`;
- `marches`;
- `potentiel_interet`;
- `niveau_priorite`;
- `justification_priorite`;
- `confidence`;
- `statut_ia`;
- `evidence_resume`。

## evidence

这个文件保存 IA 判断用到的文字证据，用来解释为什么模型给出了某个分类或提取结果。

## 注意

IA 不能编造文本里没有的信息。如果 `ai_clean_text` 里没有某个信息，输出应该为空、`inconnu`，或者给低置信度。
