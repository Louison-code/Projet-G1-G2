# Rapport IA Grok

- Base d'entree: `C:\Users\Dou\Desktop\Projet\Clean\output_clean_1000_latest\entreprises_clean.db`
- Table lue: `companies_raw`
- Sortie: `C:\Users\Dou\Desktop\Projet\AI\outputs_grok_api_test_1`
- Modele: `grok-4.3`
- Fournisseur API: `xAI / Grok`
- Lignes selectionnees: 1
- Entreprises exportees: 1
- Lignes evidence exportees: 1
- Duree totale: 25.42 s
- Start: 1
- Limit: 1
- Score minimum envoye au modele: 40.0
- Texte maximum envoye au modele: 9000 caracteres

## Statuts IA

- error_api: 1

## Lecture des statuts

- `ok`: appel Grok reussi et JSON exploitable.
- `skipped_weak_input`: entreprise conservee mais non envoyee au modele car le texte nettoye est trop faible.
- `dry_run`: test sans appel API.
- `error_api`: appel API ou parsing JSON en erreur; la ligne reste conservee.

La cle API n'est pas stockee dans les fichiers du projet.