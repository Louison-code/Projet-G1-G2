"""
Pipeline IA Grok pour le projet G1/G2.

Entree:
- une base SQLite produite par l'etape CLEAN

Sorties:
- companies_enriched.csv / .xlsx
- evidence.csv / .xlsx
- ia_results.db
- run_report.md
- logs/progress.jsonl
- logs/errors.jsonl

La cle API n'est jamais stockee dans les fichiers du projet.
Le script lit uniquement la variable d'environnement XAI_API_KEY.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import shutil
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


BASE_FIELDS = [
    "input_id",
    "company_name",
    "site_activity_text",
    "kompass_activity_text",
    "kompass_activities_main_text",
    "kompass_activities_secondary_text",
    "business_text",
    "ai_clean_text",
    "siren",
    "siret",
    "naf_code",
    "legal_form",
    "effectifs",
    "capital",
    "address",
    "postal_code",
    "city",
    "country",
    "emails",
    "phones",
    "fax",
    "website_detected",
    "source_url",
    "domain",
    "source_page_type",
    "scrape_status",
    "site_status",
    "kompass_status",
    "pages_ok",
    "pages_error",
    "pages_blocked_robots",
    "fetched_at",
    "ai_cleaning_status",
    "ai_input_quality_score",
    "ai_cleaning_notes",
    "ai_source_fields",
    "ai_clean_text_hash",
]

IA_FIELDS = [
    "secteur_ia",
    "sous_secteur_ia",
    "domaine_production",
    "chaine_valeur",
    "produits_services",
    "technologies",
    "competences_cles",
    "parc_machine",
    "certifications_normes",
    "clients",
    "marches",
    "potentiel_interet",
    "niveau_priorite",
    "justification_priorite",
    "confidence",
    "statut_ia",
    "evidence_resume",
]

TECH_FIELDS = [
    "texte_ia_chars",
    "texte_ia_tronque",
    "modele_ia",
    "api_provider",
    "reasoning_effort",
    "date_traitement_ia",
    "duree_traitement_s",
    "prompt_chars",
    "output_chars",
    "erreur_ia",
]

COMPANY_FIELDS = BASE_FIELDS + IA_FIELDS + TECH_FIELDS

EVIDENCE_FIELDS = [
    "input_id",
    "company_name",
    "champ",
    "valeur_ia",
    "evidence_text",
    "source_url",
    "confidence",
]

LIST_FIELDS = {
    "produits_services",
    "technologies",
    "competences_cles",
    "parc_machine",
    "certifications_normes",
    "clients",
    "marches",
}

OUTPUT_JSON_FIELDS = [
    "secteur_ia",
    "sous_secteur_ia",
    "domaine_production",
    "chaine_valeur",
    "produits_services",
    "technologies",
    "competences_cles",
    "parc_machine",
    "certifications_normes",
    "clients",
    "marches",
    "potentiel_interet",
    "niveau_priorite",
    "justification_priorite",
    "confidence",
    "evidence_resume",
    "evidences",
]

TABLE_CANDIDATES = [
    "companies_clean",
    "entreprises_clean",
    "companies_raw",
    "entreprises",
    "companies",
]


def utc_now() -> str:
    """Retourne une date UTC ISO lisible."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def read_api_key(env_name: str) -> str:
    """Lit la cle API sans jamais l'ecrire dans les sorties."""
    value = os.environ.get(env_name, "").strip()
    if value:
        return value
    if os.name != "nt":
        return ""
    try:
        import winreg

        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
            user_value, _ = winreg.QueryValueEx(key, env_name)
        return str(user_value).strip()
    except OSError:
        return ""


def clean_text(value: Any) -> str:
    """Nettoie une valeur pour les exports."""
    if value is None:
        return ""
    text = str(value).replace("\x00", " ")
    text = re.sub(r"[\x01-\x08\x0b\x0c\x0e-\x1f]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def to_float(value: Any, default: float = 0.0) -> float:
    """Convertit une valeur en float robuste."""
    try:
        if value is None or str(value).strip() == "":
            return default
        return float(str(value).replace(",", "."))
    except (TypeError, ValueError):
        return default


def normalize_confidence(value: Any) -> float:
    """Force la confidence dans l'intervalle 0-1."""
    score = to_float(value, 0.0)
    if score > 1:
        score = score / 100
    return max(0.0, min(1.0, score))


def normalize_list(value: Any) -> str:
    """Transforme une liste JSON ou un texte en valeur CSV stable."""
    if value is None:
        return ""
    if isinstance(value, list):
        items = [clean_text(item) for item in value if clean_text(item)]
        return "; ".join(dict.fromkeys(items))
    if isinstance(value, dict):
        return clean_text(json.dumps(value, ensure_ascii=False))
    return clean_text(value)


def detect_table(conn: sqlite3.Connection, explicit_table: str = "") -> str:
    """Trouve la table d'entree dans la base CLEAN."""
    if explicit_table:
        return explicit_table
    tables = {
        row[0]
        for row in conn.execute("select name from sqlite_master where type='table'")
    }
    for table in TABLE_CANDIDATES:
        if table in tables:
            return table
    raise ValueError(f"Aucune table d'entree reconnue. Tables trouvees: {sorted(tables)}")


def get_table_columns(conn: sqlite3.Connection, table: str) -> list[str]:
    """Retourne les colonnes d'une table SQLite."""
    return [row[1] for row in conn.execute(f"pragma table_info({table})")]


def read_rows(
    input_db: Path,
    *,
    table: str,
    start: int,
    limit: int,
) -> tuple[list[dict[str, Any]], str]:
    """Lit les lignes selectionnees depuis la base CLEAN."""
    conn = sqlite3.connect(input_db)
    conn.row_factory = sqlite3.Row
    selected_table = detect_table(conn, table)
    offset = max(0, start - 1)
    sql = f"select * from {selected_table} order by rowid limit ? offset ?"
    sql_limit = limit if limit > 0 else -1
    rows = [dict(row) for row in conn.execute(sql, (sql_limit, offset)).fetchall()]
    conn.close()
    return rows, selected_table


def output_db_path(output_dir: Path) -> Path:
    """Retourne le chemin de la base de resultats IA."""
    return output_dir / "ia_results.db"


def ensure_output_db(output_dir: Path) -> sqlite3.Connection:
    """Prepare la base SQLite de sortie."""
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "logs").mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(output_db_path(output_dir))
    conn.execute(
        """
        create table if not exists companies_enriched (
            input_id text primary key,
            payload_json text not null,
            updated_at text not null
        )
        """
    )
    conn.execute(
        """
        create table if not exists evidence (
            id integer primary key autoincrement,
            input_id text not null,
            payload_json text not null,
            created_at text not null
        )
        """
    )
    conn.execute(
        """
        create table if not exists run_events (
            id integer primary key autoincrement,
            input_id text,
            status text not null,
            message text,
            created_at text not null
        )
        """
    )
    conn.commit()
    return conn


def already_processed(conn: sqlite3.Connection) -> set[str]:
    """Retourne les identifiants deja presents dans la sortie."""
    return {
        row[0]
        for row in conn.execute("select input_id from companies_enriched").fetchall()
    }


def save_company(conn: sqlite3.Connection, company: dict[str, Any]) -> None:
    """Sauvegarde une ligne enrichie."""
    conn.execute(
        """
        insert or replace into companies_enriched (input_id, payload_json, updated_at)
        values (?, ?, ?)
        """,
        (
            company["input_id"],
            json.dumps(company, ensure_ascii=False),
            utc_now(),
        ),
    )


def save_evidence_rows(conn: sqlite3.Connection, input_id: str, rows: list[dict[str, Any]]) -> None:
    """Remplace les preuves d'une entreprise."""
    conn.execute("delete from evidence where input_id = ?", (input_id,))
    for row in rows:
        conn.execute(
            "insert into evidence (input_id, payload_json, created_at) values (?, ?, ?)",
            (input_id, json.dumps(row, ensure_ascii=False), utc_now()),
        )


def save_event(conn: sqlite3.Connection, input_id: str, status: str, message: str) -> None:
    """Journalise un evenement d'execution."""
    conn.execute(
        "insert into run_events (input_id, status, message, created_at) values (?, ?, ?, ?)",
        (input_id, status, message, utc_now()),
    )


def base_company(row: dict[str, Any]) -> dict[str, Any]:
    """Construit la partie factuelle issue du scraping/nettoyage."""
    company = {field: clean_text(row.get(field, "")) for field in BASE_FIELDS}
    if not company["input_id"]:
        company["input_id"] = clean_text(row.get("id", "")) or clean_text(row.get("source_url", ""))
    return company


def should_call_api(row: dict[str, Any], args: argparse.Namespace) -> tuple[bool, str]:
    """Decide si une ligne merite un appel API."""
    if args.process_weak:
        return True, ""
    status = clean_text(row.get("ai_cleaning_status")).lower()
    score = to_float(row.get("ai_input_quality_score"), 0.0)
    text = clean_text(row.get("ai_clean_text"))
    if not text:
        return False, "texte_ia_vide"
    if status and status != "ok":
        return False, f"qualite_entree_{status}"
    if score < args.min_quality_score:
        return False, f"score_entree_trop_faible_{score:g}"
    return True, ""


def truncate_text(text: str, max_chars: int) -> tuple[str, bool]:
    """Limite la taille du texte envoye au modele."""
    text = clean_text(text)
    if len(text) <= max_chars:
        return text, False
    return text[:max_chars].rsplit(" ", 1)[0].strip(), True


def build_messages(row: dict[str, Any], args: argparse.Namespace) -> tuple[list[dict[str, str]], int, bool]:
    """Construit le prompt envoye a Grok."""
    clean_input, truncated = truncate_text(row.get("ai_clean_text", ""), args.max_input_chars)
    company_name = clean_text(row.get("company_name"))
    system = (
        "Tu es un analyste industriel pour un projet de reindustrialisation et de relocalisation. "
        "Tu enrichis des fiches entreprises a partir d'un texte nettoye. "
        "Tu ne dois jamais inventer une information absente du texte. "
        "Si une information manque, utilise une chaine vide, une liste vide ou 'inconnu'. "
        "Separe strictement les clients nominatifs et les marches/secteurs vises. "
        "Reponds uniquement avec un objet JSON valide conforme au schema demande."
    )
    user = {
        "mission": "Analyser l'entreprise et produire des champs exploitables pour une base de donnees et un audit technique.",
        "schema_attendu": {
            "secteur_ia": "grande famille sectorielle",
            "sous_secteur_ia": "specialisation plus precise",
            "domaine_production": "type de production ou domaine metier",
            "chaine_valeur": "ex: matieres premieres, composants, fabrication, integration, distribution, services, logiciel, maintenance, conseil, inconnu",
            "produits_services": ["produits ou services identifiables"],
            "technologies": ["technologies, procedes ou outils"],
            "competences_cles": ["savoir-faire et competences"],
            "parc_machine": ["machines, equipements ou moyens industriels"],
            "certifications_normes": ["certifications, normes, labels"],
            "clients": ["noms d'entreprises clientes uniquement"],
            "marches": ["secteurs, applications ou marches vises"],
            "potentiel_interet": "faible, moyen, fort ou inconnu pour F-2049",
            "niveau_priorite": "basse, moyenne, haute ou inconnue",
            "justification_priorite": "raison courte fondee sur le texte",
            "confidence": "nombre entre 0 et 1",
            "evidence_resume": "phrase courte citant les elements textuels utiles",
            "evidences": [
                {
                    "champ": "nom du champ justifie",
                    "valeur": "valeur produite",
                    "evidence_text": "court extrait du texte source",
                }
            ],
        },
        "donnees_entreprise": {
            "input_id": clean_text(row.get("input_id")),
            "company_name": company_name,
            "source_url": clean_text(row.get("source_url")),
            "website_detected": clean_text(row.get("website_detected")),
            "city": clean_text(row.get("city")),
            "country": clean_text(row.get("country")),
            "siren": clean_text(row.get("siren")),
            "siret": clean_text(row.get("siret")),
            "naf_code": clean_text(row.get("naf_code")),
            "legal_form": clean_text(row.get("legal_form")),
            "effectifs": clean_text(row.get("effectifs")),
            "ai_input_quality_score": clean_text(row.get("ai_input_quality_score")),
            "ai_source_fields": clean_text(row.get("ai_source_fields")),
        },
        "texte_nettoye": clean_input,
        "regles": [
            "Ne pas confondre clients et marches.",
            "Ne pas extraire de prix produit sauf si le prix est explicitement present; le schema ne demande pas ce champ.",
            "Ne pas utiliser de connaissances externes.",
            "Ne pas classer avec confiance forte si le texte est pauvre.",
        ],
    }
    user_text = json.dumps(user, ensure_ascii=False)
    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": user_text},
    ]
    return messages, len(user_text), truncated


def grok_payload(messages: list[dict[str, str]], args: argparse.Namespace, *, json_mode: bool) -> dict[str, Any]:
    """Construit la requete API au format OpenAI-compatible de xAI."""
    payload: dict[str, Any] = {
        "model": args.model,
        "messages": messages,
        "temperature": args.temperature,
        "max_tokens": args.max_tokens,
    }
    if args.reasoning_effort:
        payload["reasoning_effort"] = args.reasoning_effort
    if json_mode:
        payload["response_format"] = {"type": "json_object"}
    return payload


def call_grok_api(messages: list[dict[str, str]], args: argparse.Namespace, api_key: str) -> str:
    """Appelle Grok API avec retry simple."""
    last_error = ""
    for attempt in range(args.retries + 1):
        json_mode = not args.disable_json_mode
        for use_json_mode in ([True, False] if json_mode else [False]):
            payload = grok_payload(messages, args, json_mode=use_json_mode)
            request = Request(
                args.api_url,
                data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                method="POST",
            )
            try:
                with urlopen(request, timeout=args.timeout) as response:
                    data = json.loads(response.read().decode("utf-8", errors="replace"))
                return data["choices"][0]["message"]["content"]
            except HTTPError as exc:
                body = exc.read().decode("utf-8", errors="replace")[:1500]
                last_error = f"HTTP {exc.code}: {body}"
                if exc.code == 400 and use_json_mode:
                    continue
            except (URLError, TimeoutError, KeyError, json.JSONDecodeError) as exc:
                last_error = str(exc)
            if attempt < args.retries:
                time.sleep(args.retry_delay * (attempt + 1))
        if attempt < args.retries:
            time.sleep(args.retry_delay * (attempt + 1))
    raise RuntimeError(last_error or "appel_api_echoue")


def extract_json_object(text: str) -> dict[str, Any]:
    """Extrait le premier objet JSON depuis la reponse du modele."""
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?", "", text, flags=re.IGNORECASE).strip()
        text = re.sub(r"```$", "", text).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start >= 0 and end > start:
            return json.loads(text[start : end + 1])
        raise


def normalize_ai_result(raw: dict[str, Any]) -> dict[str, Any]:
    """Stabilise la structure JSON renvoyee par Grok."""
    result: dict[str, Any] = {}
    for field in OUTPUT_JSON_FIELDS:
        value = raw.get(field, [] if field in LIST_FIELDS or field == "evidences" else "")
        if field in LIST_FIELDS:
            result[field] = normalize_list(value)
        elif field == "evidences":
            result[field] = value if isinstance(value, list) else []
        elif field == "confidence":
            result[field] = normalize_confidence(value)
        else:
            result[field] = clean_text(value)
    return result


def skipped_ai_result(reason: str) -> dict[str, Any]:
    """Cree un resultat IA explicite sans appel modele."""
    return {
        "secteur_ia": "inconnu",
        "sous_secteur_ia": "inconnu",
        "domaine_production": "inconnu",
        "chaine_valeur": "inconnu",
        "produits_services": "",
        "technologies": "",
        "competences_cles": "",
        "parc_machine": "",
        "certifications_normes": "",
        "clients": "",
        "marches": "",
        "potentiel_interet": "inconnu",
        "niveau_priorite": "inconnue",
        "justification_priorite": f"Ligne non envoyee au modele: {reason}.",
        "confidence": 0.0,
        "evidence_resume": "Texte d'entree insuffisant pour une analyse fiable.",
        "evidences": [],
    }


def dry_run_ai_result(row: dict[str, Any]) -> dict[str, Any]:
    """Resultat factice pour verifier le pipeline sans consommer l'API."""
    text = clean_text(row.get("ai_clean_text"))
    return {
        "secteur_ia": "dry_run",
        "sous_secteur_ia": "dry_run",
        "domaine_production": "dry_run",
        "chaine_valeur": "dry_run",
        "produits_services": "",
        "technologies": "",
        "competences_cles": "",
        "parc_machine": "",
        "certifications_normes": "",
        "clients": "",
        "marches": "",
        "potentiel_interet": "inconnu",
        "niveau_priorite": "inconnue",
        "justification_priorite": "Mode dry-run: aucun appel API.",
        "confidence": 0.0,
        "evidence_resume": text[:250],
        "evidences": [],
    }


def evidence_rows(company: dict[str, Any], result: dict[str, Any]) -> list[dict[str, Any]]:
    """Transforme les preuves JSON en table plate."""
    evidences = result.get("evidences", [])
    rows: list[dict[str, Any]] = []
    if isinstance(evidences, list):
        for item in evidences:
            if not isinstance(item, dict):
                continue
            rows.append(
                {
                    "input_id": company["input_id"],
                    "company_name": company["company_name"],
                    "champ": clean_text(item.get("champ")),
                    "valeur_ia": clean_text(item.get("valeur")),
                    "evidence_text": clean_text(item.get("evidence_text")),
                    "source_url": company.get("source_url", ""),
                    "confidence": company.get("confidence", 0.0),
                }
            )
    if not rows and clean_text(company.get("evidence_resume")):
        rows.append(
            {
                "input_id": company["input_id"],
                "company_name": company["company_name"],
                "champ": "evidence_resume",
                "valeur_ia": clean_text(company.get("evidence_resume")),
                "evidence_text": clean_text(company.get("evidence_resume")),
                "source_url": company.get("source_url", ""),
                "confidence": company.get("confidence", 0.0),
            }
        )
    return rows


def build_company_output(
    row: dict[str, Any],
    result: dict[str, Any],
    *,
    status: str,
    model: str,
    provider: str,
    reasoning_effort: str,
    duration: float,
    prompt_chars: int,
    output_chars: int,
    truncated: bool,
    error: str,
) -> dict[str, Any]:
    """Fusionne donnees factuelles et resultat IA."""
    company = base_company(row)
    for field in IA_FIELDS:
        if field == "statut_ia":
            company[field] = status
        elif field == "confidence":
            company[field] = normalize_confidence(result.get(field))
        else:
            company[field] = normalize_list(result.get(field)) if field in LIST_FIELDS else clean_text(result.get(field, ""))
    company.update(
        {
            "texte_ia_chars": len(clean_text(row.get("ai_clean_text"))),
            "texte_ia_tronque": "true" if truncated else "false",
            "modele_ia": model,
            "api_provider": provider,
            "reasoning_effort": reasoning_effort,
            "date_traitement_ia": utc_now(),
            "duree_traitement_s": round(duration, 3),
            "prompt_chars": prompt_chars,
            "output_chars": output_chars,
            "erreur_ia": error,
        }
    )
    return company


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    """Ajoute une ligne JSONL."""
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False) + "\n")


def export_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    """Exporte une liste de dictionnaires en CSV."""
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def export_xlsx(path: Path, rows: list[dict[str, Any]], fields: list[str], sheet_name: str) -> None:
    """Exporte en XLSX si openpyxl est disponible."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill
    except ImportError:
        return
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = sheet_name
    sheet.append(fields)
    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    for cell in sheet[1]:
        cell.fill = header_fill
        cell.font = header_font
    for row in rows:
        sheet.append([row.get(field, "") for field in fields])
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions
    for column_cells in sheet.columns:
        header = str(column_cells[0].value or "")
        width = min(max(len(header) + 2, 12), 42)
        sheet.column_dimensions[column_cells[0].column_letter].width = width
    workbook.save(path)


def load_output_rows(conn: sqlite3.Connection) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Recharge les resultats depuis SQLite pour exporter proprement."""
    companies = [
        json.loads(row[0])
        for row in conn.execute("select payload_json from companies_enriched order by input_id").fetchall()
    ]
    evidences = [
        json.loads(row[0])
        for row in conn.execute("select payload_json from evidence order by input_id, id").fetchall()
    ]
    return companies, evidences


def write_exports(output_dir: Path, conn: sqlite3.Connection) -> tuple[int, int]:
    """Ecrit CSV et XLSX depuis la base de sortie."""
    companies, evidences = load_output_rows(conn)
    export_csv(output_dir / "companies_enriched.csv", companies, COMPANY_FIELDS)
    export_csv(output_dir / "evidence.csv", evidences, EVIDENCE_FIELDS)
    export_xlsx(output_dir / "companies_enriched.xlsx", companies, COMPANY_FIELDS, "companies_enriched")
    export_xlsx(output_dir / "evidence.xlsx", evidences, EVIDENCE_FIELDS, "evidence")
    return len(companies), len(evidences)


def write_report(
    output_dir: Path,
    *,
    input_db: Path,
    table: str,
    selected_rows: int,
    exported_companies: int,
    exported_evidences: int,
    stats: dict[str, int],
    started_at: float,
    args: argparse.Namespace,
) -> None:
    """Genere un rapport simple de performance."""
    duration = time.perf_counter() - started_at
    lines = [
        "# Rapport IA Grok",
        "",
        f"- Base d'entree: `{input_db}`",
        f"- Table lue: `{table}`",
        f"- Sortie: `{output_dir}`",
        f"- Modele: `{args.model}`",
        f"- Fournisseur API: `xAI / Grok`",
        f"- Lignes selectionnees: {selected_rows}",
        f"- Entreprises exportees: {exported_companies}",
        f"- Lignes evidence exportees: {exported_evidences}",
        f"- Duree totale: {duration:.2f} s",
        f"- Start: {args.start}",
        f"- Limit: {args.limit}",
        f"- Score minimum envoye au modele: {args.min_quality_score}",
        f"- Texte maximum envoye au modele: {args.max_input_chars} caracteres",
        "",
        "## Statuts IA",
        "",
    ]
    for key in sorted(stats):
        lines.append(f"- {key}: {stats[key]}")
    lines.extend(
        [
            "",
            "## Lecture des statuts",
            "",
            "- `ok`: appel Grok reussi et JSON exploitable.",
            "- `skipped_weak_input`: entreprise conservee mais non envoyee au modele car le texte nettoye est trop faible.",
            "- `dry_run`: test sans appel API.",
            "- `error_api`: appel API ou parsing JSON en erreur; la ligne reste conservee.",
            "",
            "La cle API n'est pas stockee dans les fichiers du projet.",
        ]
    )
    (output_dir / "run_report.md").write_text("\n".join(lines), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    """Parse les arguments CLI."""
    parser = argparse.ArgumentParser(description="Pipeline IA Grok pour enrichir les entreprises nettoyees")
    parser.add_argument("--input-db", required=True, help="Base SQLite produite par CLEAN")
    parser.add_argument("--table", default="", help="Nom de table optionnel. Sinon detection automatique.")
    parser.add_argument("--output", default=r"AI\outputs_grok", help="Dossier de sortie IA")
    parser.add_argument("--start", type=int, default=1, help="Index 1-base de depart")
    parser.add_argument("--limit", type=int, default=0, help="Nombre de lignes a traiter. 0 = toutes")
    parser.add_argument("--resume", action="store_true", help="Reprendre en ignorant les input_id deja traites")
    parser.add_argument("--overwrite", action="store_true", help="Supprimer la sortie existante avant traitement")
    parser.add_argument("--dry-run", action="store_true", help="Tester sans appeler Grok API")
    parser.add_argument("--process-weak", action="store_true", help="Envoyer aussi les lignes weak_text au modele")
    parser.add_argument("--min-quality-score", type=float, default=40.0, help="Score minimum pour appeler Grok")
    parser.add_argument("--max-input-chars", type=int, default=9000, help="Taille maximum du texte envoye au modele")
    parser.add_argument("--api-key-env", default="XAI_API_KEY", help="Nom de la variable d'environnement contenant la cle API")
    parser.add_argument("--api-url", default="https://api.x.ai/v1/chat/completions", help="Endpoint Grok API")
    parser.add_argument("--model", default="grok-4.3", help="Modele Grok non reasoning a utiliser")
    parser.add_argument(
        "--reasoning-effort",
        default="none",
        choices=["none", "low", "medium", "high"],
        help="Effort de reasoning pour Grok 4.3. Par defaut: none pour respecter le mode non reasoning.",
    )
    parser.add_argument("--temperature", type=float, default=0.0, help="Temperature modele")
    parser.add_argument("--max-tokens", type=int, default=1400, help="Nombre maximum de tokens de sortie")
    parser.add_argument("--timeout", type=int, default=90, help="Timeout API en secondes")
    parser.add_argument("--retries", type=int, default=2, help="Nombre de retries API")
    parser.add_argument("--retry-delay", type=float, default=4.0, help="Delai entre retries")
    parser.add_argument("--sleep", type=float, default=0.1, help="Pause entre deux entreprises")
    parser.add_argument("--disable-json-mode", action="store_true", help="Ne pas envoyer response_format=json_object")
    return parser.parse_args()


def main() -> int:
    """Point d'entree CLI."""
    args = parse_args()
    if args.start < 1:
        raise ValueError("--start doit etre superieur ou egal a 1")
    input_db = Path(args.input_db).resolve()
    output_dir = Path(args.output).resolve()
    if not input_db.exists():
        raise FileNotFoundError(f"Base d'entree introuvable: {input_db}")
    if args.overwrite and output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "logs").mkdir(parents=True, exist_ok=True)

    rows, table = read_rows(input_db, table=args.table, start=args.start, limit=args.limit)
    conn = ensure_output_db(output_dir)
    processed_ids = already_processed(conn) if args.resume else set()
    api_key = read_api_key(args.api_key_env)
    if not args.dry_run and not api_key:
        raise RuntimeError(
            f"Variable d'environnement manquante: {args.api_key_env}. "
            "Definissez la cle Grok avant de lancer le traitement."
        )
    progress_path = output_dir / "logs" / "progress.jsonl"
    errors_path = output_dir / "logs" / "errors.jsonl"
    stats: dict[str, int] = {}
    started = time.perf_counter()

    print("Projet G1/G2 - Enrichissement IA Grok")
    print(f"Base CLEAN: {input_db}")
    print(f"Table: {table}")
    print(f"Sortie: {output_dir}")
    print(f"Lignes selectionnees: {len(rows)}")
    print(f"Modele: {args.model}")
    print(f"Dry-run: {args.dry_run}")

    for index, row in enumerate(rows, start=1):
        row_start = time.perf_counter()
        input_id = clean_text(row.get("input_id")) or f"ROW_{args.start + index - 1:06d}"
        row["input_id"] = input_id
        if input_id in processed_ids:
            stats["resume_skipped"] = stats.get("resume_skipped", 0) + 1
            continue

        messages, prompt_chars, truncated = build_messages(row, args)
        output_chars = 0
        error = ""
        can_call, skip_reason = should_call_api(row, args)
        status = "ok"

        try:
            if args.dry_run:
                result = dry_run_ai_result(row)
                status = "dry_run"
            elif not can_call:
                result = skipped_ai_result(skip_reason)
                status = "skipped_weak_input"
            else:
                if not api_key:
                    raise RuntimeError(f"Variable d'environnement manquante: {args.api_key_env}")
                raw_answer = call_grok_api(messages, args, api_key)
                output_chars = len(raw_answer)
                result = normalize_ai_result(extract_json_object(raw_answer))
                status = "ok"
        except Exception as exc:  # noqa: BLE001 - journalisation robuste pour audit
            error = clean_text(exc)
            result = skipped_ai_result(f"erreur_api: {error}")
            status = "error_api"
            append_jsonl(errors_path, {"input_id": input_id, "error": error, "created_at": utc_now()})

        duration = time.perf_counter() - row_start
        company = build_company_output(
            row,
            result,
            status=status,
            model=args.model,
            provider="xAI Grok",
            reasoning_effort=args.reasoning_effort,
            duration=duration,
            prompt_chars=prompt_chars,
            output_chars=output_chars,
            truncated=truncated,
            error=error,
        )
        rows_evidence = evidence_rows(company, result)
        save_company(conn, company)
        save_evidence_rows(conn, input_id, rows_evidence)
        save_event(conn, input_id, status, error)
        conn.commit()
        stats[status] = stats.get(status, 0) + 1
        append_jsonl(
            progress_path,
            {
                "index": index,
                "input_id": input_id,
                "status": status,
                "duration_s": round(duration, 3),
                "created_at": utc_now(),
            },
        )
        if index % 10 == 0 or index == len(rows):
            print(f"[{index}/{len(rows)}] dernier statut={status}")
        if args.sleep > 0 and not args.dry_run:
            time.sleep(args.sleep)

    exported_companies, exported_evidences = write_exports(output_dir, conn)
    write_report(
        output_dir,
        input_db=input_db,
        table=table,
        selected_rows=len(rows),
        exported_companies=exported_companies,
        exported_evidences=exported_evidences,
        stats=stats,
        started_at=started,
        args=args,
    )
    conn.close()
    print("Termine.")
    print(f"Entreprises exportees: {exported_companies}")
    print(f"Evidence exportees: {exported_evidences}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
