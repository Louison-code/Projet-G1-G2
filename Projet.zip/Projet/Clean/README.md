# Projet G1/G2 - Module CLEAN

Ce dossier contient la couche de nettoyage entre DATA et IA.

CLEAN ne scrape pas le web et ne fait pas de classification. Son role est de transformer les sorties DATA en une entree stable pour le modele IA.

```text
DATA
-> entreprises.db / entreprises.csv / entreprises.xlsx
-> CLEAN
-> ai_clean_text + champs utiles
-> IA
```

## Fichiers principaux

```text
Clean/
  prepare_ai_input.py     script principal de nettoyage
  requirements.txt        dependances Python
  config.json             resume de configuration
  output_.../             resultats de nettoyage
```

Le script peut etre execute avec Python, sans Codex.

## Entrees acceptees

CLEAN peut lire:

- une base SQLite `.db`;
- un CSV `.csv`;
- un Excel `.xlsx`;
- un JSON ou JSONL.

Dans le projet actuel, l'entree recommandee est la base produite par DATA:

```text
Data/output_data_1000_worker8_latest/entreprises.db
```

## Commandes utiles

Depuis le dossier `C:\Users\Dou\Desktop\Projet`:

```bash
python Clean\prepare_ai_input.py --input "Data\output_data_1000_worker8_latest\entreprises.db" --output "Clean\output_clean_1000_latest"
```

Pour traiter une partie du fichier:

```bash
python Clean\prepare_ai_input.py --input "Data\output_data_1000_worker8_latest\entreprises.db" --output "Clean\output_clean_test" --limit 100
```

Pour commencer plus loin:

```bash
python Clean\prepare_ai_input.py --input "Data\output_data_1000_worker8_latest\entreprises.db" --output "Clean\output_clean_part2" --start 501 --limit 500
```

## Sorties generees

Chaque run produit:

- `entreprises_clean.db`: base SQLite nettoyee;
- `entreprises_clean.csv`: export CSV;
- `entreprises_clean.xlsx`: export Excel;
- `clean_report.md`: rapport de nettoyage.

## Champs ajoutes

- `ai_clean_text`: texte propre, structure et pret pour l'IA.
- `ai_input_quality_score`: score de qualite de 0 a 100.
- `ai_cleaning_status`: `ok`, `weak_text` ou `empty`.
- `ai_cleaning_notes`: explication si le texte est faible.
- `ai_source_fields`: colonnes utilisees pour construire le texte IA.
- `ai_clean_text_hash`: empreinte du texte nettoye.
- `clean_pipeline_version`: nom du pipeline de nettoyage.

## Logique de nettoyage

Le script:

1. lit les donnees DATA;
2. reconnait les colonnes importantes meme si leurs noms varient;
3. standardise les champs de base;
4. recupere les textes utiles: `company_description`, `business_text`, textes site officiel, textes Kompass, produits, marches, machines, certifications;
5. reduit les textes trop longs;
6. baisse la priorite des textes de bruit: cookies, menus, mentions legales, recrutement, pages vides, redirections;
7. conserve les phrases les plus utiles pour comprendre l'activite de l'entreprise;
8. construit `ai_clean_text`;
9. attribue un score de qualite.

Le texte client `ACTIVTE` est deja integre par DATA dans `company_description` et `business_text`. CLEAN l'utilise donc automatiquement. Une entreprise peut rester exploitable pour l'IA meme si le site web ou Kompass n'a pas ete collecte, si le texte metier fourni en entree est suffisant.

## Resultat du dernier test

Dernier run CLEAN:

```text
Clean/output_clean_1000_latest
```

Resultats:

- 1000 lignes traitees;
- `ai_clean_text`: 1000/1000;
- `ai_cleaning_status = ok`: 998;
- `weak_text`: 2;
- score moyen: environ 91.9/100;
- duree observee: environ 37 s.

## Role du module CLEAN

CLEAN fait le lien entre DATA et IA. Il ne remplace pas DATA, car il ne garde pas toutes les preuves brutes. Il ne remplace pas IA, car il ne decide pas du secteur ou de la chaine de valeur. Son role est de fournir au modele un texte court, propre et exploitable.
