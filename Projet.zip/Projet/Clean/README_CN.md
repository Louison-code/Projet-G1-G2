# Projet G1/G2 - CLEAN 模块说明

这个文件夹是 DATA 和 IA 之间的清洗层。

CLEAN 不抓网页，也不做行业分类。它的作用是把 DATA 生成的数据整理成 AI 可以稳定读取的输入。

```text
DATA
-> entreprises.db / entreprises.csv / entreprises.xlsx
-> CLEAN
-> ai_clean_text + 有用字段
-> IA
```

## 主要文件

```text
Clean/
  prepare_ai_input.py     清洗主脚本
  requirements.txt        Python 依赖
  config.json             配置说明
  output_.../             清洗结果
```

这个脚本可以直接用 Python 运行，不需要 Codex。

## 支持的输入

CLEAN 可以读取：

- SQLite 数据库 `.db`;
- CSV 文件 `.csv`;
- Excel 文件 `.xlsx`;
- JSON 或 JSONL。

当前项目推荐输入 DATA 生成的数据库：

```text
Data/output_data_1000_worker8_latest/entreprises.db
```

## 常用命令

在 `C:\Users\Dou\Desktop\Projet` 中运行：

```bash
python Clean\prepare_ai_input.py --input "Data\output_data_1000_worker8_latest\entreprises.db" --output "Clean\output_clean_1000_latest"
```

如果只清洗一部分：

```bash
python Clean\prepare_ai_input.py --input "Data\output_data_1000_worker8_latest\entreprises.db" --output "Clean\output_clean_test" --limit 100
```

如果从中间开始：

```bash
python Clean\prepare_ai_input.py --input "Data\output_data_1000_worker8_latest\entreprises.db" --output "Clean\output_clean_part2" --start 501 --limit 500
```

## 输出文件

每次运行会生成：

- `entreprises_clean.db`：清洗后的 SQLite 数据库；
- `entreprises_clean.csv`：CSV 导出；
- `entreprises_clean.xlsx`：Excel 导出；
- `clean_report.md`：清洗报告。

## 新增字段

- `ai_clean_text`：整理后给 AI 阅读的文本。
- `ai_input_quality_score`：输入质量分，0 到 100。
- `ai_cleaning_status`：`ok`、`weak_text` 或 `empty`。
- `ai_cleaning_notes`：如果文本质量弱，这里说明原因。
- `ai_source_fields`：说明 `ai_clean_text` 来自哪些字段。
- `ai_clean_text_hash`：清洗文本的指纹，用于追踪。
- `clean_pipeline_version`：清洗管道名称。

## 清洗逻辑

脚本会：

1. 读取 DATA 输出；
2. 识别关键列，即使列名不完全一样也尽量兼容；
3. 标准化基础字段；
4. 读取有用文本，比如 `company_description`、`business_text`、官网文本、Kompass 文本、产品、市场、机器设备、认证；
5. 压缩过长文本；
6. 降低噪声文本优先级，比如 cookie、菜单、法律声明、招聘页、空页面、跳转提示；
7. 保留最能说明企业业务的句子；
8. 生成 `ai_clean_text`；
9. 计算质量分。

客户原始字段 `ACTIVTE` 已经在 DATA 中整合进 `company_description` 和 `business_text`。所以 CLEAN 会自动使用这部分信息。即使官网或 Kompass 没抓成功，只要输入里有足够业务描述，这家公司仍然可以给 AI 分析。

## 最近一次测试结果

最新 CLEAN 输出目录：

```text
Clean/output_clean_1000_latest
```

结果：

- 1000 行已清洗；
- `ai_clean_text`：1000/1000；
- `ai_cleaning_status = ok`：998；
- `weak_text`：2；
- 平均质量分约 91.9/100；
- 运行时间约 37 秒。

## CLEAN 的角色

CLEAN 是 DATA 和 IA 中间的桥。它不替代 DATA，因为它不保存所有原始证据。它也不替代 IA，因为它不判断行业、产业链和优先级。它只负责把输入文本整理到 AI 更容易稳定处理的状态。
