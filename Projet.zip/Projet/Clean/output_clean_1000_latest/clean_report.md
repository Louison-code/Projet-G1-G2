# Rapport CLEAN

- Date: 2026-06-14T04:55:36+00:00
- Entree: `C:\Users\Dou\Desktop\Projet\Data\output_data_1000_worker8_latest\entreprises.db`
- Format detecte: `sqlite`
- Table/feuille/source: `companies_raw`
- Sortie: `C:\Users\Dou\Desktop\Projet\Clean\output_clean_1000_latest`
- Lignes traitees: 1000
- Lignes avec texte IA nettoye: 1000
- Lignes faibles: 2
- Lignes vides: 0
- Score qualite moyen: 91.92
- Colonnes source lues: 57
- Champs source utilises pour le texte IA: 11
- Duree: 42.5 s

## Principe
Le script ne depend pas d'un seul schema. Il reconnait plusieurs alias de colonnes, conserve les champs administratifs et construit `ai_clean_text` pour la phase IA.

## Traitements appliques
- lecture SQLite/CSV/XLSX/JSON/JSONL;
- mapping des colonnes vers des champs standards;
- nettoyage des textes web;
- suppression des URL non metier dans le texte envoye a l'IA;
- conservation d'une URL source et, si disponible, d'un site principal compact;
- suppression partielle du bruit: cookies, mentions legales, navigation, recrutement, contact trop technique;
- selection des phrases les plus utiles par score metier;
- limitation de longueur pour eviter de saturer le modele IA;
- conservation des champs originaux plus ajout des champs standardises.

## Fichiers generes
- entreprises_clean.db
- entreprises_clean.csv
- entreprises_clean.xlsx
- clean_report.md

## Principaux champs source detectes
business_text, certifications_text, classifications_text, clients_identified_text, company_description, markets_text, parc_machine_text, raw_text, site_activity_text, site_detailed_business_text, site_products_services_text