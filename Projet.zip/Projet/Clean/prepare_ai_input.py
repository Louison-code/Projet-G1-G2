"""
Preparation des entrees IA pour le projet G1/G2.

Entrees supportees:
- SQLite .db produit par DATA ou par un autre scraper;
- CSV;
- Excel XLSX/XLSM;
- JSON / JSONL.

Objectif:
- reconnaitre des colonnes differentes qui parlent de la meme chose;
- conserver les champs administratifs utiles;
- nettoyer les textes web bruites;
- construire un champ standard `ai_clean_text` directement exploitable par l'IA.

Sorties:
- entreprises_clean.db
- entreprises_clean.csv
- entreprises_clean.xlsx
- clean_report.md
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sqlite3
import time
import unicodedata
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


BASE_COLUMNS = [
    "input_id",
    "company_name",
    "siren",
    "siret",
    "naf_code",
    "legal_form",
    "effectifs",
    "capital",
    "address",
    "postal_code",
    "city",
    "country",
    "emails",
    "phones",
    "fax",
    "website_detected",
    "source_url",
    "domain",
    "source_page_type",
    "scrape_status",
    "pages_ok",
    "pages_error",
    "pages_blocked_robots",
    "fetched_at",
]

EXTRA_COLUMNS = [
    "ai_clean_text",
    "ai_input_quality_score",
    "ai_cleaning_status",
    "ai_cleaning_notes",
    "ai_source_fields",
    "ai_clean_text_hash",
    "clean_pipeline_version",
]

INTEGER_COLUMNS = {
    "pages_ok",
    "pages_error",
    "pages_blocked_robots",
    "robots_allowed",
}

KNOWN_COUNTRIES = {
    "france": "France",
    "belgique": "Belgique",
    "belgium": "Belgique",
    "suisse": "Suisse",
    "switzerland": "Suisse",
    "allemagne": "Allemagne",
    "germany": "Allemagne",
    "espagne": "Espagne",
    "spain": "Espagne",
    "italie": "Italie",
    "italy": "Italie",
    "luxembourg": "Luxembourg",
    "royaume uni": "Royaume-Uni",
    "united kingdom": "Royaume-Uni",
    "uk": "Royaume-Uni",
    "pays bas": "Pays-Bas",
    "netherlands": "Pays-Bas",
    "portugal": "Portugal",
}

ALIAS_GROUPS = {
    "input_id": (
        "input_id",
        "id",
        "id_ia",
        "company_id",
        "identifiant",
        "identifiant entreprise",
        "numero",
    ),
    "company_name": (
        "company_name",
        "raison_sociale",
        "raison sociale",
        "raison sociale finale",
        "entreprise",
        "nom",
        "nom entreprise",
        "denomination",
        "denomination sociale",
        "societe",
        "société",
    ),
    "source_url": (
        "source_url",
        "url",
        "lien",
        "link",
        "lien kompass",
        "lien_kompass",
        "kompass_url",
        "url kompass",
    ),
    "website_detected": (
        "website_detected",
        "site_web",
        "site web",
        "site internet",
        "website",
        "url_site",
        "site",
        "site_web_normalise",
        "site web normalise",
    ),
    "siren": ("siren", "siren_final", "no siren", "numero siren"),
    "siret": ("siret", "siret_final", "no siret", "numero siret"),
    "naf_code": ("naf_code", "code_naf", "code naf", "naf", "ape", "code ape"),
    "legal_form": ("legal_form", "forme_juridique", "forme juridique", "statut juridique"),
    "effectifs": ("effectifs", "effectif", "employees", "salariés", "salaries"),
    "capital": ("capital", "capital social"),
    "address": ("address", "adresse", "adresse_finale", "adresse finale"),
    "postal_code": ("postal_code", "code_postal", "code postal", "cp"),
    "city": ("city", "ville", "localisation", "commune"),
    "country": ("country", "pays"),
    "emails": ("emails", "email", "mail", "e-mail"),
    "phones": ("phones", "telephone", "téléphone", "tel", "phone"),
    "fax": ("fax",),
    "domain": ("domain", "domaine"),
    "source_page_type": ("source_page_type", "type source", "source type"),
    "scrape_status": ("scrape_status", "statut_scraping", "statut scraping", "status", "statut"),
    "pages_ok": ("pages_ok", "pages ok"),
    "pages_error": ("pages_error", "pages error"),
    "pages_blocked_robots": ("pages_blocked_robots", "pages blocked robots"),
    "fetched_at": ("fetched_at", "date_collecte", "date collecte", "scraped_at"),
}

TEXT_SECTIONS = [
    (
        "Description",
        900,
        (
            "company_description",
            "description",
            "description entreprise",
            "activite_client",
            "client_activite",
            "activte",
            "activité client",
            "activite",
            "activité",
            "activity",
            "activite source",
        ),
    ),
    (
        "Activite site officiel",
        1500,
        (
            "site_activity_text",
            "activity_text",
            "activite site",
            "activité site",
            "activite_site",
            "texte activite",
        ),
    ),
    (
        "Produits et services site officiel",
        1500,
        (
            "site_products_services_text",
            "products_services_text",
            "produits_services",
            "produits services",
            "services",
            "produits",
            "offre",
        ),
    ),
    (
        "Texte metier site officiel",
        3400,
        (
            "site_detailed_business_text",
            "detailed_business_text",
            "business_text",
            "texte_ia_complet",
            "texte ia complet",
            "texte_metier",
            "texte metier",
            "texte métier",
            "texte_ia",
        ),
    ),
    (
        "Activite Kompass",
        1500,
        (
            "kompass_activity_text",
            "activity kompass",
            "activité kompass",
            "activite kompass",
        ),
    ),
    (
        "Activites principales Kompass",
        1200,
        (
            "kompass_activities_main_text",
            "activities_main_text",
            "activites principales",
            "activités principales",
            "activite principale",
            "activité principale",
        ),
    ),
    (
        "Activites secondaires Kompass",
        1000,
        (
            "kompass_activities_secondary_text",
            "activities_secondary_text",
            "activites secondaires",
            "activités secondaires",
            "activite secondaire",
            "activité secondaire",
        ),
    ),
    (
        "Produits et services Kompass",
        1200,
        (
            "kompass_products_services_text",
            "produits services kompass",
            "produits et services kompass",
        ),
    ),
    (
        "Parc machine",
        1100,
        (
            "parc_machine_text",
            "parc machine",
            "machines",
            "equipements",
            "équipements",
            "moyens industriels",
        ),
    ),
    (
        "Clients identifies",
        900,
        (
            "clients_identified_text",
            "clients",
            "clients identifies",
            "clients identifiés",
            "references clients",
            "références clients",
        ),
    ),
    (
        "Marches",
        900,
        (
            "markets_text",
            "marches",
            "marchés",
            "marches cibles",
            "marchés cibles",
            "secteurs clients",
            "applications",
        ),
    ),
    (
        "Certifications et normes",
        850,
        (
            "certifications_text",
            "certifications",
            "normes",
            "certifications_normes",
            "certifications normes",
        ),
    ),
    (
        "Classifications",
        750,
        (
            "classifications_text",
            "classifications",
            "codifications",
            "rubriques",
            "secteur",
            "secteur kompass",
        ),
    ),
    (
        "Extraits web utiles",
        4200,
        (
            "raw_text",
            "texte brut",
            "html_text",
            "source text",
            "source_text",
            "contenu",
        ),
    ),
]

POSITIVE_KEYWORDS = {
    # Mots generiques d'activite.
    "activite": 4,
    "metier": 4,
    "specialise": 6,
    "specialisee": 6,
    "savoir faire": 6,
    "expertise": 5,
    "solution": 4,
    "solutions": 4,
    "service": 4,
    "services": 4,
    "produit": 4,
    "produits": 4,
    "offre": 3,
    "prestation": 4,
    "prestations": 4,
    "conseil": 5,
    "accompagnement": 4,
    "audit": 4,
    "formation": 4,
    "bureau d'etudes": 7,
    "ingenierie": 7,
    "etude": 4,
    "etudes": 4,
    "r&d": 7,
    "recherche et developpement": 7,
    "innovation": 5,
    "industrialisation": 8,
    "relocalisation": 7,
    "supply chain": 6,
    "chaine de valeur": 6,
    "approvisionnement": 5,
    "sourcing": 5,

    # Industrie, production et maintenance.
    "fabrication": 9,
    "production": 9,
    "conception": 7,
    "developpement": 6,
    "maintenance": 7,
    "installation": 5,
    "integration": 6,
    "assemblage": 8,
    "usinage": 9,
    "tournage": 8,
    "fraisage": 8,
    "decoupe": 7,
    "laser": 6,
    "chaudronnerie": 9,
    "soudure": 8,
    "mecanique": 7,
    "mecatronique": 8,
    "metallurgie": 8,
    "fonderie": 8,
    "forge": 7,
    "traitement thermique": 8,
    "traitement de surface": 9,
    "peinture industrielle": 7,
    "plasturgie": 8,
    "injection": 7,
    "extrusion": 7,
    "composite": 7,
    "composites": 7,
    "textile technique": 7,
    "emballage": 6,
    "packaging": 6,
    "impression": 5,
    "imprimerie": 5,
    "bois": 5,
    "menuiserie": 5,
    "ameublement": 5,
    "verre": 5,
    "ceramique": 5,
    "papier": 5,
    "carton": 5,
    "machine": 8,
    "machines": 8,
    "equipement": 7,
    "equipements": 7,
    "outillage": 7,
    "atelier": 6,
    "ligne de production": 9,
    "controle qualite": 8,
    "metrologie": 7,
    "laboratoire": 5,

    # Electronique, numerique et telecoms.
    "electronique": 8,
    "electrique": 7,
    "electricite": 7,
    "electrotechnique": 7,
    "automatisme": 8,
    "automatisation": 8,
    "robotique": 9,
    "robot": 8,
    "cobot": 8,
    "capteur": 7,
    "capteurs": 7,
    "instrumentation": 7,
    "controle commande": 8,
    "systeme embarque": 8,
    "systemes embarques": 8,
    "semi conducteur": 8,
    "microelectronique": 8,
    "cable": 5,
    "cablage": 6,
    "fibre optique": 6,
    "telecom": 5,
    "telecommunications": 5,
    "reseau": 5,
    "reseaux": 5,
    "logiciel": 6,
    "logiciels": 6,
    "saas": 6,
    "erp": 6,
    "crm": 5,
    "informatique industrielle": 9,
    "developpement logiciel": 7,
    "cybersecurite": 8,
    "cloud": 5,
    "data": 5,
    "intelligence artificielle": 7,
    "ia": 5,
    "iot": 7,
    "internet des objets": 7,
    "vision industrielle": 8,
    "simulation": 6,
    "jumeau numerique": 7,

    # Energie, environnement et utilities.
    "energie": 7,
    "energies renouvelables": 8,
    "solaire": 7,
    "photovoltaique": 7,
    "eolien": 7,
    "hydrogene": 8,
    "batterie": 7,
    "stockage d'energie": 8,
    "nucleaire": 8,
    "biogaz": 7,
    "biomasse": 7,
    "reseaux electriques": 7,
    "efficacite energetique": 7,
    "chauffage": 5,
    "climatisation": 5,
    "cvc": 6,
    "hvac": 6,
    "eau": 5,
    "traitement des eaux": 8,
    "assainissement": 6,
    "dechets": 6,
    "recyclage": 7,
    "valorisation": 6,
    "depollution": 7,
    "environnement": 6,
    "economie circulaire": 7,

    # Chimie, materiaux, pharma, sante.
    "chimie": 6,
    "materiaux": 7,
    "materiau": 7,
    "polymere": 7,
    "resine": 6,
    "peinture": 5,
    "cosmetique": 6,
    "pharmaceutique": 8,
    "pharma": 7,
    "biotechnologie": 8,
    "biotech": 8,
    "dispositif medical": 8,
    "medical": 6,
    "sante": 6,
    "diagnostic": 6,
    "sterilisation": 7,
    "medicament": 7,
    "laboratoire d'analyse": 7,

    # Agriculture, agroalimentaire et ressources.
    "agriculture": 6,
    "agricole": 6,
    "agroalimentaire": 7,
    "alimentaire": 6,
    "boisson": 5,
    "viticulture": 5,
    "elevage": 5,
    "semence": 5,
    "machinisme agricole": 7,
    "peche": 5,
    "aquaculture": 5,
    "foresterie": 5,
    "mines": 6,
    "carriere": 5,
    "granulat": 5,

    # Construction, infrastructure, immobilier.
    "btp": 7,
    "batiment": 6,
    "construction": 6,
    "travaux publics": 7,
    "genie civil": 7,
    "infrastructure": 6,
    "architecture": 5,
    "immobilier": 4,
    "renovation": 5,
    "isolation": 5,
    "charpente": 5,
    "couverture": 5,
    "plomberie": 5,
    "electricite batiment": 6,

    # Transport, mobilite, logistique.
    "transport": 6,
    "logistique": 7,
    "entreposage": 5,
    "stockage": 5,
    "distribution": 5,
    "expedition": 5,
    "livraison": 5,
    "mobilite": 5,
    "ferroviaire": 8,
    "naval": 8,
    "maritime": 7,
    "aeronautique": 8,
    "spatial": 8,
    "automobile": 7,
    "vehicule": 5,
    "poids lourd": 6,
    "defense": 8,
    "securite": 5,

    # Tertiaire, commerce, finance, culture.
    "commerce": 4,
    "distribution specialisee": 5,
    "retail": 4,
    "e commerce": 5,
    "marketplace": 5,
    "hotellerie": 4,
    "restauration": 4,
    "tourisme": 4,
    "banque": 4,
    "assurance": 4,
    "finance": 4,
    "expertise comptable": 4,
    "juridique": 3,
    "communication": 4,
    "marketing": 4,
    "media": 4,
    "edition": 4,
    "audiovisuel": 4,
    "culture": 3,
    "evenementiel": 4,

    # Indices de marche, clients, normes.
    "certification": 8,
    "certifie": 7,
    "iso": 8,
    "norme": 6,
    "normes": 6,
    "homologation": 7,
    "qualification": 6,
    "client": 4,
    "clients": 4,
    "marche": 4,
    "marches": 4,
    "secteur": 4,
    "secteurs": 4,
    "application": 4,
    "applications": 4,
}

NEGATIVE_KEYWORDS = {
    "cookie": 10,
    "cookies": 10,
    "rgpd": 8,
    "gdpr": 8,
    "confidentialite": 8,
    "mentions legales": 9,
    "conditions generales": 9,
    "newsletter": 8,
    "mot de passe": 8,
    "connexion": 6,
    "se connecter": 8,
    "panier": 7,
    "copyright": 7,
    "plan du site": 8,
    "facebook": 7,
    "instagram": 7,
    "twitter": 7,
    "linkedin": 5,
    "youtube": 5,
    "google analytics": 9,
    "contactez-nous": 6,
    "contactez nous": 6,
    "tous droits reserves": 9,
    "recrutement": 7,
    "offres d'emploi": 7,
    "candidature": 6,
}

DROP_PATTERNS = [
    re.compile(r"\bmailto:\S+", re.IGNORECASE),
    re.compile(r"\btel:\S+", re.IGNORECASE),
    re.compile(r"\bjavascript:\S*", re.IGNORECASE),
    re.compile(r"\b\d{2}(?:[ .-]?\d{2}){4}\b"),
]

URL_PATTERN = re.compile(r"https?://[^\s;,)>\"]+", re.IGNORECASE)

NOISY_URL_DOMAINS = (
    "youtube.com",
    "youtu.be",
    "facebook.com",
    "instagram.com",
    "linkedin.com",
    "twitter.com",
    "x.com",
    "choosemycompany.com",
    "darktrace.com",
    "sentinelone.com",
    "cookiedatabase.org",
    "cdn-website.com",
    "calendly.com",
    "google.com",
    "docs.google.com",
    "hpanel.hostinger.com",
    "hostinger.com",
    "community.ovh.com",
    "teamviewer.com",
    "jimdo.com",
)

NOISY_URL_PARTS = (
    "preprod.",
    "/login",
    "/signin",
    "/auth/",
    "/app/",
    "/cms/",
    "/logout",
    "/privacy",
    "/terms",
    "/mentions",
    "/cookie",
    "/wp-content/",
    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".webp",
    ".svg",
)


def now_iso() -> str:
    """Renvoie une date UTC stable."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def fold_text(value: Any) -> str:
    """Normalise pour comparer des noms de colonnes meme avec accents."""
    if value is None:
        return ""
    text = unicodedata.normalize("NFKD", str(value))
    text = "".join(char for char in text if not unicodedata.combining(char))
    text = text.lower().strip()
    text = re.sub(r"[_\-./]+", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text


def clean_text(value: Any) -> str:
    """Nettoie un texte sans inventer de contenu."""
    if value is None:
        return ""
    text = str(value).replace("\ufeff", " ").replace("\x00", " ")
    for pattern in DROP_PATTERNS:
        text = pattern.sub(" ", text)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip(" ;,|-")


def extract_urls(value: str) -> list[str]:
    """Extrait les URL HTTP(S) en supprimant les doublons evidents."""
    urls = []
    seen: set[str] = set()
    for match in URL_PATTERN.finditer(clean_text(value)):
        url = match.group(0).strip(" ;,.)]")
        if url in {"http://", "https://"} or url in seen:
            continue
        seen.add(url)
        urls.append(url)
    return urls


def url_domain(value: str) -> str:
    """Retourne le domaine d'une URL si elle est valide."""
    try:
        parsed = urlparse(value)
    except ValueError:
        return ""
    return (parsed.netloc or "").lower().removeprefix("www.")


def is_noisy_url(value: str) -> bool:
    """Detecte les URL qui ne sont pas des pages metier utiles pour l'IA."""
    low = value.lower()
    domain = url_domain(value)
    if not domain:
        return True
    if any(domain == noisy or domain.endswith("." + noisy) for noisy in NOISY_URL_DOMAINS):
        return True
    return any(part in low for part in NOISY_URL_PARTS)


def compact_url_value(value: str, preferred_domain: str = "", allow_noisy_fallback: bool = False) -> str:
    """Garde une seule URL lisible au lieu d'une liste de liens internes."""
    urls = extract_urls(value)
    if not urls:
        return ""
    preferred = preferred_domain.lower().removeprefix("www.")
    clean_urls = [url for url in urls if not is_noisy_url(url)]
    if preferred:
        for url in clean_urls:
            domain = url_domain(url)
            if domain == preferred or domain.endswith("." + preferred):
                return url
    if clean_urls:
        return clean_urls[0]
    return urls[0] if allow_noisy_fallback else ""


def site_homepage(value: str) -> str:
    """Reduit une URL de site a son domaine principal pour eviter les liens internes."""
    if not value:
        return ""
    try:
        parsed = urlparse(value)
    except ValueError:
        return ""
    if not parsed.scheme or not parsed.netloc:
        return ""
    return f"{parsed.scheme}://{parsed.netloc}/"


def remove_urls_for_ai(value: str) -> str:
    """Retire les URL du texte envoye a l'IA, sans supprimer le texte metier."""
    return clean_text(URL_PATTERN.sub(" ", value))


@lru_cache(maxsize=128)
def _normalized_column_map_cached(columns: tuple[str, ...]) -> dict[str, str]:
    """Construit un index tolerant des noms de colonnes."""
    result: dict[str, str] = {}
    for column in columns:
        key = fold_text(column)
        if key and key not in result:
            result[key] = column
    return result


def normalized_column_map(columns: list[str]) -> dict[str, str]:
    """Construit un index tolerant des noms de colonnes avec cache."""
    return _normalized_column_map_cached(tuple(columns))


def find_column(columns: list[str], aliases: tuple[str, ...]) -> str:
    """Trouve la premiere colonne correspondant a une liste d'alias."""
    mapping = normalized_column_map(columns)
    for alias in aliases:
        column = mapping.get(fold_text(alias))
        if column:
            return column
    return ""


def values_for_aliases(row: dict[str, Any], aliases: tuple[str, ...]) -> list[tuple[str, str]]:
    """Retourne les valeurs presentes pour plusieurs alias possibles."""
    columns = list(row.keys())
    mapping = normalized_column_map(columns)
    values: list[tuple[str, str]] = []
    used_columns: set[str] = set()
    for alias in aliases:
        column = mapping.get(fold_text(alias))
        if not column or column in used_columns:
            continue
        value = clean_text(row.get(column))
        if value:
            values.append((column, value))
            used_columns.add(column)
    return values


def first_value(row: dict[str, Any], canonical: str) -> str:
    """Lit un champ canonique depuis des colonnes variables."""
    aliases = ALIAS_GROUPS.get(canonical, (canonical,))
    values = values_for_aliases(row, aliases)
    return values[0][1] if values else ""


def normalize_country_name(value: str) -> str:
    """Normalise un pays seulement s'il est explicitement reconnu."""
    folded = fold_text(value)
    return KNOWN_COUNTRIES.get(folded, "")


def split_localisation(value: str) -> tuple[str, str]:
    """Separe une localisation du type 'Ville - Pays' sans inventer le pays."""
    text = clean_text(value)
    if not text:
        return "", ""
    parts = [part.strip(" ,;") for part in re.split(r"\s+-\s+|\s+–\s+|\s+—\s+", text) if part.strip()]
    if len(parts) >= 2:
        country = normalize_country_name(parts[-1])
        if country:
            return " - ".join(parts[:-1]).strip(), country
    for pattern in (r",\s*([A-Za-zÀ-ÿ -]+)$", r"\s+\(([A-Za-zÀ-ÿ -]+)\)$"):
        match = re.search(pattern, text)
        if match:
            country = normalize_country_name(match.group(1))
            if country:
                return text[: match.start()].strip(" ,;()"), country
    return text, ""


def split_sentences(text: str) -> list[str]:
    """Decoupe un texte en morceaux exploitables."""
    text = clean_text(text)
    if not text:
        return []
    text = re.sub(r"\s*[•·]\s*", ". ", text)
    parts = re.split(r"(?<=[.!?])\s+|[\r\n]+|\s{2,}| \| | /{2,}", text)
    result: list[str] = []
    for part in parts:
        part = clean_text(part)
        if len(part) < 25:
            continue
        result.append(part)
    return result


@lru_cache(maxsize=1)
def keyword_items() -> tuple[tuple[tuple[str, int], ...], tuple[tuple[str, int], ...]]:
    """Prepare les mots-cles normalises une seule fois pour accelerer le scoring."""
    positive = tuple((fold_text(keyword), weight) for keyword, weight in POSITIVE_KEYWORDS.items())
    negative = tuple((fold_text(keyword), weight) for keyword, weight in NEGATIVE_KEYWORDS.items())
    return positive, negative


def score_sentence(text: str) -> int:
    """Score une phrase selon son interet metier pour l'IA."""
    low = fold_text(text)
    score = 0
    positive_items, negative_items = keyword_items()
    for keyword, weight in positive_items:
        if keyword and keyword in low:
            score += weight
    for keyword, weight in negative_items:
        if keyword and keyword in low:
            score -= weight
    if 60 <= len(text) <= 650:
        score += 3
    if len(text) > 1200:
        score -= 5
    if text.count(";") > 8:
        score -= 3
    if text.count("@") > 2:
        score -= 4
    return score


def dedupe_keep_order(values: list[str]) -> list[str]:
    """Supprime les doublons sans changer l'ordre."""
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        cleaned = clean_text(value)
        normalized = fold_text(cleaned)
        if not cleaned or normalized in seen:
            continue
        seen.add(normalized)
        result.append(cleaned)
    return result


def select_best_text(text: str, max_chars: int, min_score: int = -2) -> str:
    """Garde les passages les plus utiles et limite le bruit web."""
    sentences = split_sentences(text)
    if not sentences:
        return ""
    scored_sentences = [(index, sentence, score_sentence(sentence)) for index, sentence in enumerate(sentences)]
    ranked = sorted(
        scored_sentences,
        key=lambda item: (item[2], -item[0]),
        reverse=True,
    )
    selected: list[tuple[int, str]] = []
    total = 0
    for index, sentence, score in ranked:
        if score < min_score and selected:
            continue
        candidate_len = len(sentence) + 2
        if total + candidate_len > max_chars:
            continue
        selected.append((index, sentence))
        total += candidate_len
        if total >= int(max_chars * 0.92):
            break
    selected.sort(key=lambda item: item[0])
    return " ".join(dedupe_keep_order([sentence for _, sentence in selected]))[:max_chars]


def source_format(path: Path) -> str:
    """Retourne un libelle simple du format source."""
    suffix = path.suffix.lower()
    if suffix in {".db", ".sqlite", ".sqlite3"}:
        return "sqlite"
    if suffix == ".csv":
        return "csv"
    if suffix in {".xlsx", ".xlsm"}:
        return "xlsx"
    if suffix == ".json":
        return "json"
    if suffix == ".jsonl":
        return "jsonl"
    return suffix.strip(".") or "unknown"


def read_sqlite_rows(path: Path) -> tuple[list[dict[str, Any]], list[str], str]:
    """Charge une table SQLite en restant tolerant sur le nom de table."""
    connection = sqlite3.connect(path)
    connection.row_factory = sqlite3.Row
    try:
        tables = [
            row[0]
            for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()
        ]
        if not tables:
            raise RuntimeError("Aucune table SQLite lisible")
        table = "companies_raw" if "companies_raw" in tables else tables[0]
        table_info = connection.execute(f'PRAGMA table_info("{table}")').fetchall()
        columns = [row[1] for row in table_info]
        order = "input_id" if "input_id" in columns else columns[0]
        rows = [dict(row) for row in connection.execute(f'SELECT * FROM "{table}" ORDER BY "{order}"').fetchall()]
        return rows, columns, table
    finally:
        connection.close()


def read_csv_rows(path: Path) -> tuple[list[dict[str, Any]], list[str], str]:
    """Charge un CSV."""
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        columns = [column or "" for column in (reader.fieldnames or [])]
        rows = [dict(row) for row in reader]
    return rows, columns, "csv"


def read_xlsx_rows(path: Path) -> tuple[list[dict[str, Any]], list[str], str]:
    """Charge un fichier Excel."""
    try:
        import openpyxl
    except ImportError as exc:
        raise RuntimeError("openpyxl est requis pour lire les fichiers Excel") from exc
    workbook = openpyxl.load_workbook(path, read_only=True, data_only=True)
    sheet = workbook.active
    rows_iter = sheet.iter_rows(values_only=True)
    try:
        headers = [clean_text(value) for value in next(rows_iter)]
    except StopIteration:
        return [], [], sheet.title
    rows: list[dict[str, Any]] = []
    for values in rows_iter:
        rows.append({headers[index]: clean_text(value) for index, value in enumerate(values) if index < len(headers)})
    return rows, headers, sheet.title


def read_json_rows(path: Path) -> tuple[list[dict[str, Any]], list[str], str]:
    """Charge JSON ou JSONL."""
    if path.suffix.lower() == ".jsonl":
        rows = [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    else:
        payload = json.loads(path.read_text(encoding="utf-8-sig"))
        if isinstance(payload, list):
            rows = payload
        elif isinstance(payload, dict):
            for key in ("companies", "entreprises", "rows", "data", "items"):
                if isinstance(payload.get(key), list):
                    rows = payload[key]
                    break
            else:
                rows = [payload]
        else:
            rows = []
    normalized_rows = [row if isinstance(row, dict) else {"value": row} for row in rows]
    columns = sorted({str(key) for row in normalized_rows for key in row.keys()})
    return normalized_rows, columns, "json"


def read_rows(input_path: Path, start: int, limit: int | None) -> tuple[list[dict[str, Any]], list[str], str]:
    """Charge les lignes depuis un format supporte."""
    suffix = input_path.suffix.lower()
    if suffix in {".db", ".sqlite", ".sqlite3"}:
        rows, columns, table = read_sqlite_rows(input_path)
    elif suffix == ".csv":
        rows, columns, table = read_csv_rows(input_path)
    elif suffix in {".xlsx", ".xlsm"}:
        rows, columns, table = read_xlsx_rows(input_path)
    elif suffix in {".json", ".jsonl"}:
        rows, columns, table = read_json_rows(input_path)
    else:
        raise ValueError(f"Format d'entree non supporte par CLEAN: {input_path.suffix}")
    if start > 1:
        rows = rows[start - 1 :]
    if limit is not None and limit > 0:
        rows = rows[:limit]
    return rows, columns, table


def normalize_base_fields(row: dict[str, Any], index: int) -> dict[str, str]:
    """Cree des champs de base standard meme si l'entree utilise d'autres noms."""
    normalized: dict[str, str] = {}
    for field in BASE_COLUMNS:
        normalized[field] = first_value(row, field)
    if not normalized["input_id"]:
        normalized["input_id"] = f"ENT_{index:06d}"
    city, country_from_city = split_localisation(normalized["city"])
    if city:
        normalized["city"] = city
    if not normalized["country"] and country_from_city:
        normalized["country"] = country_from_city
    if normalized["country"]:
        normalized["country"] = normalize_country_name(normalized["country"]) or normalized["country"]
    return normalized


def clean_original_text_fields(row: dict[str, Any]) -> dict[str, Any]:
    """Nettoie les champs texte originaux connus sans toucher aux champs administratifs."""
    cleaned = dict(row)
    all_aliases = {alias for _, _, aliases in TEXT_SECTIONS for alias in aliases}
    columns = list(row.keys())
    for alias in all_aliases:
        column = find_column(columns, (alias,))
        if not column:
            continue
        value = clean_text(cleaned.get(column))
        if not value:
            cleaned[column] = ""
            continue
        limit = 4200 if fold_text(column) in {"raw text", "texte brut", "business text"} else 1500
        min_score = -4 if limit >= 3200 else -2
        cleaned[column] = select_best_text(value, limit, min_score=min_score) or value[:limit]
    return cleaned


def build_clean_input(row: dict[str, Any], base: dict[str, str]) -> tuple[str, int, str, str]:
    """Construit le texte final que l'IA doit lire."""
    sections: list[str] = []
    notes: list[str] = []
    used_fields: list[str] = []

    source_url = compact_url_value(base.get("source_url", ""), allow_noisy_fallback=True)
    site_url = site_homepage(compact_url_value(base.get("website_detected", ""), base.get("domain", "")))

    header = [
        f"Entreprise: {base.get('company_name', '')}",
        f"URL source: {source_url}",
        f"Site detecte: {site_url}",
        f"Statut scraping: {base.get('scrape_status', '')}",
    ]
    if base.get("naf_code"):
        header.append(f"Code NAF: {base['naf_code']}")
    if base.get("city") or base.get("postal_code"):
        header.append(f"Localisation: {base.get('postal_code', '')} {base.get('city', '')}".strip())
    sections.append("\n".join(line for line in header if clean_text(line.split(":", 1)[-1])))

    strong_sections = 0
    raw_only = True
    for label, limit, aliases in TEXT_SECTIONS:
        values = values_for_aliases(row, aliases)
        if not values:
            continue
        joined = " ".join(value for _, value in values)
        min_score = -4 if label == "Extraits web utiles" else -2
        cleaned = select_best_text(joined, limit, min_score=min_score)
        cleaned = remove_urls_for_ai(cleaned)
        if not cleaned:
            continue
        sections.append(f"{label}:\n{cleaned}")
        used_fields.extend(column for column, _ in values)
        if label != "Extraits web utiles":
            raw_only = False
            strong_sections += 1

    clean_input = "\n\n".join(dedupe_keep_order(sections))
    length = len(clean_input)

    quality = 0
    if fold_text(base.get("scrape_status")) == "ok":
        quality += 15
    try:
        quality += min(int(base.get("pages_ok") or 0) * 8, 24)
    except ValueError:
        pass
    quality += min(length // 300, 30)
    quality += min(strong_sections * 7, 28)
    if base.get("company_name"):
        quality += 3
    if base.get("source_url") or base.get("website_detected"):
        quality += 3
    structured_used_fields = {fold_text(field).replace("_", " ") for field in used_fields}
    if structured_used_fields.intersection(
        {
            "company description",
            "business text",
            "site activity text",
            "site detailed business text",
            "site products services text",
        }
    ):
        quality += 20
    if length >= 600 and strong_sections >= 1:
        quality += 10
    if raw_only and length:
        quality -= 12
        notes.append("texte_base_surtout_raw")
    if length < 350:
        notes.append("texte_trop_court")
    if not used_fields:
        notes.append("aucun_champ_metier_detecte")
    if "blocked" in fold_text(base.get("scrape_status")):
        notes.append("source_bloquee_ou_incomplete")
    if length > 6500:
        notes.append("texte_long_tronque")

    quality = max(0, min(100, quality))
    return clean_input[:7000], quality, "; ".join(notes), "; ".join(dedupe_keep_order(used_fields))


def output_columns(source_columns: list[str]) -> list[str]:
    """Prepare les colonnes de sortie: original + base standard + champs clean."""
    return dedupe_keep_order(source_columns + BASE_COLUMNS + EXTRA_COLUMNS)


def clean_row(row: dict[str, Any], source_columns: list[str], index: int) -> dict[str, Any]:
    """Nettoie une ligne et produit les champs attendus par l'IA."""
    cleaned = clean_original_text_fields(row)
    base = normalize_base_fields(cleaned, index)
    cleaned.update({key: value for key, value in base.items() if value})
    ai_text, quality, notes, source_fields = build_clean_input(cleaned, base)
    cleaned["ai_clean_text"] = ai_text
    cleaned["ai_input_quality_score"] = str(quality)
    cleaned["ai_cleaning_status"] = "ok" if ai_text and quality >= 40 else ("weak_text" if ai_text else "empty")
    cleaned["ai_cleaning_notes"] = notes
    cleaned["ai_source_fields"] = source_fields
    cleaned["ai_clean_text_hash"] = hashlib.sha256(ai_text.encode("utf-8", errors="ignore")).hexdigest() if ai_text else ""
    cleaned["clean_pipeline_version"] = "CLEAN"
    return {column: cleaned.get(column, "") for column in output_columns(source_columns)}


def create_output_db(connection: sqlite3.Connection, columns: list[str]) -> None:
    """Cree la table de sortie compatible avec le pipeline IA."""
    definitions = []
    for column in columns:
        col_type = "TEXT"
        if column in INTEGER_COLUMNS:
            col_type = "INTEGER"
        definitions.append(f'"{column}" {col_type}')
    connection.execute("DROP TABLE IF EXISTS companies_raw")
    connection.execute(f"CREATE TABLE companies_raw ({', '.join(definitions)}, PRIMARY KEY(input_id))")
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS clean_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            input_id TEXT,
            status TEXT,
            message TEXT,
            source_fields TEXT,
            created_at TEXT
        )
        """
    )
    connection.commit()


def insert_rows(output_db: Path, rows: list[dict[str, Any]], columns: list[str]) -> None:
    """Ecrit les lignes nettoyees dans SQLite."""
    output_db.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(output_db)
    try:
        create_output_db(connection, columns)
        placeholders = ", ".join("?" for _ in columns)
        col_sql = ", ".join(f'"{column}"' for column in columns)
        values = [[row.get(column, "") for column in columns] for row in rows]
        connection.executemany(f"INSERT OR REPLACE INTO companies_raw ({col_sql}) VALUES ({placeholders})", values)
        for row in rows:
            connection.execute(
                "INSERT INTO clean_events (input_id, status, message, source_fields, created_at) VALUES (?, ?, ?, ?, ?)",
                (
                    row.get("input_id", ""),
                    row.get("ai_cleaning_status", ""),
                    row.get("ai_cleaning_notes", ""),
                    row.get("ai_source_fields", ""),
                    now_iso(),
                ),
            )
        connection.commit()
    finally:
        connection.close()


def export_csv(rows: list[dict[str, Any]], columns: list[str], output_csv: Path) -> None:
    """Exporte un CSV de controle."""
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in columns})


def export_xlsx(csv_path: Path, xlsx_path: Path) -> None:
    """Convertit le CSV de controle en XLSX si openpyxl est disponible."""
    try:
        import openpyxl
        from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
    except ImportError:
        return
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "entreprises_clean"
    with csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.reader(handle):
            sheet.append([ILLEGAL_CHARACTERS_RE.sub("", str(value))[:32767] for value in row])
    sheet.freeze_panes = "A2"
    for cell in sheet[1]:
        cell.font = openpyxl.styles.Font(bold=True)
    workbook.save(xlsx_path)


def write_report(
    output_dir: Path,
    rows: list[dict[str, Any]],
    started_at: float,
    args: argparse.Namespace,
    source_table: str,
    source_columns: list[str],
) -> None:
    """Ecrit un rapport lisible pour l'audit."""
    total = len(rows)
    with_text = sum(1 for row in rows if clean_text(row.get("ai_clean_text")))
    weak = sum(1 for row in rows if row.get("ai_cleaning_status") == "weak_text")
    empty = sum(1 for row in rows if row.get("ai_cleaning_status") == "empty")
    average_quality = round(
        sum(int(row.get("ai_input_quality_score") or 0) for row in rows) / total,
        2,
    ) if total else 0
    used_fields = sorted(
        {
            field
            for row in rows
            for field in clean_text(row.get("ai_source_fields")).split("; ")
            if field
        }
    )
    report = [
        "# Rapport CLEAN",
        "",
        f"- Date: {now_iso()}",
        f"- Entree: `{args.input}`",
        f"- Format detecte: `{source_format(args.input)}`",
        f"- Table/feuille/source: `{source_table}`",
        f"- Sortie: `{output_dir}`",
        f"- Lignes traitees: {total}",
        f"- Lignes avec texte IA nettoye: {with_text}",
        f"- Lignes faibles: {weak}",
        f"- Lignes vides: {empty}",
        f"- Score qualite moyen: {average_quality}",
        f"- Colonnes source lues: {len(source_columns)}",
        f"- Champs source utilises pour le texte IA: {len(used_fields)}",
        f"- Duree: {time.time() - started_at:.1f} s",
        "",
        "## Principe",
        "Le script ne depend pas d'un seul schema. Il reconnait plusieurs alias de colonnes, conserve les champs administratifs et construit `ai_clean_text` pour la phase IA.",
        "",
        "## Traitements appliques",
        "- lecture SQLite/CSV/XLSX/JSON/JSONL;",
        "- mapping des colonnes vers des champs standards;",
        "- nettoyage des textes web;",
        "- suppression des URL non metier dans le texte envoye a l'IA;",
        "- conservation d'une URL source et, si disponible, d'un site principal compact;",
        "- suppression partielle du bruit: cookies, mentions legales, navigation, recrutement, contact trop technique;",
        "- selection des phrases les plus utiles par score metier;",
        "- limitation de longueur pour eviter de saturer le modele IA;",
        "- conservation des champs originaux plus ajout des champs standardises.",
        "",
        "## Fichiers generes",
        "- entreprises_clean.db",
        "- entreprises_clean.csv",
        "- entreprises_clean.xlsx",
        "- clean_report.md",
    ]
    if used_fields:
        report.extend(["", "## Principaux champs source detectes", ", ".join(used_fields[:80])])
    (output_dir / "clean_report.md").write_text("\n".join(report), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    """Parse les arguments CLI."""
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description="Prepare des textes nettoyes pour la partie IA.")
    parser.add_argument("--input", type=Path, default=project_root / "Data" / "output_full" / "entreprises.db")
    parser.add_argument("--output", type=Path, default=project_root / "Clean" / "output_full")
    parser.add_argument("--start", type=int, default=1)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def main() -> int:
    """Point d'entree."""
    args = parse_args()
    started_at = time.time()
    input_path = args.input.resolve()
    output_dir = args.output.resolve()
    output_db = output_dir / "entreprises_clean.db"
    output_csv = output_dir / "entreprises_clean.csv"
    output_xlsx = output_dir / "entreprises_clean.xlsx"

    if not input_path.exists():
        raise FileNotFoundError(f"Entree DATA introuvable: {input_path}")
    if output_dir.exists() and args.overwrite:
        for path in [output_db, output_csv, output_xlsx, output_dir / "clean_report.md"]:
            if path.exists():
                path.unlink()
    output_dir.mkdir(parents=True, exist_ok=True)

    limit = args.limit if args.limit > 0 else None
    source_rows, source_columns, source_table = read_rows(input_path, args.start, limit)
    columns = output_columns(source_columns)
    cleaned_rows: list[dict[str, Any]] = []
    total_rows = len(source_rows)
    for offset, row in enumerate(source_rows, start=args.start):
        cleaned_rows.append(clean_row(row, source_columns, offset))
        processed = len(cleaned_rows)
        if processed == 1 or processed % 500 == 0 or processed == total_rows:
            print(
                json.dumps(
                    {
                        "event": "clean_progress",
                        "processed": processed,
                        "total": total_rows,
                        "elapsed_s": round(time.time() - started_at, 1),
                    },
                    ensure_ascii=False,
                ),
                flush=True,
            )
    insert_rows(output_db, cleaned_rows, columns)
    export_csv(cleaned_rows, columns, output_csv)
    export_xlsx(output_csv, output_xlsx)
    write_report(output_dir, cleaned_rows, started_at, args, source_table, source_columns)

    print(
        json.dumps(
            {
                "event": "clean_done",
                "pipeline": "CLEAN",
                "input": str(input_path),
                "output": str(output_dir),
                "rows": len(cleaned_rows),
                "db": str(output_db),
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
