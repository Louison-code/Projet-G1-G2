# Benchmark de parallelisation DATA

Ce document resume le choix de parallelisation pour le module DATA.

## Objectif

Le scraping doit rester assez rapide pour traiter plusieurs milliers de lignes, sans envoyer trop de requetes en meme temps vers les memes domaines.

Le parametre utilise est:

```text
--workers
```

Il controle le nombre d'entreprises traitees en parallele.

## Choix retenu

Le reglage recommande est:

```text
--workers 8
```

Pourquoi 8:

- assez rapide pour un echantillon de taille moyenne;
- moins instable qu'un nombre de workers trop eleve;
- limite les erreurs liees aux timeouts et aux sites lents;
- reste raisonnable pour une machine personnelle.

Un nombre plus eleve peut sembler attractif, mais il peut ralentir le run si les sites repondent mal, si le reseau sature ou si trop de domaines attendent en meme temps.

## Dernier test mesure

Run:

```text
Data/output_data_1000_worker8_latest
```

Parametres:

- 1000 entreprises;
- 8 workers;
- entree: `Data/input/liste URL_KOMPASS.xlsx`.

Resultats:

- total: 1000 lignes;
- `ok`: 815;
- `blocked_robots`: 176;
- `error`: 9;
- `business_text`: 998/1000;
- `company_description`: 1000/1000;
- duree DATA observee: environ 18 min 40 s.

## Interpretation

Le nombre de lignes `blocked_robots` ne signifie pas toujours que la ligne est inutilisable. Quand le fichier client fournit deja une activite dans `ACTIVTE`, cette information est integree dans `company_description` et `business_text`.

Cela permet au module CLEAN et au module IA de garder une entree exploitable meme lorsque la collecte web directe est limitee.

## Recommendation

Pour un run long:

```bash
python Data\scraper_mvp.py --input "Data\input\liste URL_KOMPASS.xlsx" --output "Data\output_data_full" --workers 8
```

Pour decouper le traitement:

```bash
python Data\scraper_mvp.py --input "Data\input\liste URL_KOMPASS.xlsx" --output "Data\output_data_part1" --start 1 --limit 1000 --workers 8
python Data\scraper_mvp.py --input "Data\input\liste URL_KOMPASS.xlsx" --output "Data\output_data_part2" --start 1001 --limit 1000 --workers 8
```

Le decoupage est utile pour controler la qualite progressivement.
