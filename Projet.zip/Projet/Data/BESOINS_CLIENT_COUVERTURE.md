# Besoins client et couverture DATA

Ce document resume ce que couvre la partie DATA par rapport au besoin exprime pendant les echanges projet.

## Besoin compris

Le client ne demande pas seulement un Excel ponctuel. Le besoin technique est un outil reutilisable capable de:

- prendre en entree un fichier de liens ou un lien direct;
- collecter les pages accessibles;
- structurer les donnees dans une base SQLite;
- exporter en CSV et Excel;
- garder des traces de collecte et d'erreur;
- fournir un texte metier exploitable ensuite par l'IA.

## Donnees conservees

La partie DATA conserve les informations administratives utiles quand elles existent:

- nom d'entreprise;
- ville;
- code postal;
- site web;
- SIREN / SIRET / NAF si presents dans les sources;
- forme juridique, effectifs, capital, contact si detectes.

Mais DATA ne s'arrete pas a ces champs. Le point principal est de construire un texte metier utilisable:

- description d'activite;
- produits et services;
- machines et equipements;
- marches;
- clients;
- certifications;
- classifications;
- preuves textuelles issues des sources accessibles.

## Integration du fichier client

Le fichier `liste URL_KOMPASS.xlsx` contient dans sa feuille `Base`:

- `LIEN KOMPASS`;
- `RAISON SOCIALE`;
- `LOCALISATION`;
- `ACTIVTE`;
- `SITE WEB`.

Ces colonnes sont converties dans notre schema:

| Colonne client | Utilisation DATA |
| --- | --- |
| `LIEN KOMPASS` | lien source et reference Kompass |
| `RAISON SOCIALE` | `company_name` |
| `LOCALISATION` | `city`, parfois `postal_code` / `country` |
| `ACTIVTE` | `company_description`, `business_text` |
| `SITE WEB` | `website_detected` et point d'entree du site officiel |

Cela evite de perdre l'activite fournie par le client, meme si le site web ou Kompass ne peut pas etre collecte.

## Kompass

DATA distingue:

- les informations deja fournies par le fichier client;
- les pages Kompass qui seraient collecteables dans un cadre autorise;
- les pages bloquees par `robots.txt`.

Le script ne contourne pas les restrictions. Si Kompass bloque une page, la ligne est marquee `blocked_robots`. Pour une collecte complete de Kompass, il faut une API officielle, un export, une autorisation explicite ou des fichiers HTML fournis.

## Sorties utiles pour la suite

DATA produit:

- une base SQLite `entreprises.db`;
- un CSV `entreprises.csv`;
- un Excel `entreprises.xlsx`;
- un fichier d'erreurs `errors.csv`;
- un resume qualite `quality_summary.json`;
- un rapport `run_report.md`.

Le champ le plus important pour la suite est:

```text
business_text
```

Il regroupe le texte metier disponible et sert d'entree au module CLEAN.

## Resultat du dernier test

Run:

```text
Data/output_data_1000_worker8_latest
```

Resultats:

- 1000 lignes traitees;
- 815 lignes `ok`;
- 176 lignes `blocked_robots`;
- 9 lignes `error`;
- `company_description`: 1000/1000;
- `business_text`: 998/1000.

## Limite

DATA ne produit pas les labels IA finaux. Les champs comme `secteur_ia`, `sous_secteur_ia`, `chaine_valeur`, `potentiel_interet` et `niveau_priorite` sont produits plus tard par le module IA, a partir du texte nettoye par CLEAN.
