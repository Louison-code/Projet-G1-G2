# Projet G1/G2 - Module DATA

Ce dossier contient l'outil de collecte et de structuration des donnees entreprises.

L'objectif n'est pas seulement de produire un Excel. L'objectif est d'avoir un outil reutilisable:

```text
fichier de liens ou lien direct
-> collecte des pages accessibles
-> extraction et structuration des informations utiles
-> base SQLite
-> exports CSV et Excel
-> rapport de qualite
```

## Fichiers principaux

```text
Data/
  scraper_mvp.py        script principal de collecte DATA
  requirements.txt      dependances Python
  config.json           resume de configuration
  input/                fichiers d'entree
  output_.../           resultats de run
```

Le script peut etre execute avec Python, sans Codex.

## Entrees acceptees

Le module accepte:

- un fichier Excel `.xlsx`;
- un fichier CSV `.csv`;
- un fichier texte `.txt` avec un lien par ligne;
- un ou plusieurs liens passes directement avec `--url`.

Le fichier principal de test est:

```text
Data/input/liste URL_KOMPASS.xlsx
```

Dans la feuille `Base`, le fichier client contient ces colonnes:

- `LIEN KOMPASS`
- `RAISON SOCIALE`
- `LOCALISATION`
- `ACTIVTE`
- `SITE WEB`

Ces colonnes ne sont pas recopiees comme cinq colonnes brutes dans la sortie finale. Elles sont integrees dans notre structure:

- `LIEN KOMPASS` alimente le lien source et la reference Kompass.
- `RAISON SOCIALE` alimente `company_name`.
- `LOCALISATION` alimente `city`, et quand c'est possible `postal_code` et `country`.
- `ACTIVTE` alimente `company_description` et `business_text`.
- `SITE WEB` alimente `website_detected` et sert d'entree pour la collecte du site officiel.

## Commandes utiles

Depuis le dossier `C:\Users\Dou\Desktop\Projet`:

```bash
python Data\scraper_mvp.py --input "Data\input\liste URL_KOMPASS.xlsx" --output "Data\output_data_1000_worker8_latest" --limit 1000 --workers 8
```

Pour continuer plus loin dans le fichier:

```bash
python Data\scraper_mvp.py --input "Data\input\liste URL_KOMPASS.xlsx" --output "Data\output_data_part2" --start 1001 --limit 1000 --workers 8
```

Pour tester un seul lien:

```bash
python Data\scraper_mvp.py --url "https://www.exemple.fr" --output "Data\output_data_url_test"
```

## Sorties generees

Chaque run produit:

- `entreprises.db`: base SQLite principale;
- `entreprises.csv`: export complet;
- `entreprises.xlsx`: export lisible dans Excel;
- `errors.csv`: lignes bloquees, incompletes ou en erreur;
- `quality_summary.json`: indicateurs de couverture;
- `run_report.md`: rapport de run.

La base SQLite contient:

- `companies_raw`: une ligne par entreprise;
- `pages`: pages visitees et statut de collecte;
- `run_events`: evenements du run.

## Champs importants

### Identification

- `input_id`: identifiant interne de la ligne.
- `source_url`: lien source principal.
- `domain`: domaine principal.
- `source_page_type`: type de source detectee.
- `company_name`: nom de l'entreprise.

### Site officiel

- `site_status`: statut de collecte du site officiel.
- `site_pages_ok`: nombre de pages du site lues avec succes.
- `site_activity_text`: phrases liees a l'activite.
- `site_products_services_text`: produits et services trouves sur le site.
- `site_detailed_business_text`: texte metier consolide du site.
- `site_contact_text`: coordonnees trouvees.
- `site_admin_text`: mentions administratives utiles.
- `site_urls_collected`: URL du site effectivement collectees.

### Kompass

- `kompass_status`: statut de collecte Kompass.
- `kompass_pages_ok`: nombre de pages Kompass collectees.
- `kompass_activity_text`: description Kompass si disponible dans un cadre autorise.
- `kompass_activities_main_text`: activites principales Kompass si disponibles.
- `kompass_activities_secondary_text`: activites secondaires Kompass si disponibles.
- `kompass_products_services_text`: produits/services Kompass si disponibles.
- `kompass_urls_collected`: URL Kompass collectees.

Le script respecte `robots.txt`. Si une page Kompass est interdite a la collecte automatique, elle est marquee comme bloquee au lieu d'etre forcee. Pour collecter proprement ces pages, il faut une API, un export, une autorisation client ou des fichiers HTML fournis.

### Informations metier

- `company_description`: description courte construite a partir des sources disponibles.
- `parc_machine_text`: machines, equipements, ateliers, lignes de production.
- `clients_identified_text`: clients ou indices clients.
- `markets_text`: marches et domaines d'application.
- `clients_markets_text`: champ de compatibilite combinant clients et marches.
- `certifications_text`: certifications, normes, labels.
- `classifications_text`: classifications ou codes metier.
- `business_text`: texte metier consolide destine au module CLEAN puis a l'IA.
- `business_text_quality_score`: score indicatif de qualite du texte metier.

### Controle qualite

- `scrape_status`: `ok`, `blocked_robots`, `error`, etc.
- `http_status`: code HTTP quand il existe.
- `robots_allowed`: 1 si la collecte est autorisee par `robots.txt`, 0 sinon.
- `pages_ok`: nombre de pages collectees.
- `pages_error`: nombre de pages en erreur.
- `pages_blocked_robots`: nombre de pages bloquees par `robots.txt`.
- `fetched_at`: date de collecte.

## Resultat du dernier test

Dernier run DATA effectue:

```text
Data/output_data_1000_worker8_latest
```

Parametres:

- 1000 entreprises;
- 8 workers;
- entree: `Data/input/liste URL_KOMPASS.xlsx`.

Resultats observes:

- total: 1000 lignes;
- `ok`: 815;
- `blocked_robots`: 176;
- `error`: 9;
- `company_name`: 1000/1000;
- `city`: 1000/1000;
- `website_detected`: 1000/1000;
- `company_description`: 1000/1000;
- `business_text`: 998/1000;
- longueur moyenne de `business_text`: environ 3051 caracteres.

## Role du module DATA

DATA collecte, structure et trace les sources. Il ne fait pas la classification IA. La classification, les secteurs, les sous-secteurs, la chaine de valeur et les priorites sont traites ensuite par le module IA, apres nettoyage par le module CLEAN.
