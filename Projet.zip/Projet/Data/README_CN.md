# Projet G1/G2 - DATA 模块说明

这个文件夹是项目的 DATA 部分，负责抓取和结构化企业数据。

它的目标不是只生成一个 Excel，而是做一个可复用的数据采集工具：

```text
输入链接或链接文件
-> 自动访问可访问网页
-> 提取并整理有用企业信息
-> 生成 SQLite 数据库
-> 导出 CSV 和 Excel
-> 生成质量报告
```

## 主要文件

```text
Data/
  scraper_mvp.py        DATA 主脚本
  requirements.txt      Python 依赖
  config.json           配置说明
  input/                输入文件
  output_.../           运行结果
```

这个脚本可以直接用 Python 运行，不需要 Codex。

## 支持的输入

DATA 模块支持：

- Excel 文件 `.xlsx`;
- CSV 文件 `.csv`;
- TXT 文件 `.txt`，一行一个链接;
- 命令行直接输入一个或多个 `--url`。

项目主要测试输入文件是：

```text
Data/input/liste URL_KOMPASS.xlsx
```

客户 Excel 的 `Base` 表里有 5 列：

- `LIEN KOMPASS`
- `RAISON SOCIALE`
- `LOCALISATION`
- `ACTIVTE`
- `SITE WEB`

这 5 列不会被机械地原样复制成 5 个最终字段，而是被整合进我们的结构：

- `LIEN KOMPASS` 用作来源链接和 Kompass 参考。
- `RAISON SOCIALE` 进入 `company_name`。
- `LOCALISATION` 尽量解析到 `city`，必要时也补充 `postal_code` 和 `country`。
- `ACTIVTE` 进入 `company_description` 和 `business_text`。
- `SITE WEB` 进入 `website_detected`，并作为官网抓取入口。

## 常用命令

在 `C:\Users\Dou\Desktop\Projet` 中运行：

```bash
python Data\scraper_mvp.py --input "Data\input\liste URL_KOMPASS.xlsx" --output "Data\output_data_1000_worker8_latest" --limit 1000 --workers 8
```

如果要从第 1001 行继续跑：

```bash
python Data\scraper_mvp.py --input "Data\input\liste URL_KOMPASS.xlsx" --output "Data\output_data_part2" --start 1001 --limit 1000 --workers 8
```

如果只测试一个链接：

```bash
python Data\scraper_mvp.py --url "https://www.exemple.fr" --output "Data\output_data_url_test"
```

## 输出文件

每次运行会生成：

- `entreprises.db`：SQLite 数据库；
- `entreprises.csv`：完整 CSV；
- `entreprises.xlsx`：Excel 文件；
- `errors.csv`：失败、被阻止或不完整的链接；
- `quality_summary.json`：质量指标；
- `run_report.md`：运行报告。

SQLite 数据库里有三张主要表：

- `companies_raw`：每个企业一行；
- `pages`：实际访问过的页面记录；
- `run_events`：运行事件记录。

## 主要字段

### 识别字段

- `input_id`：内部编号。
- `source_url`：主要输入链接。
- `domain`：主域名。
- `source_page_type`：来源类型。
- `company_name`：公司名。

### 官网字段

- `site_status`：官网抓取状态。
- `site_pages_ok`：成功读取的官网页面数量。
- `site_activity_text`：官网里的活动描述。
- `site_products_services_text`：官网里的产品和服务文本。
- `site_detailed_business_text`：官网综合业务文本。
- `site_contact_text`：联系方式相关文本。
- `site_admin_text`：官网里的行政或法律信息。
- `site_urls_collected`：实际访问过的官网 URL。

### Kompass 字段

- `kompass_status`：Kompass 抓取状态。
- `kompass_pages_ok`：成功读取的 Kompass 页面数。
- `kompass_activity_text`：Kompass 活动描述。
- `kompass_activities_main_text`：Kompass 主营活动。
- `kompass_activities_secondary_text`：Kompass 次要活动。
- `kompass_products_services_text`：Kompass 产品或服务。
- `kompass_urls_collected`：实际处理过的 Kompass URL。

脚本遵守 `robots.txt`。如果 Kompass 页面不允许自动抓取，脚本会记录为 blocked，而不是强行绕过。要完整抓取 Kompass 详情页，需要 API、授权、官方导出或客户提供的 HTML 文件。

### 业务文本字段

- `company_description`：企业短描述，由可用来源整理而来。
- `parc_machine_text`：机器、设备、车间、生产线等文本。
- `clients_identified_text`：客户名称或客户相关证据。
- `markets_text`：市场、应用行业、目标领域。
- `clients_markets_text`：客户和市场的兼容合并字段。
- `certifications_text`：认证、标准、标签。
- `classifications_text`：分类、代码、行业标签。
- `business_text`：给 CLEAN 和 IA 使用的综合业务文本。
- `business_text_quality_score`：DATA 阶段业务文本质量分。

### 质量控制字段

- `scrape_status`：抓取状态，比如 `ok`、`blocked_robots`、`error`。
- `http_status`：HTTP 状态码。
- `robots_allowed`：1 表示 robots 允许，0 表示不允许。
- `pages_ok`：成功页面数。
- `pages_error`：错误页面数。
- `pages_blocked_robots`：被 robots 阻止的页面数。
- `fetched_at`：抓取时间。

## 最近一次测试结果

最新 DATA 输出目录：

```text
Data/output_data_1000_worker8_latest
```

参数：

- 1000 家企业；
- 8 个 workers；
- 输入文件：`Data/input/liste URL_KOMPASS.xlsx`。

结果：

- 总数：1000 行；
- `ok`：815；
- `blocked_robots`：176；
- `error`：9；
- `company_name`：1000/1000；
- `city`：1000/1000；
- `website_detected`：1000/1000；
- `company_description`：1000/1000；
- `business_text`：998/1000；
- `business_text` 平均长度约 3051 字符。

## DATA 的角色

DATA 只负责采集、结构化和保留来源证据。它不做 IA 分类，也不生成行业、子行业、产业链位置和优先级。这些由 CLEAN 之后的 IA 模块处理。
