# Rapport DATA Scraper

Date generation: 2026-06-14T04:43:44+00:00

## Configuration

- Input: `C:\Users\Dou\Desktop\Projet\Data\input\liste URL_KOMPASS.xlsx`
- Output: `C:\Users\Dou\Desktop\Projet\Data\output_data_1000_worker8_latest`
- SQLite: `C:\Users\Dou\Desktop\Projet\Data\output_data_1000_worker8_latest\entreprises.db`
- Max pages par lien: 5
- Timeout: 15 s
- Delai par domaine: 0.5 s
- Moteur: http
- Workers: 8
- Retries: 1
- Kompass autorise: False
- Resume: False

## Resultats

- Entreprises en base: 1000
- Statut ok: 815
- Statut erreur/bloque: 185
- Pages lues correctement: 2289
- Pages bloquees robots.txt: 992
- Duree run: 1118.85 s

## Fichiers produits

- `entreprises.db`: base SQLite avec `companies_raw`, `pages`, `run_events`.
- `entreprises.csv`: export principal.
- `entreprises.xlsx`: export Excel si openpyxl est disponible.
- `errors.csv`: liens en erreur ou incomplets.
- `quality_summary.json`: indicateurs de couverture et qualite.
- `run_report.md`: ce rapport.

## Notes

- Le script respecte robots.txt et ne contourne pas les blocages.
- L'option `--kompass-authorized` doit etre utilisee uniquement si le client confirme disposer d'une autorisation explicite pour collecter les pages detail Kompass.
- Les champs issus du site officiel et les champs issus de Kompass sont separes.
- `site_activity_text` vient du site officiel accessible.
- `kompass_activity_text`, `kompass_activities_main_text` et `kompass_activities_secondary_text` ne sont remplis que si une source Kompass detail est accessible dans un cadre autorise.
- `business_text` est le texte metier consolide qui servira d'entree a la phase IA.
- Les phrases de navigation, cookies, mentions legales, recrutement et contact sont filtrees avant les champs metier.
- Les champs clients et marches sont separes pour eviter de melanger noms de clients et domaines d'application.
- Les valeurs absentes du texte restent vides: le scraper ne les invente pas.
