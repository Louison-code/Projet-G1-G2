# Projet G1/G2 完整使用说明

这份说明面向第一次接触项目的人。即使你不了解 Python、scraping、SQL 或 AI，也可以按照步骤运行项目。

## 1. 这个项目是做什么的

这个项目是一套自动化数据处理工具链，用来处理企业信息。

它的目标是：

1. 读取客户提供的企业链接文件。
2. 自动访问可访问的企业网页。
3. 提取企业基础信息和业务信息。
4. 保存成 SQL 数据库、CSV 和 Excel。
5. 把 Data 阶段生成的数据库交给 AI 阶段。
6. 使用本地 Mistral 模型对企业做行业分类、产业链定位、产品服务识别、技术能力识别等。
7. 输出最终的 AI 结果表和证据表。

完整流程是：

```text
客户输入文件
        ↓
Data 阶段：抓取网页、提取字段、生成数据库和表格
        ↓
entreprises.db
        ↓
AI 阶段：读取数据库、调用 Mistral、生成结构化分析结果
        ↓
companies_enriched.xlsx / evidence.xlsx / ia_results.db
```

这个项目不是图形界面软件，而是一个命令行自动化工具。用户启动一次命令后，后面的 Data 和 AI 步骤会自动衔接。

## 2. 项目总结构

项目文件夹结构如下：

```text
Projet
├── Data
│   ├── input
│   │   └── liste URL_KOMPASS.xlsx
│   ├── samples
│   │   └── sample_company.html
│   ├── scraper_mvp.py
│   ├── config.json
│   ├── requirements.txt
│   ├── README.md
│   ├── README_CN.md
│   ├── BESOINS_CLIENT_COUVERTURE.md
│   └── BENCHMARK_PARALLELISATION.md
├── AI
│   ├── prompts
│   │   └── prompt_mistral.md
│   ├── schemas
│   │   └── schema_sortie_ia.json
│   ├── pipeline_ai_mistral.py
│   ├── requirements.txt
│   ├── README.md
│   └── README_CN.md
├── run_full_pipeline.py
├── run_full_pipeline.ps1
├── setup_environment.ps1
├── RUN_FULL_PIPELINE_README.md
├── GUIDE_COMPLET_CN.md
└── GUIDE_COMPLET_FR.md
```

## 3. 根目录文件说明

### `run_full_pipeline.py`

这是项目的主入口。

它会自动执行两个阶段：

1. 运行 `Data/scraper_mvp.py`
2. 运行 `AI/pipeline_ai_mistral.py`

也就是说，正常情况下你不需要分别进入 `Data` 和 `AI` 文件夹运行脚本，只需要在项目根目录运行这个文件。

### `run_full_pipeline.ps1`

这是 Windows PowerShell 的便捷启动脚本。

它的作用是帮助 Windows 用户更容易启动 `run_full_pipeline.py`。如果项目里有 `.venv` 虚拟环境，它会优先使用 `.venv` 里的 Python；如果没有，就使用系统里的 `python`。

### `setup_environment.ps1`

这是安装环境脚本。

第一次在一台新电脑上运行项目时，先运行它。它会：

1. 创建 Python 虚拟环境 `.venv`
2. 安装 Data 阶段需要的依赖
3. 安装 AI 阶段需要的依赖

虚拟环境的意义是：项目使用自己的 Python 依赖，不污染电脑里其他 Python 项目。

### `RUN_FULL_PIPELINE_README.md`

这是简短版一键运行说明。

如果你已经理解项目，只想快速看命令，可以看这个文件。

### `GUIDE_COMPLET_CN.md`

中文完整说明，也就是你现在正在看的文件。

### `GUIDE_COMPLET_FR.md`

法语完整说明，可以发给法国同学、老师或客户看。

## 4. Data 文件夹说明

`Data` 文件夹负责第一阶段：网页抓取和数据结构化。

### `Data/input/liste URL_KOMPASS.xlsx`

这是客户提供的原始输入文件。

它包含：

- Kompass 链接
- 公司名称
- 地理位置
- 活动描述
- 企业官网链接

工具默认读取这个文件。

### `Data/scraper_mvp.py`

这是 Data 阶段的核心代码。

它负责：

1. 读取输入 Excel / CSV / TXT。
2. 访问每家企业的 Kompass 链接和企业官网链接。
3. 遵守访问限制，记录不能访问的页面。
4. 从网页文本中提取企业信息。
5. 生成 SQLite 数据库、CSV、Excel、错误文件和运行报告。

它会提取的信息包括：

- 公司名
- SIREN
- SIRET
- NAF code
- 法律形式
- 员工规模
- 地址
- 城市
- 邮编
- 邮箱
- 电话
- 企业描述
- 活动文本
- 主营活动
- 次要活动
- 产品和服务
- Kompass 产品服务分类
- 机器设备
- 客户
- 市场
- 认证
- 分类信息
- 可交给 AI 的业务文本

### `Data/config.json`

配置文件。

目前项目主要通过命令行参数控制运行，但这个文件保留给后续扩展使用。

### `Data/requirements.txt`

Data 阶段需要安装的 Python 包列表。

安装环境脚本会读取这个文件并自动安装依赖。

### `Data/README.md`

Data 阶段法语说明。

### `Data/README_CN.md`

Data 阶段中文说明。

### `Data/BESOINS_CLIENT_COUVERTURE.md`

客户需求覆盖说明。

它解释了客户需要什么，以及当前 Data 工具覆盖了哪些需求。

### `Data/BENCHMARK_PARALLELISATION.md`

并行性能测试报告。

我们测试了 `1 / 4 / 8 / 16 workers` 在同一批 100 家企业上的表现。

测试结论：

- 1 worker：420.09 秒
- 4 workers：165.53 秒
- 8 workers：125.54 秒
- 16 workers：130.85 秒

所以推荐：

- 稳妥模式：4 workers
- 快速模式：8 workers
- 不建议默认使用 16 workers，因为没有更快

### `Data/samples/sample_company.html`

本地测试用网页样例。

当没有网络或不想访问真实网站时，可以用这个样例测试解析逻辑。

## 5. AI 文件夹说明

`AI` 文件夹负责第二阶段：读取 Data 阶段的数据库，然后调用 Mistral 做结构化分析。

### `AI/pipeline_ai_mistral.py`

这是 AI 阶段的核心代码。

它负责：

1. 读取 Data 阶段生成的 `entreprises.db`。
2. 对每家公司整理适合模型读取的文本。
3. 调用本地 Mistral 模型。
4. 要求模型输出标准 JSON。
5. 解析模型结果。
6. 生成最终企业结果表。
7. 生成证据表。
8. 生成 AI 结果数据库和性能报告。

AI 会输出的字段包括：

- `secteur_ia`：AI 判断的行业大类
- `sous_secteur_ia`：AI 判断的更细行业
- `domaine_production`：具体生产或业务领域
- `chaine_valeur`：产业链位置
- `produits_services`：产品和服务
- `technologies`：技术、工艺、软件、工具
- `competences_cles`：关键能力
- `parc_machine`：机器设备
- `certifications_normes`：认证和标准
- `clients`：客户名称
- `marches`：市场或应用领域
- `prix_produits`：价格信息，如果网页里有
- `potentiel_interet`：对项目的潜在价值
- `niveau_priorite`：优先级
- `confidence`：置信度
- `evidence_resume`：判断依据摘要

### `AI/prompts/prompt_mistral.md`

这是给 Mistral 的提示词。

它规定了：

- 模型应该输出哪些字段
- 不允许编造信息
- 客户和市场必须分开
- 置信度怎么判断
- 产业链位置怎么分类
- 行业标签应该从哪些固定类别中选择

### `AI/schemas/schema_sortie_ia.json`

这是 AI 输出格式说明。

它定义了 AI 返回 JSON 时必须包含哪些字段。

### `AI/requirements.txt`

AI 阶段需要安装的 Python 包列表。

### `AI/README.md`

AI 阶段法语说明。

### `AI/README_CN.md`

AI 阶段中文说明。

## 6. 第一次使用：安装环境

### 第一步：打开 PowerShell

进入项目文件夹：

```powershell
cd C:\Users\Dou\Desktop\Projet
```

如果项目在别的位置，就把路径换成你的实际路径。

### 第二步：安装 Python 依赖

运行：

```powershell
powershell -ExecutionPolicy Bypass -File ".\setup_environment.ps1"
```

运行成功后，项目根目录会出现一个 `.venv` 文件夹。

`.venv` 是项目自己的 Python 环境。

## 7. 快速测试：不调用 Mistral

第一次运行时，建议先做 dry-run 测试。

dry-run 的意思是：AI 阶段不真正调用 Mistral，只测试 Data 和 AI 两个阶段能不能接上。

运行：

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 1 --limit 5 --ai-limit 5 --dry-run-ai --data-output ".\Data\output_test" --ai-output ".\AI\outputs_test" --overwrite-ai
```

这个命令会：

1. 只处理前 5 家企业
2. 跑 Data 阶段
3. 生成 `Data/output_test/entreprises.db`
4. 把数据库交给 AI 阶段
5. AI 阶段用 dry-run 方式输出测试结果
6. 生成 `AI/outputs_test`

如果这个测试成功，说明工具链可以运行。

## 8. 小样本真实 AI 测试

如果电脑上已经安装并启动 Ollama，并且已经下载 `mistral:latest`，可以跑真实 AI 测试。

运行：

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 1 --limit 10 --ai-limit 10 --data-output ".\Data\output_test_10" --ai-output ".\AI\outputs_test_10" --overwrite-ai
```

这个命令会：

1. 抓取前 10 家企业数据
2. 调用本地 Mistral 分析这 10 家企业
3. 生成真实 AI 结果

## 9. 跑完整 7100 家

确认小样本测试没问题后，可以跑完整文件。

推荐命令：

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 1 --workers 8 --data-output ".\Data\output_7100" --ai-output ".\AI\outputs_7100" --overwrite-ai
```

这个命令会：

1. 读取 `Data/input/liste URL_KOMPASS.xlsx`
2. 用 8 个并行 worker 运行 Data 阶段
3. 输出 `Data/output_7100`
4. 自动把 `Data/output_7100/entreprises.db` 交给 AI 阶段
5. 输出 `AI/outputs_7100`

注意：完整 AI 阶段会比较慢，因为每家公司都要调用本地 Mistral。

## 9 bis. 用 `--start` 分批继续运行

现在一键脚本支持分批处理同一个客户输入文件。

比如你可以先跑第 1 到第 100 家，再跑第 101 到第 200 家，而且结果会继续写到同一套输出文件里，不需要手动拼接。

第一批，第 1 到第 100 家：

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 1 --limit 100 --ai-limit 100 --workers 8 --data-output ".\Data\output_progress" --ai-output ".\AI\outputs_progress" --overwrite-ai
```

第二批，第 101 到第 200 家，继续追加到同一个输出目录：

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 101 --limit 100 --ai-limit 100 --workers 8 --data-output ".\Data\output_progress" --ai-output ".\AI\outputs_progress"
```

第二批不要加 `--overwrite-ai`，否则第一批已经生成的 AI 结果会被删掉。

默认情况下，AI 阶段会使用和 DATA 阶段一样的起点。也就是说 `--start 101` 会让 DATA 从客户文件第 101 行开始，也会让 IA 从同一个累计数据库里的第 101 行开始。

如果你新建了一个 DATA 输出目录，里面只包含第二批数据，那 IA 阶段应该从这个新数据库的第 1 行开始，这时需要加 `--ai-start 1`。

## 10. 常用参数说明

### `--input`

指定输入文件。

默认是：

```text
Data\input\liste URL_KOMPASS.xlsx
```

如果换了输入文件，可以这样：

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 1 --input ".\Data\input\nouveaux_liens.xlsx"
```

### `--data-output`

指定 Data 阶段输出目录。

例如：

```powershell
--data-output ".\Data\output_7100"
```

### `--ai-output`

指定 AI 阶段输出目录。

例如：

```powershell
--ai-output ".\AI\outputs_7100"
```

### `--workers`

指定 Data 阶段并行数量。

推荐：

- `--workers 4`：稳妥
- `--workers 8`：较快

不建议默认用 16，因为测试中 16 没有比 8 更快。

### `--start`

指定从客户输入文件的第几行开始处理。

例如：

```powershell
--start 101 --limit 100
```

意思是处理第 101 到第 200 家企业。

### `--limit`

限制 Data 阶段处理多少家公司。

例如只跑 100 家：

```powershell
--limit 100
```

### `--ai-start`

指定 AI 阶段从 DATA 数据库的第几行开始处理。

默认情况下，`--ai-start` 会自动等于 `--start`。

例如：

```powershell
--start 101 --limit 100 --ai-start 101 --ai-limit 100
```

如果你用的是同一个 DATA 输出目录和同一个 AI 输出目录，一般不需要手动写 `--ai-start`。

### `--ai-limit`

限制 AI 阶段处理多少家公司。

例如只跑 20 家：

```powershell
--ai-limit 20
```

### `--dry-run-ai`

测试 AI 流程，但不调用 Mistral。

适合第一次检查项目是否能跑通。

### `--overwrite-ai`

覆盖旧 AI 输出。

如果你想重新生成 AI 结果，建议加上这个参数。

## 11. Data 阶段输出文件

假设输出目录是：

```text
Data/output_7100
```

里面会生成：

### `entreprises.db`

SQLite 数据库。

这是 Data 阶段最重要的输出，因为 AI 阶段会读取这个文件。

### `entreprises.csv`

Data 阶段主结果表，CSV 格式。

适合程序处理或导入数据库。

### `entreprises.xlsx`

Data 阶段主结果表，Excel 格式。

适合人工查看。

### `errors.csv`

错误和失败链接记录。

它会记录哪些链接访问失败、被阻止或没有数据。

### `run_report.md`

Data 阶段运行报告。

它会总结：

- 处理了多少家公司
- 成功多少
- 失败多少
- 多少页面被 robots 阻止
- 运行耗时

## 12. AI 阶段输出文件

假设输出目录是：

```text
AI/outputs_7100
```

里面会生成：

### `ia_results.db`

AI 阶段 SQLite 数据库。

里面有：

- `companies_enriched`
- `evidence`
- `run_events`

### `companies_enriched.xlsx`

AI 最终企业结果表。

一家公司一行。

这是最适合给业务方查看的最终表。

### `companies_enriched.csv`

和 Excel 内容相同，但 CSV 更适合程序处理。

### `evidence.xlsx`

AI 证据表。

它解释 AI 为什么这样判断。

例如某家公司被判断为“工业制造”，证据表会尽量给出对应的文本依据。

### `evidence.csv`

证据表 CSV 版本。

### `rapport_performance_ia.md`

AI 阶段运行报告。

它会说明：

- 使用了哪个模型
- 处理了多少家公司
- 平均耗时
- 平均置信度
- 是否有错误

## 13. `blocked` 是什么意思

`blocked` 表示某些页面被网站访问规则阻止。

常见情况是 Kompass 详情页被 robots.txt 阻止。

这不一定表示整家公司完全失败。

例如：

- Kompass 页面 blocked
- 企业官网成功
- 那么这家公司仍然可能是 `ok`

只有当 Kompass 和官网都没有可用数据时，这家公司才会整体信息不足。

项目不会绕过访问限制；它会记录失败原因，然后继续处理其他可访问来源。

## 14. 为什么要有 SQL 数据库

SQL 数据库不是为了让人手写 SQL。

它的作用是：

1. 保存结构化数据
2. 方便程序继续读取
3. 记录页面状态和运行日志
4. 支持后续扩展到更多企业
5. 让 Data 和 AI 两个阶段稳定衔接

Data 阶段输出 `entreprises.db`。

AI 阶段读取 `entreprises.db`，再输出 `ia_results.db`。

## 15. 为什么说这是自动化工具

因为用户不需要手动复制 Data 输出给 AI。

运行 `run_full_pipeline.py` 后，它会自动：

1. 读取输入文件
2. 跑 Data 抓取
3. 生成 Data 数据库
4. 把 Data 数据库交给 AI
5. 调用 Mistral
6. 生成 AI 结果
7. 输出 Excel、CSV、SQL 和报告

它不是图形界面软件，而是命令行自动化工具。

## 16. 换输入文件怎么做

把新输入文件放进：

```text
Data/input
```

然后运行：

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 1 --input ".\Data\input\nouveaux_liens.xlsx" --data-output ".\Data\output_nouveau" --ai-output ".\AI\outputs_nouveau" --overwrite-ai
```

建议每一批输入使用不同输出目录。

这样方便追踪结果，不会混淆旧数据。

## 17. 常见问题

### 问题 1：`python` 不是可识别命令

说明电脑没有安装 Python，或者 Python 没有加入 PATH。

解决方法：

1. 安装 Python
2. 安装时勾选 Add Python to PATH
3. 重新打开 PowerShell

### 问题 2：缺少 `openpyxl`

说明依赖没有安装。

解决方法：

```powershell
powershell -ExecutionPolicy Bypass -File ".\setup_environment.ps1"
```

### 问题 3：AI 阶段连接不到 Mistral

说明 Ollama 没有启动，或者本地没有 `mistral:latest`。

可以先用 dry-run 测试：

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 1 --limit 5 --ai-limit 5 --dry-run-ai --overwrite-ai
```

### 问题 4：有些公司没有数据

可能原因：

- 官网打不开
- 网站超时
- robots.txt 阻止
- 页面没有有用文本
- 客户输入文件里缺少官网

这些情况会记录在 `errors.csv` 和 `run_report.md` 中。

### 问题 5：运行太慢

可以增加 workers：

```powershell
--workers 8
```

但不建议盲目增加到 16 或更多，因为测试显示 16 不一定更快。

## 18. 最推荐的操作顺序

第一次使用：

```powershell
cd C:\Users\Dou\Desktop\Projet
powershell -ExecutionPolicy Bypass -File ".\setup_environment.ps1"
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 1 --limit 5 --ai-limit 5 --dry-run-ai --data-output ".\Data\output_test" --ai-output ".\AI\outputs_test" --overwrite-ai
```

确认测试成功后，跑小样本真实 AI：

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 1 --limit 10 --ai-limit 10 --data-output ".\Data\output_test_10" --ai-output ".\AI\outputs_test_10" --overwrite-ai
```

最后跑完整文件：

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 1 --workers 8 --data-output ".\Data\output_7100" --ai-output ".\AI\outputs_7100" --overwrite-ai
```

## 19. 项目当前状态

当前项目已经完成：

- Data 工具
- AI 工具
- Data 和 AI 自动衔接
- 一键启动入口
- 环境安装脚本
- 并行性能测试
- 中文和法语说明

还需要实际运行完整数据，才能生成最终 7100 家企业的完整结果。

也就是说：

```text
工具已经完成。
完整生产数据需要运行完整 pipeline。
```
