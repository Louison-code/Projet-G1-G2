# Lancement en une commande

Ce script lance automatiquement les trois etapes:

1. DATA: scraping, extraction, base SQLite, CSV, Excel.
2. CLEAN: nettoyage des textes web et preparation de l'entree IA.
3. IA: lecture de la base SQLite nettoyee, appel Mistral, resultats enrichis, preuves, base SQLite IA.

## Installation sur un autre ordinateur

Depuis le dossier `Projet`:

```powershell
powershell -ExecutionPolicy Bypass -File ".\setup_environment.ps1"
```

Ce script cree `.venv` et installe les dependances Python.

## Test rapide en Python pur

Depuis le dossier `Projet`:

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 1 --limit 5 --ai-limit 5 --dry-run-ai --data-output ".\Data\output_pipeline_test" --ai-output ".\AI\outputs_pipeline_test" --overwrite-ai
```

## Test rapide avec le wrapper PowerShell

Depuis le dossier `Projet`:

```powershell
.\run_full_pipeline.ps1 -Start 1 -Limit 5 -AILimit 5 -DryRunAI -DataOutput ".\Data\output_pipeline_test" -AIOutput ".\AI\outputs_pipeline_test" -OverwriteAI
```

Le wrapper PowerShell utilise `.venv\Scripts\python.exe` si l'environnement virtuel existe, sinon il utilise `python`.

## Test avec Mistral local

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 1 --limit 5 --ai-limit 5 --data-output ".\Data\output_pipeline_test_mistral" --ai-output ".\AI\outputs_pipeline_test_mistral" --overwrite-ai
```

Ollama doit etre lance et le modele `mistral:latest` doit etre disponible.

## Run complet recommande

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 1 --workers 8 --data-output ".\Data\output_7100" --ai-output ".\AI\outputs_7100" --overwrite-ai
```

## Reutiliser une base DATA deja produite

Si la base DATA existe deja, par exemple apres un run complet de scraping, il est possible de ne relancer que CLEAN + IA:

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --skip-data --start 1 --limit 50 --ai-limit 50 --data-output ".\Data\output_7100_worker8_full_20260611_005759" --clean-output ".\Clean\output_test_50" --ai-output ".\AI\outputs_test_50_clean" --overwrite-ai
```

## Traitement par lots avec `--start`

Pour traiter progressivement le meme fichier d'entree, il faut garder le meme dossier DATA et le meme dossier IA.

Premier lot, lignes 1 a 100:

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 1 --limit 100 --ai-limit 100 --workers 8 --data-output ".\Data\output_progress" --ai-output ".\AI\outputs_progress" --overwrite-ai
```

Deuxieme lot, lignes 101 a 200, ajoute aux memes sorties:

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --start 101 --limit 100 --ai-limit 100 --workers 8 --data-output ".\Data\output_progress" --ai-output ".\AI\outputs_progress"
```

Important: ne pas mettre `--overwrite-ai` sur le deuxieme lot si vous voulez conserver les resultats IA du premier lot.

Par defaut, l'etape IA utilise le meme depart que DATA. Si vous utilisez un nouveau dossier DATA qui ne contient que le deuxieme lot, ajoutez `--ai-start 1`.

## Parametres utiles

- `--start 101`: commence a la ligne 101 du fichier d'entree.
- `--limit 100`: traite 100 entreprises cote DATA.
- `--ai-start 101`: commence l'IA a la ligne 101 de la base DATA. Par defaut: meme valeur que `--start`.
- `--ai-limit 100`: traite 100 entreprises cote IA.
- `--workers 8`: nombre de workers DATA. Le benchmark montre que 8 est le meilleur choix teste.
- `--clean-output`: dossier de sortie pour la base nettoyee.
- `--skip-data`: reutilise une base DATA existante sans relancer le scraping.
- `--dry-run-ai`: teste l'etape IA sans appeler Mistral.
- `--overwrite-ai`: remplace les anciens resultats IA.

## Sorties

DATA:

- `Data/output_xxx/entreprises.db`
- `Data/output_xxx/entreprises.csv`
- `Data/output_xxx/entreprises.xlsx`
- `Data/output_xxx/errors.csv`
- `Data/output_xxx/run_report.md`

CLEAN:

- `Clean/output_xxx/entreprises_clean.db`
- `Clean/output_xxx/entreprises_clean.csv`
- `Clean/output_xxx/entreprises_clean.xlsx`
- `Clean/output_xxx/clean_report.md`
- `Clean/output_xxx/run_full.log`
- `Clean/output_xxx/run_meta_full.json`

`run_full.log` contient les sorties DATA, CLEAN et IA dans un seul fichier.
`run_meta_full.json` resume les parametres, les durees, les chemins de sortie et le statut de chaque etape.

IA:

- `AI/outputs_xxx/ia_results.db`
- `AI/outputs_xxx/companies_enriched.csv`
- `AI/outputs_xxx/companies_enriched.xlsx`
- `AI/outputs_xxx/evidence.csv`
- `AI/outputs_xxx/evidence.xlsx`
- `AI/outputs_xxx/rapport_performance_ia.md`
