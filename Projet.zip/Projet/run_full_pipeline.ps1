param(
    [string]$InputFile = ".\Data\input\liste URL_KOMPASS.xlsx",
    [string]$DataOutput = ".\Data\output_full",
    [string]$AIOutput = ".\AI\outputs_full",
    [int]$Workers = 8,
    [int]$MaxPages = 4,
    [int]$Timeout = 12,
    [double]$Delay = 0.5,
    [int]$Start = 1,
    [int]$Limit = 0,
    [int]$AIStart = 0,
    [int]$AILimit = 0,
    [string]$PythonExe = "",
    [switch]$DryRunAI,
    [switch]$OverwriteAI
)

$ErrorActionPreference = "Stop"

function Resolve-ProjectPath {
    param([string]$PathValue)
    if ([System.IO.Path]::IsPathRooted($PathValue)) {
        return $PathValue
    }
    return (Join-Path $PSScriptRoot $PathValue)
}

function Invoke-Step {
    param(
        [string]$Name,
        [scriptblock]$Action
    )
    Write-Host ""
    Write-Host "================ $Name ================" -ForegroundColor Cyan
    & $Action
    if ($LASTEXITCODE -ne 0) {
        throw "$Name a echoue avec le code $LASTEXITCODE"
    }
}

$ProjectRoot = $PSScriptRoot
$PythonLauncher = Join-Path $ProjectRoot "run_full_pipeline.py"
$InputPath = Resolve-ProjectPath $InputFile
$DataOutputPath = Resolve-ProjectPath $DataOutput
$AIOutputPath = Resolve-ProjectPath $AIOutput
$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"

if (-not $PythonExe) {
    if (Test-Path -LiteralPath $VenvPython) {
        $PythonExe = $VenvPython
    }
    else {
        $PythonExe = "python"
    }
}

if (-not (Test-Path -LiteralPath $PythonLauncher)) {
    throw "Lanceur Python introuvable: $PythonLauncher"
}

$ArgsPython = @(
    $PythonLauncher,
    "--input", $InputPath,
    "--data-output", $DataOutputPath,
    "--ai-output", $AIOutputPath,
    "--workers", "$Workers",
    "--max-pages", "$MaxPages",
    "--timeout", "$Timeout",
    "--delay", "$Delay",
    "--start", "$Start",
    "--python-exe", $PythonExe
)

if ($Limit -gt 0) {
    $ArgsPython += @("--limit", "$Limit")
}
if ($AIStart -gt 0) {
    $ArgsPython += @("--ai-start", "$AIStart")
}
if ($AILimit -gt 0) {
    $ArgsPython += @("--ai-limit", "$AILimit")
}
if ($DryRunAI) {
    $ArgsPython += "--dry-run-ai"
}
if ($OverwriteAI) {
    $ArgsPython += "--overwrite-ai"
}

& $PythonExe @ArgsPython
if ($LASTEXITCODE -ne 0) {
    throw "Le pipeline complet a echoue avec le code $LASTEXITCODE"
}
