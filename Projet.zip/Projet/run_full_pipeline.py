"""
Lanceur complet DATA + IA pour le projet G1/G2.

Ce script utilise l'interpreteur Python courant
pour lancer successivement:
1. Data/scraper_mvp.py
2. Clean/prepare_ai_input.py
3. AI/pipeline_ai_mistral.py
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path


def project_root() -> Path:
    """Retourne le dossier Projet, c'est-a-dire le dossier du lanceur."""
    return Path(__file__).resolve().parent


def resolve_project_path(root: Path, value: str) -> Path:
    """Convertit un chemin relatif au projet en chemin absolu."""
    path = Path(value)
    if path.is_absolute():
        return path
    return (root / path).resolve()


def run_command(name: str, command: list[str], cwd: Path, log_path: Path) -> dict[str, object]:
    """Execute une commande en affichant et journalisant la sortie."""
    started_at = datetime.now()
    started_perf = time.perf_counter()
    print()
    print(f"================ {name} ================")
    with log_path.open("a", encoding="utf-8") as log:
        log.write(f"\n================ {name} ================\n")
        log.write(f"Debut: {started_at.isoformat(timespec='seconds')}\n")
        log.write("Commande: " + " ".join(f'"{item}"' if " " in item else item for item in command) + "\n")
        process = subprocess.Popen(
            command,
            cwd=str(cwd),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="")
            log.write(line)
        return_code = process.wait()
        ended_at = datetime.now()
        duration_seconds = time.perf_counter() - started_perf
        log.write(f"Code retour: {return_code}\n")
        log.write(f"Fin: {ended_at.isoformat(timespec='seconds')}\n")
        log.write(f"Duree secondes: {duration_seconds:.2f}\n")
    return {
        "name": name,
        "command": command,
        "cwd": str(cwd),
        "started_at": started_at.isoformat(timespec="seconds"),
        "ended_at": ended_at.isoformat(timespec="seconds"),
        "duration_seconds": round(duration_seconds, 2),
        "return_code": return_code,
    }


def write_meta(
    meta_path: Path,
    *,
    status: str,
    error: str,
    started_at: datetime,
    duration_seconds: float,
    args: argparse.Namespace,
    input_path: Path,
    data_output: Path,
    clean_output: Path,
    ai_output: Path,
    log_path: Path,
    stages: list[dict[str, object]],
) -> None:
    """Ecrit un seul fichier meta lisible pour tout le pipeline."""
    meta = {
        "status": status,
        "error": error,
        "started_at": started_at.isoformat(timespec="seconds"),
        "ended_at": datetime.now().isoformat(timespec="seconds"),
        "duration_seconds": round(duration_seconds, 2),
        "duration_minutes": round(duration_seconds / 60, 2),
        "input": str(input_path),
        "data_output": str(data_output),
        "clean_output": str(clean_output),
        "ai_output": str(ai_output),
        "log": str(log_path),
        "workers": args.workers,
        "max_pages": args.max_pages,
        "timeout": args.timeout,
        "delay": args.delay,
        "start": args.start,
        "limit": args.limit,
        "ai_start": args.ai_start,
        "ai_limit": args.ai_limit,
        "ai_timeout": args.ai_timeout,
        "dry_run_ai": args.dry_run_ai,
        "overwrite_ai": args.overwrite_ai,
        "skip_data": args.skip_data,
        "stages": stages,
    }
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    """Parse les parametres du pipeline complet."""
    parser = argparse.ArgumentParser(description="Pipeline complet DATA + IA")
    parser.add_argument("--input", default=r"Data\input\liste URL_KOMPASS.xlsx", help="Fichier d'entree")
    parser.add_argument("--data-output", default=r"Data\output_full", help="Dossier de sortie DATA")
    parser.add_argument("--clean-output", default=r"Clean\output_full", help="Dossier de sortie CLEAN")
    parser.add_argument("--ai-output", default=r"AI\outputs_full", help="Dossier de sortie IA")
    parser.add_argument("--workers", type=int, default=8, help="Nombre de workers DATA")
    parser.add_argument("--max-pages", type=int, default=4, help="Pages maximum par entreprise")
    parser.add_argument("--timeout", type=int, default=12, help="Timeout HTTP DATA")
    parser.add_argument("--delay", type=float, default=0.5, help="Delai par domaine DATA")
    parser.add_argument("--start", type=int, default=1, help="Index 1-base de depart DATA")
    parser.add_argument("--limit", type=int, default=0, help="Limite DATA pour test")
    parser.add_argument(
        "--ai-start",
        type=int,
        default=0,
        help="Index 1-base de depart IA. Par defaut: meme valeur que --start.",
    )
    parser.add_argument("--ai-limit", type=int, default=0, help="Limite IA pour test")
    parser.add_argument("--ai-timeout", type=int, default=300, help="Timeout Ollama par entreprise")
    parser.add_argument("--dry-run-ai", action="store_true", help="Teste l'IA sans appeler Mistral")
    parser.add_argument("--overwrite-ai", action="store_true", help="Remplace les resultats IA existants")
    parser.add_argument("--skip-data", action="store_true", help="Utilise une base DATA deja existante sans relancer le scraping")
    parser.add_argument("--python-exe", default=sys.executable, help="Interpreteur Python a utiliser")
    return parser.parse_args()


def main() -> int:
    """Point d'entree."""
    args = parse_args()
    if args.start < 1:
        raise ValueError("--start doit etre superieur ou egal a 1")
    ai_start = args.ai_start if args.ai_start > 0 else 1
    if ai_start < 1:
        raise ValueError("--ai-start doit etre superieur ou egal a 1")
    root = project_root()
    pipeline_started_at = datetime.now()
    pipeline_started_perf = time.perf_counter()

    input_path = resolve_project_path(root, args.input)
    data_output = resolve_project_path(root, args.data_output)
    clean_output = resolve_project_path(root, args.clean_output)
    ai_output = resolve_project_path(root, args.ai_output)
    data_output.mkdir(parents=True, exist_ok=True)
    clean_output.mkdir(parents=True, exist_ok=True)
    ai_output.mkdir(parents=True, exist_ok=True)
    log_path = clean_output / "run_full.log"
    meta_path = clean_output / "run_meta_full.json"
    data_script = root / "Data" / "scraper_mvp.py"
    clean_script = root / "Clean" / "prepare_ai_input.py"
    ai_script = root / "AI" / "pipeline_ai_mistral.py"
    data_db = data_output / "entreprises.db"
    clean_db = clean_output / "entreprises_clean.db"
    python_exe = args.python_exe
    stages: list[dict[str, object]] = []
    status = "success"
    error = ""

    print("Projet G1/G2 - Pipeline complet DATA + IA")
    print(f"Racine projet: {root}")
    print(f"Python: {python_exe}")
    print(f"Input: {input_path}")
    print(f"Sortie DATA: {data_output}")
    print(f"Sortie CLEAN: {clean_output}")
    print(f"Sortie IA: {ai_output}")
    print(f"Start DATA: {args.start}")
    print(f"Start IA: {ai_start}")
    print(f"Log: {log_path}")
    print(f"Meta: {meta_path}")

    log_path.write_text(
        "\n".join(
            [
                "Projet G1/G2 - Pipeline complet DATA + IA",
                f"Debut pipeline: {pipeline_started_at.isoformat(timespec='seconds')}",
                f"Racine projet: {root}",
                f"Python: {python_exe}",
                f"Input: {input_path}",
                f"Sortie DATA: {data_output}",
                f"Sortie CLEAN: {clean_output}",
                f"Sortie IA: {ai_output}",
                "",
            ]
        ),
        encoding="utf-8",
    )

    if not input_path.exists():
        raise FileNotFoundError(f"Fichier d'entree introuvable: {input_path}")
    if not data_script.exists():
        raise FileNotFoundError(f"Script DATA introuvable: {data_script}")
    if not clean_script.exists():
        raise FileNotFoundError(f"Script CLEAN introuvable: {clean_script}")
    if not ai_script.exists():
        raise FileNotFoundError(f"Script IA introuvable: {ai_script}")

    data_command = [
        python_exe,
        str(data_script),
        "--input",
        str(input_path),
        "--output",
        str(data_output),
        "--max-pages",
        str(args.max_pages),
        "--timeout",
        str(args.timeout),
        "--delay",
        str(args.delay),
        "--start",
        str(args.start),
        "--workers",
        str(args.workers),
        "--resume",
        "--progress-every",
        "10",
    ]
    if args.limit > 0:
        data_command.extend(["--limit", str(args.limit)])

    try:
        if args.skip_data:
            data_stage = {
                "name": "Etape DATA",
                "command": ["skip-data"],
                "cwd": str(root),
                "started_at": datetime.now().isoformat(timespec="seconds"),
                "ended_at": datetime.now().isoformat(timespec="seconds"),
                "duration_seconds": 0,
                "return_code": 0,
            }
            stages.append(data_stage)
            with log_path.open("a", encoding="utf-8") as log:
                log.write("\n================ Etape DATA ================\n")
                log.write("DATA ignoree: utilisation de la base existante.\n")
        else:
            data_stage = run_command("Etape DATA", data_command, root, log_path)
            stages.append(data_stage)
            if data_stage["return_code"] != 0:
                raise RuntimeError(f"Etape DATA a echoue avec le code {data_stage['return_code']}")

        if not data_db.exists():
            raise FileNotFoundError(f"La base DATA n'a pas ete produite: {data_db}")

        clean_command = [
            python_exe,
            str(clean_script),
            "--input",
            str(data_db),
            "--output",
            str(clean_output),
            "--start",
            str(args.start),
            "--overwrite",
        ]
        if args.limit > 0:
            clean_command.extend(["--limit", str(args.limit)])

        clean_stage = run_command("Etape CLEAN", clean_command, root, log_path)
        stages.append(clean_stage)
        if clean_stage["return_code"] != 0:
            raise RuntimeError(f"Etape CLEAN a echoue avec le code {clean_stage['return_code']}")

        if not clean_db.exists():
            raise FileNotFoundError(f"La base CLEAN n'a pas ete produite: {clean_db}")

        ai_command = [
            python_exe,
            str(ai_script),
            "--input",
            str(clean_db),
            "--output",
            str(ai_output),
            "--start",
            str(ai_start),
            "--timeout",
            str(args.ai_timeout),
        ]
        if args.ai_limit > 0:
            ai_command.extend(["--limit", str(args.ai_limit)])
        if args.dry_run_ai:
            ai_command.append("--dry-run")
        if args.overwrite_ai:
            ai_command.append("--overwrite")

        ai_stage = run_command("Etape IA", ai_command, root, log_path)
        stages.append(ai_stage)
        if ai_stage["return_code"] != 0:
            raise RuntimeError(f"Etape IA a echoue avec le code {ai_stage['return_code']}")
    except Exception as exc:
        status = "failed"
        error = str(exc)
        raise
    finally:
        write_meta(
            meta_path,
            status=status,
            error=error,
            started_at=pipeline_started_at,
            duration_seconds=time.perf_counter() - pipeline_started_perf,
            args=args,
            input_path=input_path,
            data_output=data_output,
            clean_output=clean_output,
            ai_output=ai_output,
            log_path=log_path,
            stages=stages,
        )

    print()
    print("Pipeline termine avec succes.")
    print(f"Base DATA: {data_db}")
    print(f"Base CLEAN: {clean_db}")
    print(f"Resultats IA: {ai_output}")
    print(f"Log: {log_path}")
    print(f"Meta: {meta_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
