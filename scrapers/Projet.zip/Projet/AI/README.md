# Pipeline IA Mistral - Projet G1/G2

Ce dossier contient la deuxieme etape du projet: l'enrichissement automatique par IA.

## Role

Le pipeline lit les donnees produites par le pipeline DATA, prepare un texte utile pour chaque entreprise, appelle un modele local Mistral via Ollama, puis genere:

- `outputs/companies_enriched.csv`
- `outputs/companies_enriched.xlsx`
- `outputs/evidence.csv`
- `outputs/evidence.xlsx`
- `outputs/ia_results.db`
- `outputs/rapport_performance_ia.md`

## Entree attendue

Par defaut, le script lit:

`../Data/output_test_100/entreprises.db`

Le format prioritaire est donc la base SQL SQLite produite par l'etape DATA. Le pipeline peut aussi lire un fichier CSV ou XLSX produit par l'etape DATA, mais le mode SQL est recommande pour garder une chaine automatisable et tracable.

Important: le pipeline IA traite toutes les entreprises presentes dans la base, pas seulement les lignes `ok`. Une ligne `blocked_robots`, `error` ou `partial` doit aussi etre conservee, car elle permet de produire un statut IA explicite et de montrer que l'information source est insuffisante.

## Commande de test sans modele

Cette commande verifie toute la chaine sans appeler Mistral:

```powershell
python pipeline_ai_mistral.py --dry-run --limit 5 --overwrite
```

## Commande avec Mistral local

Ollama doit etre lance et le modele `mistral:latest` doit etre disponible.

```powershell
python pipeline_ai_mistral.py --limit 10 --overwrite
```

Pour reprendre sans supprimer les resultats existants:

```powershell
python pipeline_ai_mistral.py --start 11 --limit 100
```

## Principe automatique

1. Le pipeline DATA collecte et structure les donnees dans SQLite.
2. Le pipeline IA lit toutes les lignes de la base SQL.
3. Le pipeline IA selectionne les champs metier utiles.
4. Il limite le texte envoye au modele pour eviter les prompts trop longs.
5. Mistral renvoie un JSON normalise.
6. Le pipeline sauvegarde les resultats en SQL, CSV et Excel.
7. Les preuves sont sauvegardees dans une table separee.

## Limite importante

L'IA ne remplace pas le scraping. Elle ne doit pas inventer une activite, une machine, un client ou une certification. Si le texte source ne contient pas l'information, le champ doit rester vide.
