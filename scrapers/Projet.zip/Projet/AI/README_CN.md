# Mistral IA 自动化流程 - Projet G1/G2

这个文件夹是项目第二阶段：AI 自动分析。

## 它做什么

它读取第一阶段 DATA 生成的数据库或表格，自动整理每家企业的业务文本，然后调用本地 Mistral 模型，输出结构化的 AI 结果。

输出包括：

- `outputs/companies_enriched.csv`
- `outputs/companies_enriched.xlsx`
- `outputs/evidence.csv`
- `outputs/evidence.xlsx`
- `outputs/ia_results.db`
- `outputs/rapport_performance_ia.md`

## 默认输入

默认读取：

`../Data/output_test_100/entreprises.db`

也就是说，第二阶段优先使用第一阶段生成的 SQL/SQLite 数据库。它也可以读取 DATA 阶段生成的 CSV 或 XLSX，但正式自动化流程建议用 SQL 数据库。

重要：AI 阶段会处理数据库里的所有企业，不只处理 `ok`。如果某家公司是 `blocked_robots`、`error` 或信息很少，也应该进入 AI 流程，因为最后结果需要显示“信息不足”或“无法可靠判断”，而不是直接丢掉。

## 不调用模型的测试命令

用于检查整个流程能不能跑通：

```powershell
python pipeline_ai_mistral.py --dry-run --limit 5 --overwrite
```

## 调用本地 Mistral 的命令

需要先启动 Ollama，并且本地已经有 `mistral:latest`。

```powershell
python pipeline_ai_mistral.py --limit 10 --overwrite
```

## 为什么这叫自动化

因为你不需要手动把 Excel 丢给聊天框。程序会自动完成：

1. 读取 DATA 阶段生成的 SQL 数据库。
2. 处理数据库里的所有企业行。
3. 选择最适合喂给模型的业务文本。
4. 调用本地 Mistral。
5. 解析 JSON。
6. 输出 SQL 数据库、CSV、Excel、证据表和性能报告。

## 注意

AI 不能凭空判断。它只能根据第一阶段抓到的文本来判断行业、产业链位置、产品服务、技术、设备、认证、客户和市场。
