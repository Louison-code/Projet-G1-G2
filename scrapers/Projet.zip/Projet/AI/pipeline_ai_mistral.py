"""
Pipeline IA local pour le projet G1/G2.

Entree:
- une base SQLite ou un fichier CSV/XLSX produit par le pipeline DATA

Sorties:
- outputs/companies_enriched.csv
- outputs/companies_enriched.xlsx
- outputs/evidence.csv
- outputs/evidence.xlsx
- outputs/ia_results.db
- outputs/rapport_performance_ia.md
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sqlite3
import statistics
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.error import URLError
from urllib.request import Request, urlopen


BASE_FIELDS = [
    "input_id",
    "company_name",
    "siren",
    "siret",
    "naf_code",
    "legal_form",
    "effectifs",
    "capital",
    "address",
    "postal_code",
    "city",
    "country",
    "emails",
    "phones",
    "fax",
    "website_detected",
    "source_url",
    "domain",
    "source_page_type",
    "scrape_status",
    "pages_ok",
    "pages_error",
    "pages_blocked_robots",
    "fetched_at",
]

IA_FIELDS = [
    "secteur_ia",
    "sous_secteur_ia",
    "domaine_production",
    "chaine_valeur",
    "produits_services",
    "technologies",
    "competences_cles",
    "parc_machine",
    "certifications_normes",
    "clients",
    "marches",
    "prix_produits",
    "potentiel_interet",
    "niveau_priorite",
    "confidence",
    "statut_ia",
    "evidence_resume",
]

TECH_FIELDS = [
    "texte_llm_length",
    "texte_tronque",
    "modele_ia",
    "date_traitement_ia",
    "duree_traitement_s",
    "prompt_chars",
    "output_chars",
    "erreur_ia",
]

COMPANY_FIELDS = BASE_FIELDS + IA_FIELDS + TECH_FIELDS

EVIDENCE_FIELDS = [
    "input_id",
    "company_name",
    "champ",
    "valeur_ia",
    "evidence_text",
    "source_url",
    "confidence",
]

LIST_FIELDS = {
    "produits_services",
    "technologies",
    "competences_cles",
    "parc_machine",
    "certifications_normes",
    "clients",
    "marches",
}

REQUIRED_IA_FIELDS = [
    "secteur_ia",
    "sous_secteur_ia",
    "domaine_production",
    "chaine_valeur",
    "produits_services",
    "technologies",
    "competences_cles",
    "parc_machine",
    "certifications_normes",
    "clients",
    "marches",
    "prix_produits",
    "potentiel_interet",
    "niveau_priorite",
    "confidence",
    "evidence_resume",
    "evidences",
]

TEXT_FIELDS = [
    ("Description societe", "company_description"),
    ("Role", "company_role"),
    ("Activite", "activity_text"),
    ("Activites principales", "activities_main_text"),
    ("Activites secondaires", "activities_secondary_text"),
    ("Produits et services", "products_services_text"),
    ("Produits et services Kompass", "kompass_products_services_text"),
    ("Parc machine", "parc_machine_text"),
    ("Clients identifies", "clients_identified_text"),
    ("Marches", "markets_text"),
    ("Clients et marches", "clients_markets_text"),
    ("Certifications", "certifications_text"),
    ("Classifications", "classifications_text"),
    ("Texte metier detaille", "detailed_business_text"),
]

POSITIVE_KEYWORDS = {
    "activite": 4,
    "specialise": 6,
    "specialisee": 6,
    "fabrication": 8,
    "production": 8,
    "produit": 5,
    "produits": 5,
    "service": 4,
    "services": 4,
    "solution": 4,
    "solutions": 4,
    "conception": 6,
    "developpement": 5,
    "ingenierie": 6,
    "maintenance": 6,
    "usinage": 9,
    "chaudronnerie": 9,
    "soudure": 7,
    "assemblage": 7,
    "mecanique": 7,
    "electronique": 7,
    "electrique": 6,
    "automatisme": 8,
    "automatisation": 8,
    "robotique": 9,
    "machine": 8,
    "machines": 8,
    "equipement": 7,
    "equipements": 7,
    "parc machine": 10,
    "logiciel": 5,
    "informatique industrielle": 8,
    "capteur": 6,
    "capteurs": 6,
    "plasturgie": 8,
    "injection": 7,
    "traitement de surface": 9,
    "certification": 8,
    "certifie": 7,
    "iso": 8,
    "norme": 6,
    "aeronautique": 7,
    "automobile": 6,
    "defense": 7,
    "medical": 6,
    "energie": 6,
    "agroalimentaire": 6,
    "chimie": 6,
    "logistique": 4,
}

NEGATIVE_KEYWORDS = {
    "cookie": 8,
    "cookies": 8,
    "copyright": 7,
    "politique de confidentialite": 8,
    "conditions generales": 7,
    "mentions legales": 6,
    "newsletter": 6,
    "facebook": 5,
    "linkedin": 5,
    "instagram": 5,
    "twitter": 5,
    "plan du site": 5,
}


def clean_text(value: Any) -> str:
    """Nettoie un texte sans changer son sens."""
    if value is None:
        return ""
    text = str(value).replace("\ufeff", " ")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def now_iso() -> str:
    """Renvoie la date UTC lisible par machine."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def read_csv_rows(path: Path) -> list[dict[str, str]]:
    """Charge un CSV en dictionnaires."""
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def read_xlsx_rows(path: Path) -> list[dict[str, str]]:
    """Charge un XLSX sans imposer de dependance forte au reste du pipeline."""
    try:
        import openpyxl
    except ImportError as exc:
        raise RuntimeError("openpyxl est requis pour lire les fichiers XLSX") from exc

    workbook = openpyxl.load_workbook(path, read_only=True, data_only=True)
    sheet = workbook.active
    headers = [clean_text(cell.value) for cell in next(sheet.iter_rows(min_row=1, max_row=1))]
    rows: list[dict[str, str]] = []
    for values in sheet.iter_rows(min_row=2, values_only=True):
        row = {headers[index]: clean_text(value) for index, value in enumerate(values) if index < len(headers)}
        rows.append(row)
    return rows


def read_sqlite_rows(path: Path) -> list[dict[str, str]]:
    """Charge la table companies_raw produite par le pipeline DATA."""
    connection = sqlite3.connect(path)
    connection.row_factory = sqlite3.Row
    try:
        cursor = connection.execute("SELECT * FROM companies_raw ORDER BY input_id")
        return [dict(row) for row in cursor.fetchall()]
    finally:
        connection.close()


def read_input_rows(path: Path) -> list[dict[str, str]]:
    """Charge le fichier d'entree quel que soit son format supporte."""
    suffix = path.suffix.lower()
    if suffix == ".db":
        return read_sqlite_rows(path)
    if suffix == ".csv":
        return read_csv_rows(path)
    if suffix in {".xlsx", ".xlsm"}:
        return read_xlsx_rows(path)
    raise ValueError(f"Format d'entree non supporte: {path.suffix}")


def csv_value(value: Any) -> str:
    """Convertit une valeur complexe en cellule CSV."""
    if value is None:
        return ""
    if isinstance(value, list):
        return "; ".join(clean_text(item) for item in value if clean_text(item))
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False)
    return clean_text(value)


def append_csv(path: Path, fields: list[str], row: dict[str, Any]) -> None:
    """Ajoute une ligne CSV en creant l'en-tete si necessaire."""
    path.parent.mkdir(parents=True, exist_ok=True)
    exists = path.exists() and path.stat().st_size > 0
    with path.open("a", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        if not exists:
            writer.writeheader()
        writer.writerow({field: csv_value(row.get(field, "")) for field in fields})


def existing_done_ids(path: Path) -> set[str]:
    """Retourne les ids deja traites correctement."""
    if not path.exists() or path.stat().st_size == 0:
        return set()
    done: set[str] = set()
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            if row.get("statut_ia") in {"ok", "dry_run"}:
                done.add(row.get("input_id", ""))
    return done


def normalize_input_id(row: dict[str, Any], index: int) -> str:
    """Construit un identifiant stable si l'entree n'en contient pas."""
    for key in ("input_id", "company_id", "id_ia", "id"):
        value = clean_text(row.get(key))
        if value:
            return value
    return f"ENT_{index:06d}"


def score_text(text: str) -> int:
    """Score un morceau de texte pour garder les passages utiles au modele."""
    low = text.lower()
    score = 0
    for keyword, weight in POSITIVE_KEYWORDS.items():
        if keyword in low:
            score += weight
    for keyword, weight in NEGATIVE_KEYWORDS.items():
        if keyword in low:
            score -= weight
    score += min(len(text) // 200, 8)
    return score


def split_chunks(text: str, max_chunk_chars: int = 700) -> list[str]:
    """Decoupe le texte brut en morceaux courts et lisibles."""
    text = clean_text(text)
    if not text:
        return []
    parts = re.split(r"(?<=[.!?])\s+|[\r\n]+", text)
    chunks: list[str] = []
    current = ""
    for part in parts:
        part = clean_text(part)
        if not part:
            continue
        if len(current) + len(part) + 1 <= max_chunk_chars:
            current = f"{current} {part}".strip()
        else:
            if current:
                chunks.append(current)
            current = part[:max_chunk_chars]
    if current:
        chunks.append(current)
    return chunks


def dedupe_keep_order(values: list[str]) -> list[str]:
    """Supprime les doublons simples en gardant l'ordre."""
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        normalized = clean_text(value).lower()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        result.append(clean_text(value))
    return result


def build_llm_text(row: dict[str, Any], max_chars: int) -> tuple[str, bool]:
    """Prepare le texte d'entree IA a partir des champs metier utiles."""
    header_lines = [
        f"Entreprise: {clean_text(row.get('company_name'))}",
        f"URL source: {clean_text(row.get('source_url'))}",
        f"Site detecte: {clean_text(row.get('website_detected'))}",
        f"Statut scraping: {clean_text(row.get('scrape_status'))}",
    ]

    sections: list[str] = []
    used_values: list[str] = []
    for label, field in TEXT_FIELDS:
        value = clean_text(row.get(field))
        if not value:
            continue
        used_values.append(value)
        sections.append(f"{label}:\n{value}")

    base_text = "\n\n".join(header_lines + sections)
    if len(base_text) <= max_chars:
        return base_text, False

    # Si le texte structure est trop long, on garde d'abord les champs courts,
    # puis les meilleurs extraits du texte brut.
    raw_text = clean_text(row.get("raw_text"))
    raw_chunks = split_chunks(raw_text)
    ranked_chunks = sorted(raw_chunks, key=score_text, reverse=True)

    compact_sections: list[str] = []
    for label, field in TEXT_FIELDS:
        if field == "raw_text":
            continue
        value = clean_text(row.get(field))
        if value and len(value) <= 1200:
            compact_sections.append(f"{label}:\n{value}")

    selected = dedupe_keep_order(compact_sections)
    current = "\n\n".join(header_lines + selected)
    for chunk in ranked_chunks:
        block = f"Extrait utile:\n{chunk}"
        if block.lower() in current.lower():
            continue
        candidate = f"{current}\n\n{block}" if current else block
        if len(candidate) > max_chars:
            continue
        current = candidate
        if len(current) >= int(max_chars * 0.92):
            break

    if len(current) > max_chars:
        current = current[:max_chars].rsplit(" ", 1)[0]
    return current, True


def load_prompt(path: Path) -> str:
    """Charge le prompt systeme."""
    return path.read_text(encoding="utf-8").strip()


def extract_json(text: str) -> dict[str, Any]:
    """Extrait le premier objet JSON de la reponse du modele."""
    text = clean_text(text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        return json.loads(text[start : end + 1])
    raise ValueError("La reponse ne contient pas d'objet JSON valide")


def normalize_list(value: Any) -> list[str]:
    """Normalise un champ liste."""
    if value is None or value == "":
        return []
    if isinstance(value, list):
        return [clean_text(item) for item in value if clean_text(item)][:8]
    if isinstance(value, str):
        parts = re.split(r"[;,\n]+", value)
        return [clean_text(item) for item in parts if clean_text(item)][:8]
    return [clean_text(value)]


def normalize_result(data: dict[str, Any]) -> dict[str, Any]:
    """Complete et securise le JSON renvoye par le modele."""
    result: dict[str, Any] = {}
    for field in REQUIRED_IA_FIELDS:
        if field == "evidences":
            continue
        value = data.get(field, [] if field in LIST_FIELDS else "")
        if field in LIST_FIELDS:
            result[field] = normalize_list(value)
        elif field == "confidence":
            try:
                confidence = float(value)
            except (TypeError, ValueError):
                confidence = 0.0
            result[field] = max(0.0, min(1.0, confidence))
        else:
            result[field] = clean_text(value)
    evidences = data.get("evidences", [])
    result["evidences"] = evidences if isinstance(evidences, list) else []
    return result


def call_ollama(
    ollama_url: str,
    model: str,
    system_prompt: str,
    company_text: str,
    timeout: int,
    temperature: float,
) -> tuple[dict[str, Any], str]:
    """Appelle Ollama en local et renvoie le JSON IA."""
    prompt = (
        f"{system_prompt}\n\n"
        "Texte entreprise a analyser:\n"
        "-----------------------------\n"
        f"{company_text}\n"
        "-----------------------------\n"
        "Reponds uniquement avec le JSON demande."
    )
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": False,
        "format": "json",
        "options": {"temperature": temperature},
    }
    request = Request(
        f"{ollama_url.rstrip('/')}/api/generate",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urlopen(request, timeout=timeout) as response:
        raw = response.read().decode("utf-8", errors="replace")
    envelope = json.loads(raw)
    model_response = envelope.get("response", "")
    return normalize_result(extract_json(model_response)), model_response


def dry_run_result(row: dict[str, Any], company_text: str) -> dict[str, Any]:
    """Produit un resultat de test sans appeler le modele."""
    low = company_text.lower()
    if any(word in low for word in ["usinage", "fabrication", "production", "machine", "electronique"]):
        secteur = "Industrie manufacturiere"
        chaine = "Production / fabrication"
        potentiel = "moyen"
        priorite = "moyenne"
        confidence = 0.55
    else:
        secteur = "Autre / non pertinent"
        chaine = "Non determine"
        potentiel = "faible"
        priorite = "basse"
        confidence = 0.35
    evidence = clean_text(row.get("company_description")) or company_text[:220]
    return normalize_result(
        {
            "secteur_ia": secteur,
            "sous_secteur_ia": "",
            "domaine_production": "",
            "chaine_valeur": chaine,
            "produits_services": [],
            "technologies": [],
            "competences_cles": [],
            "parc_machine": [],
            "certifications_normes": [],
            "clients": [],
            "marches": [],
            "prix_produits": "",
            "potentiel_interet": potentiel,
            "niveau_priorite": priorite,
            "confidence": confidence,
            "evidence_resume": evidence[:280],
            "evidences": [],
        }
    )


def make_company_output(
    source_row: dict[str, Any],
    ia_result: dict[str, Any],
    input_id: str,
    model: str,
    status: str,
    text_length: int,
    truncated: bool,
    started_at: float,
    prompt_chars: int,
    output_chars: int,
    error: str = "",
) -> dict[str, Any]:
    """Fusionne les champs DATA et les champs IA."""
    output: dict[str, Any] = {}
    for field in BASE_FIELDS:
        if field == "input_id":
            output[field] = input_id
        elif field == "country":
            output[field] = clean_text(source_row.get(field)) or "France"
        else:
            output[field] = clean_text(source_row.get(field))
    for field in IA_FIELDS:
        if field == "statut_ia":
            output[field] = status
        else:
            output[field] = ia_result.get(field, [] if field in LIST_FIELDS else "")
    output.update(
        {
            "texte_llm_length": str(text_length),
            "texte_tronque": "TRUE" if truncated else "FALSE",
            "modele_ia": model,
            "date_traitement_ia": now_iso(),
            "duree_traitement_s": f"{time.time() - started_at:.2f}",
            "prompt_chars": str(prompt_chars),
            "output_chars": str(output_chars),
            "erreur_ia": error,
        }
    )
    return output


def make_evidence_rows(company_row: dict[str, Any], ia_result: dict[str, Any]) -> list[dict[str, Any]]:
    """Construit une table evidence exploitable."""
    rows: list[dict[str, Any]] = []
    raw_evidences = ia_result.get("evidences") or []
    for item in raw_evidences:
        if not isinstance(item, dict):
            continue
        rows.append(
            {
                "input_id": company_row.get("input_id", ""),
                "company_name": company_row.get("company_name", ""),
                "champ": clean_text(item.get("champ") or item.get("field")),
                "valeur_ia": csv_value(item.get("valeur") or item.get("value")),
                "evidence_text": clean_text(item.get("evidence") or item.get("texte")),
                "source_url": company_row.get("source_url", ""),
                "confidence": company_row.get("confidence", ""),
            }
        )

    if not rows and clean_text(company_row.get("evidence_resume")):
        rows.append(
            {
                "input_id": company_row.get("input_id", ""),
                "company_name": company_row.get("company_name", ""),
                "champ": "resume",
                "valeur_ia": "",
                "evidence_text": clean_text(company_row.get("evidence_resume")),
                "source_url": company_row.get("source_url", ""),
                "confidence": company_row.get("confidence", ""),
            }
        )
    return rows


def init_output_db(path: Path) -> sqlite3.Connection:
    """Cree la base SQLite de sortie IA."""
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path)
    company_cols = ", ".join(f'"{field}" TEXT' for field in COMPANY_FIELDS)
    evidence_cols = ", ".join(f'"{field}" TEXT' for field in EVIDENCE_FIELDS)
    connection.execute(f"CREATE TABLE IF NOT EXISTS companies_enriched ({company_cols}, PRIMARY KEY(input_id))")
    connection.execute(f"CREATE TABLE IF NOT EXISTS evidence ({evidence_cols})")
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS run_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            input_id TEXT,
            status TEXT,
            message TEXT,
            created_at TEXT
        )
        """
    )
    connection.commit()
    return connection


def replace_company_db(connection: sqlite3.Connection, row: dict[str, Any]) -> None:
    """Insere ou remplace une entreprise enrichie."""
    placeholders = ", ".join("?" for _ in COMPANY_FIELDS)
    columns = ", ".join(f'"{field}"' for field in COMPANY_FIELDS)
    values = [csv_value(row.get(field, "")) for field in COMPANY_FIELDS]
    connection.execute(f"INSERT OR REPLACE INTO companies_enriched ({columns}) VALUES ({placeholders})", values)


def insert_evidence_db(connection: sqlite3.Connection, rows: list[dict[str, Any]]) -> None:
    """Insere les preuves IA."""
    if not rows:
        return
    columns = ", ".join(f'"{field}"' for field in EVIDENCE_FIELDS)
    placeholders = ", ".join("?" for _ in EVIDENCE_FIELDS)
    values = [[csv_value(row.get(field, "")) for field in EVIDENCE_FIELDS] for row in rows]
    connection.executemany(f"INSERT INTO evidence ({columns}) VALUES ({placeholders})", values)


def log_event(connection: sqlite3.Connection, input_id: str, status: str, message: str) -> None:
    """Journalise un evenement de traitement."""
    connection.execute(
        "INSERT INTO run_events (input_id, status, message, created_at) VALUES (?, ?, ?, ?)",
        (input_id, status, message, now_iso()),
    )


def export_xlsx(csv_path: Path, xlsx_path: Path) -> None:
    """Convertit un CSV de sortie en XLSX."""
    try:
        import openpyxl
    except ImportError:
        return

    if not csv_path.exists():
        return
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = csv_path.stem[:31]
    with csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
        for row_index, row in enumerate(csv.reader(handle), start=1):
            sheet.append(row)
            if row_index == 1:
                for cell in sheet[row_index]:
                    cell.font = openpyxl.styles.Font(bold=True)
    sheet.freeze_panes = "A2"
    for column_cells in sheet.columns:
        max_length = max((len(str(cell.value)) for cell in column_cells if cell.value), default=8)
        sheet.column_dimensions[column_cells[0].column_letter].width = min(max(max_length + 2, 10), 45)
    workbook.save(xlsx_path)


def write_report(output_dir: Path, rows: list[dict[str, str]], started_at: float, args: argparse.Namespace) -> None:
    """Genere un rapport court de performance IA."""
    companies_csv = output_dir / "companies_enriched.csv"
    evidence_csv = output_dir / "evidence.csv"
    total = len(rows)
    statuses: dict[str, int] = {}
    durations: list[float] = []
    confidences: list[float] = []
    truncated = 0
    for row in rows:
        status = row.get("statut_ia", "")
        statuses[status] = statuses.get(status, 0) + 1
        try:
            durations.append(float(row.get("duree_traitement_s", "0")))
        except ValueError:
            pass
        try:
            confidences.append(float(row.get("confidence", "0")))
        except ValueError:
            pass
        if row.get("texte_tronque") == "TRUE":
            truncated += 1

    report = [
        "# Rapport performance IA",
        "",
        f"- Date: {now_iso()}",
        f"- Modele: {args.model}",
        f"- Entree: {args.input}",
        f"- Sortie: {output_dir}",
        f"- Entreprises dans le fichier de sortie: {total}",
        f"- Duree totale du run courant: {time.time() - started_at:.1f} s",
        f"- Mode dry-run: {args.dry_run}",
        "",
        "## Statuts IA",
    ]
    for status, count in sorted(statuses.items()):
        report.append(f"- {status or 'vide'}: {count}")
    report.extend(
        [
            "",
            "## Mesures",
            f"- Duree moyenne par entreprise: {statistics.mean(durations):.2f} s" if durations else "- Duree moyenne par entreprise: n/a",
            f"- Confidence moyenne: {statistics.mean(confidences):.2f}" if confidences else "- Confidence moyenne: n/a",
            f"- Textes tronques: {truncated}",
            "",
            "## Fichiers generes",
            f"- {companies_csv.name}",
            "- companies_enriched.xlsx",
            f"- {evidence_csv.name}",
            "- evidence.xlsx",
            "- ia_results.db",
        ]
    )
    (output_dir / "rapport_performance_ia.md").write_text("\n".join(report), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    """Parse la ligne de commande."""
    project_root = Path(__file__).resolve().parents[1]
    default_input = project_root / "Data" / "output_test_100" / "entreprises.db"
    default_output = Path(__file__).resolve().parent / "outputs"
    default_prompt = Path(__file__).resolve().parent / "prompts" / "prompt_mistral.md"

    parser = argparse.ArgumentParser(description="Pipeline IA local Mistral pour G1/G2")
    parser.add_argument("--input", type=Path, default=default_input, help="DB/CSV/XLSX produit par DATA")
    parser.add_argument("--output", type=Path, default=default_output, help="Dossier de sortie IA")
    parser.add_argument("--prompt", type=Path, default=default_prompt, help="Prompt systeme")
    parser.add_argument("--model", default="mistral:latest", help="Modele Ollama")
    parser.add_argument("--ollama-url", default="http://127.0.0.1:11434", help="URL Ollama local")
    parser.add_argument("--start", type=int, default=1, help="Index 1-base de la premiere ligne a traiter")
    parser.add_argument("--limit", type=int, default=None, help="Nombre maximum de lignes a traiter")
    parser.add_argument("--max-chars", type=int, default=7000, help="Taille max du texte envoye au modele")
    parser.add_argument("--timeout", type=int, default=180, help="Timeout Ollama par entreprise")
    parser.add_argument("--temperature", type=float, default=0.0, help="Temperature du modele")
    parser.add_argument("--overwrite", action="store_true", help="Recree les sorties au lieu de reprendre")
    parser.add_argument("--dry-run", action="store_true", help="Teste le pipeline sans appeler Ollama")
    return parser.parse_args()


def main() -> int:
    """Point d'entree du pipeline."""
    args = parse_args()
    run_started = time.time()
    input_path = args.input.resolve()
    output_dir = args.output.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    log_dir = output_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    companies_csv = output_dir / "companies_enriched.csv"
    evidence_csv = output_dir / "evidence.csv"
    output_db = output_dir / "ia_results.db"
    progress_log = log_dir / "progress.jsonl"
    errors_log = log_dir / "errors.jsonl"

    if args.overwrite:
        for path in [companies_csv, evidence_csv, output_db, output_dir / "companies_enriched.xlsx", output_dir / "evidence.xlsx"]:
            if path.exists():
                path.unlink()

    system_prompt = load_prompt(args.prompt)
    rows = read_input_rows(input_path)
    if args.start > 1:
        rows = rows[args.start - 1 :]
    if args.limit is not None:
        rows = rows[: args.limit]

    done_ids = set() if args.overwrite else existing_done_ids(companies_csv)
    connection = init_output_db(output_db)
    processed_rows: list[dict[str, str]] = []

    try:
        for offset, source_row in enumerate(rows, start=args.start):
            input_id = normalize_input_id(source_row, offset)
            if input_id in done_ids:
                continue

            started = time.time()
            company_text, truncated = build_llm_text(source_row, args.max_chars)
            prompt_chars = len(system_prompt) + len(company_text)
            model_response = ""
            error = ""
            status = "ok"

            try:
                if args.dry_run:
                    ia_result = dry_run_result(source_row, company_text)
                    status = "dry_run"
                else:
                    ia_result, model_response = call_ollama(
                        args.ollama_url,
                        args.model,
                        system_prompt,
                        company_text,
                        args.timeout,
                        args.temperature,
                    )
            except (URLError, TimeoutError, ValueError, json.JSONDecodeError, OSError) as exc:
                ia_result = normalize_result({})
                status = "error"
                error = str(exc)

            company_row = make_company_output(
                source_row,
                ia_result,
                input_id,
                args.model,
                status,
                len(company_text),
                truncated,
                started,
                prompt_chars,
                len(model_response),
                error,
            )
            evidence_rows = make_evidence_rows(company_row, ia_result)

            append_csv(companies_csv, COMPANY_FIELDS, company_row)
            for evidence_row in evidence_rows:
                append_csv(evidence_csv, EVIDENCE_FIELDS, evidence_row)
            replace_company_db(connection, company_row)
            insert_evidence_db(connection, evidence_rows)
            log_event(connection, input_id, status, error)
            connection.commit()

            processed_rows.append({field: csv_value(company_row.get(field, "")) for field in COMPANY_FIELDS})
            with progress_log.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps({"input_id": input_id, "status": status, "created_at": now_iso()}, ensure_ascii=False) + "\n")
            if error:
                with errors_log.open("a", encoding="utf-8") as handle:
                    handle.write(json.dumps({"input_id": input_id, "error": error, "created_at": now_iso()}, ensure_ascii=False) + "\n")

            print(f"[{offset}] {input_id} {status} {time.time() - started:.1f}s")
    finally:
        connection.close()

    if companies_csv.exists():
        export_xlsx(companies_csv, output_dir / "companies_enriched.xlsx")
        all_rows = read_csv_rows(companies_csv)
    else:
        all_rows = []
    if evidence_csv.exists():
        export_xlsx(evidence_csv, output_dir / "evidence.xlsx")
    write_report(output_dir, all_rows, run_started, args)
    print(f"Termine. Sorties: {output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
