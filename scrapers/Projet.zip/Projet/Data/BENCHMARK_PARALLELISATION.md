# Benchmark de parallelisation DATA

Objectif: mesurer l'impact du nombre de workers sur le temps de scraping, sans degrader la qualite des donnees.

## Conditions de test

- Fichier d'entree: `input/liste URL_KOMPASS.xlsx`
- Echantillon: 100 premieres entreprises
- Pages maximum par entreprise: 4
- Timeout: 12 secondes
- Delai par domaine: 0,5 seconde
- Mode: HTTP, respect de `robots.txt`
- Source principale exploitee: sites web des entreprises lorsque disponibles
- Kompass page detail: testee mais non contournee si bloquee

## Resultats

| Configuration | Duree pour 100 entreprises | Temps moyen / entreprise | Acceleration vs 1 worker | Entreprises ok | Entreprises bloquees | Pages ok | Pages bloquees robots |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1 worker | 420,09 s | 4,20 s | 1,00x | 81 | 19 | 204 | 101 |
| 4 workers | 165,53 s | 1,66 s | 2,54x | 81 | 19 | 204 | 101 |
| 8 workers | 125,54 s | 1,26 s | 3,35x | 81 | 19 | 204 | 101 |
| 16 workers | 130,85 s | 1,31 s | 3,21x | 81 | 19 | 204 | 101 |

## Controle qualite

- Nombre de lignes en sortie: 100 pour les trois tests.
- Identifiants uniques: 100 pour les trois tests.
- Doublons: 0 pour les trois tests.
- Couverture metier stable:
  - `activity_text`: 81/100
  - `products_services_text`: 76/100
  - `parc_machine_text`: 58/100
  - `clients_identified_text`: 68/100
  - `markets_text`: 67/100
  - `certifications_text`: 70/100
  - `detailed_business_text`: 78/100

La parallelisation n'a donc pas degrade les indicateurs principaux sur cet echantillon.

## Interpretation

Le passage de 1 a 4 workers apporte le gain le plus important: le temps est divise par environ 2,5.

Le passage de 4 a 8 workers apporte encore un gain, mais plus faible: environ 40 secondes gagnees sur 100 entreprises, soit une acceleration supplementaire d'environ 32% du debit. Cela montre un debut de rendement decroissant: les temps reseau, les timeouts et les sites lents limitent le gain maximum.

Le test a 16 workers ne donne pas de gain supplementaire: il est legerement plus lent que 8 workers sur le meme echantillon. Cela indique que, sur cette machine et ce type de sources, 8 workers est proche du point optimal.

## Estimation pour 7 100 entreprises

Projection lineaire a partir du test de 100 entreprises:

| Configuration | Estimation 7 100 entreprises |
|---|---:|
| 1 worker | environ 8,3 h |
| 4 workers | environ 3,3 h |
| 8 workers | environ 2,5 h |
| 16 workers | environ 2,6 h |

Ces chiffres restent indicatifs: la duree reelle dependra des sites web, des timeouts, du reseau et des erreurs SSL/HTTP.

## Choix recommande

Pour un run complet sur les sites web d'entreprises, `8 workers` est le meilleur choix observe sur l'echantillon: c'est la configuration la plus rapide sans perte de qualite.

Pour un run plus conservateur, `4 workers` est un bon compromis: il apporte deja la majeure partie du gain, avec moins de charge machine et moins de risque de timeouts simultanes.

`16 workers` n'est pas recommande par defaut: il augmente la charge et ne reduit pas le temps sur ce benchmark.

Pour Kompass page detail, il ne faut pas utiliser la parallelisation comme strategie de contournement: les acces limites doivent rester journalises et non forces.

## Formulation audit

Nous avons teste la parallelisation sur le meme echantillon de 100 entreprises. Le passage de 1 a 4 workers reduit le temps de 420 s a 166 s sans perte de qualite. Le passage a 8 workers reduit encore le temps a 126 s, avec les memes taux de succes et la meme couverture de champs. Le test a 16 workers ne donne pas de gain supplementaire, avec 131 s. Nous avons donc retenu une approche parametrable: 4 workers pour un mode prudent, 8 workers pour un run rapide sur les sites web, et pas 16 par defaut car le rendement devient nul sur ce benchmark.
