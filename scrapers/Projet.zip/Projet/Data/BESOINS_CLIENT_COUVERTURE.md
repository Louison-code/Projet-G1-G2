# Besoins client et couverture du MVP DATA

Ce document reprend les points exprimes pendant la reunion du 4 juin 2026 et indique comment le MVP DATA y repond.

## Synthese courte

Le besoin n'est pas seulement de produire un Excel sur 7 100 lignes. Le besoin cible est un outil reutilisable:

```text
liste de liens Kompass / sites entreprises
  -> scraping detaille
  -> base SQLite
  -> exports CSV et Excel
  -> logs d'erreurs
  -> donnees pretes pour un enrichissement IA ulterieur
```

## Points importants de la reunion

| Besoin exprime | Interpretation technique | Couverture dans le MVP |
|---|---|---|
| Ne pas se limiter au SIREN, code postal, adresse, telephone | Conserver les champs administratifs, mais ajouter les champs metier profonds | `siren`, `siret`, `naf_code`, `legal_form`, `effectifs`, `capital`, `address`, `postal_code`, `city`, `emails`, `phones`, `fax` sont conserves. Les champs metier sont ajoutes. |
| Scraper la page detaillee Kompass, pas seulement la page liste | Prioriser description, role, activites principales/secondaires, produits/services, classifications | Champs: `source_page_type`, `company_description`, `company_role`, `activities_main_text`, `activities_secondary_text`, `kompass_products_services_text`, `classifications_text`. |
| Scraper aussi les sites internet des societes | Recuperer le texte visible du site officiel et de quelques pages internes utiles | Le crawler suit les liens internes du meme domaine avec mots-cles: activite, produits, services, parc machine, clients, contact, etc. |
| Recuperer le parc machine | Extraire les phrases contenant machines, equipements, atelier, CNC, robotique, ligne de production | Champ: `parc_machine_text`. |
| Distinguer clients et marches | Ne pas melanger noms d'entreprises clientes et secteurs/applications | Champs separes: `clients_identified_text` et `markets_text`. Ancien champ combine garde en trace: `clients_markets_text`. |
| Les prix produits sont peu exploitables | Ne pas en faire un champ central du scraper | Le MVP ne met pas le prix au centre. Il pourra etre ajoute plus tard si le texte le contient, mais ce n'est pas prioritaire. |
| Avoir une base SQL + CSV + Excel | Produire un outil, pas seulement un fichier final | Sorties: `entreprises.db`, `entreprises.csv`, `entreprises.xlsx`, `errors.csv`, `run_report.md`. |
| Pouvoir reprendre apres blocage | Supporter resume, erreurs, logs | Option `--resume`, table `run_events`, table `pages`, `errors.csv`, champs `scrape_status`, `error`, `pages_blocked_robots`. |
| Monter en charge | Preparer une architecture extensible | Options `--workers`, `--start`, `--limit`, `--delay`, `--retries`. Pour 100k/1M, il faudra renforcer monitoring et strategie anti-blocage dans un cadre autorise. |
| Eviter / comprendre les blocages Kompass | Ne pas contourner illegalement, tracer les blocages | Verification `robots.txt`; les pages interdites ou en erreur sont enregistrees. Option technique `--engine drission` pour pages dynamiques si autorise et installe. |
| Tester Kompass page 2 dans un cadre autorise | Si le client confirme une autorisation explicite, tester les pages detail a faible volume | Option `--kompass-authorized`, detection `blocked_access`, logs, SQLite, CSV/Excel. |
| Connecter ensuite l'IA | Separer donnees factuelles et enrichissement IA | La table `companies_raw` fournit les textes et champs source. La phase 2 pourra creer une table `companies_ai` reliee par `input_id`. |

## Positionnement du MVP

Ce MVP est une premiere version operationnelle, pas encore une plateforme industrielle.

Il prouve que l'on peut:

- entrer une liste de liens ;
- collecter des pages autorisees ;
- extraire les champs administratifs et metier ;
- stocker dans SQLite ;
- exporter CSV/Excel ;
- tracer erreurs et blocages ;
- preparer la connexion IA.

Il ne garantit pas encore:

- un run stable sur 100 000 ou 1 000 000 liens ;
- un contournement des protections Kompass ;
- l'extraction parfaite de toutes les rubriques Kompass si la page est fortement dynamique ou bloquee ;
- la qualite finale sans verification metier.

## Prochaine etape logique

Tester le MVP sur un petit lot reel de liens Kompass detail + sites entreprises:

1. 10 liens pour verifier les champs.
2. 100 liens pour mesurer le taux de succes.
3. 500-1000 liens pour mesurer les blocages, la vitesse et la qualite.
4. Ajuster les extracteurs selon les exemples reels de Lamotte/Carine.
