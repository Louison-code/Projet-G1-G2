# Projet G1/G2 - DATA Scraper MVP

Ce dossier contient le premier prototype de l'outil DATA.

Objectif: donner une liste de liens Kompass ou sites entreprises, puis obtenir automatiquement:

- une base SQLite `entreprises.db` ;
- un export `entreprises.csv` ;
- un export `entreprises.xlsx` ;
- un fichier `errors.csv` ;
- un rapport `run_report.md`.

## Structure

```text
Data/
  scraper_mvp.py
  config.json
  requirements.txt
  README.md
  BESOINS_CLIENT_COUVERTURE.md
  input/
    liste URL_KOMPASS.xlsx
  samples/
    sample_company.html
  output/
    entreprises.db
    entreprises.csv
    entreprises.xlsx
    errors.csv
    run_report.md
```

## Utilisation rapide

Depuis le dossier `Data`:

```powershell
python scraper_mvp.py --input "input/liste URL_KOMPASS.xlsx" --output output --resume
```

Avec un vrai fichier de liens:

```powershell
python scraper_mvp.py --input input/mes_liens.xlsx --output output --max-pages 5 --delay 0.5 --workers 4 --resume
```

Si une page est tres dynamique, il est possible de tester le moteur navigateur:

```powershell
python scraper_mvp.py --input input/mes_liens.xlsx --output output --engine drission --max-pages 3 --resume
```

Le moteur `drission` demande la librairie DrissionPage et un Chrome/Chromium utilisable.

## Mode Kompass autorise

Par defaut, le MVP respecte `robots.txt` et ne lit pas les pages Kompass detail si elles sont interdites.

Si le client confirme disposer d'une autorisation explicite pour collecter les pages detail Kompass, on peut tester:

```powershell
python scraper_mvp.py --input "input/liste URL_KOMPASS.xlsx" --output output_kompass_test --limit 5 --max-pages 1 --delay 2 --kompass-authorized
```

Ce mode ne doit pas etre utilise pour contourner un blocage. Il sert uniquement dans un cadre autorise, avec un rythme faible, des logs et une detection des pages de blocage (`blocked_access`).

Le fichier d'entree peut etre:

- `.csv` avec une colonne `url`, `lien`, `link`, `source_url`, `SITE WEB` ou `LIEN KOMPASS` ;
- `.txt` avec un lien par ligne ;
- `.xlsx` avec une colonne de lien.

## Champs principaux extraits

- `company_name`
- `source_page_type`
- `company_description`
- `company_role`
- `activity_text`
- `activities_main_text`
- `activities_secondary_text`
- `products_services_text`
- `kompass_products_services_text`
- `parc_machine_text`
- `clients_identified_text`
- `markets_text`
- `certifications_text`
- `classifications_text`
- `siren`
- `siret`
- `naf_code`
- `legal_form`
- `effectifs`
- `capital`
- `address`
- `postal_code`
- `city`
- `emails`
- `phones`
- `fax`
- `website_detected`
- `detailed_business_text`
- `source_urls_collected`
- `raw_text`
- `scrape_status`
- `error`
- `pages_ok`
- `pages_error`
- `pages_blocked_robots`

## Important

Le script respecte `robots.txt`.

S'il ne peut pas lire une page Kompass ou une page entreprise, il ne contourne pas le blocage. Il enregistre l'erreur dans `errors.csv` et dans la base SQLite.

## Base SQLite

La base contient trois tables:

- `companies_raw`: une ligne par lien d'entree ;
- `pages`: traces des pages visitees ;
- `run_events`: evenements de run.

Cette base servira ensuite de point d'entree pour la deuxieme phase IA.

## Limites du MVP

- Ce n'est pas encore un outil anti-blocage Kompass a grande echelle.
- Les champs business sont extraits par heuristiques de texte, pas par IA.
- Les donnees absentes du texte restent vides.
- Pour 100k ou 1M de liens, il faudra ajouter une strategie plus robuste: files d'attente, monitoring, gestion fine des erreurs, proxies autorises si le cadre projet le permet, et tests de charge.

## Ce qui correspond au besoin client

La reunion a montre qu'il ne faut pas se limiter aux champs administratifs.
Ces champs restent indispensables pour identifier et fiabiliser les entreprises
(`SIREN`, `SIRET`, `NAF`, adresse, ville, code postal, telephone, email, effectifs, capital).
Mais ils doivent etre completes par les champs metier qui donnent la vraie valeur d'analyse:

- description entreprise ;
- activites principales ;
- activites secondaires ;
- produits et services ;
- role producteur/distributeur/prestataire ;
- parc machine ;
- clients identifies ;
- marches cibles ;
- classifications et codifications ;
- source web et traces d'erreur.
