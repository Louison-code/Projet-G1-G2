# Projet G1/G2 - DATA 爬虫 MVP 中文说明

这个文件夹是第一阶段工具：**输入企业链接，自动抓取网页，保存 SQLite 数据库，并导出 CSV/Excel**。

它不是带界面的软件，而是一个 Python 数据采集工具。

## 快速运行

在 `Data` 文件夹里运行：

```powershell
python scraper_mvp.py --input "input/liste URL_KOMPASS.xlsx" --output output --resume
```

如果你有自己的链接文件：

```powershell
python scraper_mvp.py --input input/mes_liens.xlsx --output output --max-pages 5 --delay 0.5 --resume
```

如果需要测试动态网页，可以试：

```powershell
python scraper_mvp.py --input input/mes_liens.xlsx --output output --engine drission --max-pages 3 --resume
```

`--engine drission` 需要安装 DrissionPage，并且电脑上有可用的 Chrome/Chromium。

## Kompass 授权模式

默认情况下，工具会遵守 `robots.txt`。如果 Kompass 详情页不允许普通自动抓取，工具不会读取，而是记录错误。

如果客户明确确认他们拥有采集 Kompass 详情页的授权，可以小批量测试：

```powershell
python scraper_mvp.py --input "input/liste URL_KOMPASS.xlsx" --output output_kompass_test --limit 5 --max-pages 1 --delay 2 --kompass-authorized
```

这个模式不是用来绕过封锁的。它只用于授权场景，并且会低频访问、记录日志、识别 `blocked_access` 这种阻止页或假空页。

## 输入

可以是：

- CSV：里面有 `url`、`lien`、`link`、`source_url`、`SITE WEB` 或 `LIEN KOMPASS`；
- TXT：一行一个链接；
- Excel：有一列链接。

## 输出

运行后会生成：

- `output/entreprises.db`：SQLite 数据库；
- `output/entreprises.csv`：主数据表；
- `output/entreprises.xlsx`：Excel 版本；
- `output/errors.csv`：失败或被 robots.txt 阻止的链接；
- `output/run_report.md`：运行报告。

## 当前第一阶段做什么

它会尝试提取：

- 企业名；
- 企业描述；
- 企业角色：producteur / distributeur / prestataire 等；
- 活动描述；
- 主营活动；
- 次要活动；
- 产品/服务文本；
- Kompass 产品/服务/branch 文本；
- 设备/机器相关文本；
- 客户名称相关文本；
- 目标市场/应用行业相关文本；
- 认证/规范文本；
- 分类/编码相关文本；
- SIREN / SIRET / NAF；
- 法律形式；
- effectifs；
- capital；
- 地址、城市、邮编；
- email、电话、fax；
- 检测到的官网链接；
- 原始网页文本；
- 成功/失败/robots.txt 状态。

## 和第二阶段 IA 的关系

第一阶段只负责抓真实数据，不做行业判断。

第二阶段会读取 `entreprises.db` 或 `entreprises.csv`，再调用 Mistral 做：

- `secteur_ia`
- `sous_secteur_ia`
- `chaine_valeur`
- `produits_services`
- `technologies`
- `parc_machine`
- `clients_identifies`
- `marches_cibles`
- `potentiel_interet`
- `niveau_priorite`
- `confidence`
- `evidence_resume`

## 注意

这个 MVP 遵守 `robots.txt`。如果 Kompass 或某个企业网站不允许抓取，程序不会绕过，而是记录到错误日志。

## 为什么这样设计

会议里客户强调的不是“行政字段没用”，而是“不能只做行政字段”。
行政字段仍然必须保留，因为它们用于识别和核验企业：

- SIREN / SIRET；
- NAF；
- 地址、城市、邮编；
- 电话、email、fax；
- effectifs；
- capital；
- 法律/分类信息。

但除了这些基础骨架，还必须抓 Kompass 详情页和企业官网里的业务信息：

- description；
- activités principales / secondaires；
- produits et services；
- parc machine；
- clients；
- marchés；
- producteur / distributeur / prestataire；
- codifications。

所以第一阶段 Data 工具优先抓这些事实字段。第二阶段 IA 再在这些真实文本基础上做标准化分类。
