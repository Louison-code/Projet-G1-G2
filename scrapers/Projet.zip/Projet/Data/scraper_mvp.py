"""
Outil DATA MVP pour le projet G1/G2.

Objectif:
- lire une liste de liens Kompass ou sites entreprises ;
- collecter les pages autorisees par robots.txt ;
- extraire le texte visible et quelques champs utiles ;
- stocker les resultats dans SQLite ;
- exporter CSV, Excel, erreurs et rapport d'execution.

Ce script est volontairement autonome: il utilise surtout la bibliotheque
standard Python. L'export Excel utilise openpyxl si la librairie est disponible.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import re
import sqlite3
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime, timezone
from email.message import Message
from html.parser import HTMLParser
from pathlib import Path
from threading import Lock
from typing import Any, Iterable
from urllib import robotparser
from urllib.error import HTTPError, URLError
from urllib.parse import unquote, urldefrag, urljoin, urlparse, urlunparse
from urllib.request import Request, urlopen


USER_AGENT = "ProjetG1G2-ScraperMVP/1.0 (+academic project; respectful crawler)"
DEFAULT_TIMEOUT = 15

PAGE_KEYWORDS = (
    "about",
    "a-propos",
    "apropos",
    "qui-sommes",
    "societe",
    "entreprise",
    "activite",
    "metier",
    "expertise",
    "savoir-faire",
    "service",
    "services",
    "produit",
    "produits",
    "solution",
    "solutions",
    "industrie",
    "technologie",
    "equipement",
    "equipements",
    "machine",
    "machines",
    "atelier",
    "production",
    "fabrication",
    "certification",
    "qualite",
    "client",
    "clients",
    "marche",
    "marches",
    "application",
    "applications",
    "contact",
    "coordonnees",
    "mentions-legales",
    "mentions",
    "legal",
    "legales",
)

IGNORED_EXTENSIONS = {
    ".pdf",
    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".svg",
    ".webp",
    ".zip",
    ".rar",
    ".7z",
    ".doc",
    ".docx",
    ".xls",
    ".xlsx",
    ".ppt",
    ".pptx",
    ".mp4",
    ".mp3",
    ".avi",
    ".mov",
}

BAD_EMAIL_DOMAINS = {
    "kompass.com",
    "example.com",
}

STREET_WORDS = (
    "rue",
    "avenue",
    "av",
    "boulevard",
    "bd",
    "route",
    "chemin",
    "impasse",
    "allee",
    "allée",
    "place",
    "quai",
    "cours",
    "parc",
    "zone",
    "zi",
    "za",
    "zac",
    "lieu-dit",
)

SECTION_KEYWORDS = {
    "activity_text": (
        "activité",
        "activite",
        "métier",
        "metier",
        "spécialis",
        "specialis",
        "société",
        "societe",
        "entreprise",
        "fabrication",
        "production",
        "conception",
        "ingénierie",
        "ingenierie",
    ),
    "products_services_text": (
        "produit",
        "produits",
        "service",
        "services",
        "solution",
        "solutions",
        "offre",
        "gamme",
        "catalogue",
        "prestation",
        "prestations",
    ),
    "parc_machine_text": (
        "parc machine",
        "machine",
        "machines",
        "équipement",
        "equipement",
        "équipements",
        "equipements",
        "cnc",
        "atelier",
        "ligne de production",
        "usine",
        "robot",
        "robotique",
        "centre d'usinage",
        "usinage",
    ),
    "clients_markets_text": (
        "client",
        "clients",
        "marché",
        "marche",
        "marchés",
        "marches",
        "secteur",
        "secteurs",
        "application",
        "applications",
        "aéronautique",
        "aeronautique",
        "automobile",
        "défense",
        "defense",
        "médical",
        "medical",
        "agroalimentaire",
        "btp",
        "énergie",
        "energie",
    ),
    "certifications_text": (
        "certification",
        "certifié",
        "certifie",
        "certifiée",
        "certifiee",
        "iso",
        "norme",
        "normes",
        "qualité",
        "qualite",
        "en 9100",
        "iatf",
    ),
    "activities_main_text": (
        "activités principales",
        "activites principales",
        "activité principale",
        "activite principale",
        "principales activités",
        "principales activites",
        "spécialis",
        "specialis",
        "fabrication",
        "production",
        "conception",
    ),
    "activities_secondary_text": (
        "activités secondaires",
        "activites secondaires",
        "activité secondaire",
        "activite secondaire",
        "autres activités",
        "autres activites",
        "également",
        "egalement",
        "aussi",
    ),
    "kompass_products_services_text": (
        "produits et services",
        "produits/services",
        "produit",
        "service",
        "branche",
        "rubrique",
        "nomenclature",
        "producteur",
        "distributeur",
        "prestataire",
    ),
    "clients_identified_text": (
        "clients",
        "client",
        "références",
        "references",
        "ils nous font confiance",
        "partenaires",
        "donneurs d'ordre",
        "donneurs d ordres",
    ),
    "markets_text": (
        "marché",
        "marche",
        "marchés",
        "marches",
        "secteur",
        "secteurs",
        "application",
        "applications",
        "aéronautique",
        "aeronautique",
        "automobile",
        "défense",
        "defense",
        "médical",
        "medical",
        "agroalimentaire",
        "énergie",
        "energie",
        "btp",
        "machines agricoles",
        "industrie",
    ),
    "classifications_text": (
        "code naf",
        "code ape",
        "nace",
        "naics",
        "sic",
        "esic",
        "codification",
        "classification",
        "convention collective",
        "idcc",
    ),
}


@dataclass
class InputLink:
    input_id: str
    url: str
    company_hint: str = ""
    extra_urls: list[str] | None = None


@dataclass
class PageResult:
    input_id: str
    source_url: str
    url: str
    final_url: str
    domain: str
    status: str
    http_status: str
    robots_allowed: bool
    title: str
    meta_description: str
    text: str
    links: list[str]
    error: str
    fetched_at: str


def now_iso() -> str:
    """Retourne une date UTC lisible."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def clean_text(value: Any) -> str:
    """Nettoie un texte sans modifier son sens."""
    if value is None:
        return ""
    text = html.unescape(str(value)).replace("\xa0", " ").replace("\ufeff", " ")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def short_hash(value: str) -> str:
    """Calcule un identifiant court et stable."""
    return hashlib.sha1(value.encode("utf-8")).hexdigest()[:12]


def normalize_url(value: Any) -> str:
    """Normalise une URL web ou file://."""
    raw = clean_text(value)
    if not raw:
        return ""
    if raw.lower().startswith("file:///"):
        return raw
    if raw.lower().startswith("file://"):
        return "file:///" + raw[7:].lstrip("/")
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", raw):
        raw = "https://" + raw
    try:
        raw, _fragment = urldefrag(raw)
        parsed = urlparse(raw)
    except ValueError:
        return ""
    if parsed.scheme == "file":
        return raw
    scheme = (parsed.scheme or "https").lower()
    netloc = parsed.netloc.lower()
    if not netloc:
        return ""
    path = re.sub(r"/+", "/", parsed.path or "/")
    if path != "/":
        path = path.rstrip("/")
    return urlunparse((scheme, netloc, path, "", parsed.query, ""))


def domain_of(url: str) -> str:
    """Retourne le domaine, sans www."""
    parsed = urlparse(normalize_url(url))
    if parsed.scheme == "file":
        return "local_file"
    return parsed.netloc.lower().removeprefix("www.")


def origin_of(url: str) -> str:
    """Retourne l'origine scheme://host/."""
    parsed = urlparse(normalize_url(url))
    if parsed.scheme == "file":
        return ""
    return urlunparse((parsed.scheme, parsed.netloc, "/", "", "", ""))


def extension_of(url: str) -> str:
    """Retourne l'extension de chemin URL."""
    path = urlparse(url).path.lower()
    if "." not in path.rsplit("/", 1)[-1]:
        return ""
    return "." + path.rsplit(".", 1)[-1]


class VisibleTextParser(HTMLParser):
    """Extracteur HTML simple: titre, meta description, liens et texte visible."""

    def __init__(self, base_url: str) -> None:
        super().__init__(convert_charrefs=True)
        self.base_url = base_url
        self.skip_depth = 0
        self.in_title = False
        self.title_parts: list[str] = []
        self.text_parts: list[str] = []
        self.links: list[str] = []
        self.meta_description = ""

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        attrs_dict = {k.lower(): v for k, v in attrs if k}
        if tag in {"script", "style", "noscript", "svg", "canvas", "iframe"}:
            self.skip_depth += 1
        if tag == "title":
            self.in_title = True
        if tag == "a":
            href = attrs_dict.get("href")
            if href:
                self.links.append(urljoin(self.base_url, href))
        if tag == "meta":
            name = clean_text(attrs_dict.get("name", "")).lower()
            prop = clean_text(attrs_dict.get("property", "")).lower()
            if name == "description" or prop == "og:description":
                self.meta_description = clean_text(attrs_dict.get("content", ""))

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in {"script", "style", "noscript", "svg", "canvas", "iframe"}:
            self.skip_depth = max(0, self.skip_depth - 1)
        if tag == "title":
            self.in_title = False

    def handle_data(self, data: str) -> None:
        text = clean_text(data)
        if not text:
            return
        if self.in_title:
            self.title_parts.append(text)
        if self.skip_depth == 0:
            self.text_parts.append(text)

    @property
    def title(self) -> str:
        return clean_text(" ".join(self.title_parts))[:300]

    @property
    def visible_text(self) -> str:
        return clean_text(" ".join(self.text_parts))


class RobotsCache:
    """Cache robots.txt pour eviter de relire le meme fichier."""

    def __init__(self, timeout: int) -> None:
        self.timeout = timeout
        self.cache: dict[str, robotparser.RobotFileParser | None] = {}
        self.lock = Lock()

    def allowed(self, url: str) -> bool:
        normalized = normalize_url(url)
        parsed = urlparse(normalized)
        if parsed.scheme == "file":
            return True
        site_origin = origin_of(normalized)
        if not site_origin:
            return False
        with self.lock:
            if site_origin not in self.cache:
                parser = robotparser.RobotFileParser()
                parser.set_url(urljoin(site_origin, "robots.txt"))
                try:
                    req = Request(parser.url, headers={"User-Agent": USER_AGENT})
                    with urlopen(req, timeout=self.timeout) as response:
                        parser.parse(response.read().decode("utf-8", errors="ignore").splitlines())
                    self.cache[site_origin] = parser
                except Exception:
                    # Si robots.txt est inaccessible, on laisse passer mais on reste lent.
                    self.cache[site_origin] = None
            parser = self.cache[site_origin]
        if parser is None:
            return True
        return parser.can_fetch(USER_AGENT, normalized)


class DomainCadence:
    """Gestion simple du delai entre deux requetes sur le meme domaine."""

    def __init__(self, delay: float) -> None:
        self.delay = delay
        self.last_seen: dict[str, float] = defaultdict(float)
        self.lock = Lock()

    def wait(self, url: str) -> None:
        if self.delay <= 0:
            return
        dom = domain_of(url)
        with self.lock:
            elapsed = time.monotonic() - self.last_seen[dom]
            wait_time = max(0.0, self.delay - elapsed)
            if wait_time:
                time.sleep(wait_time)
            self.last_seen[dom] = time.monotonic()


def read_input(path: Path) -> list[InputLink]:
    """Lit CSV, TXT ou XLSX."""
    suffix = path.suffix.lower()
    if suffix == ".txt":
        links = []
        for index, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), start=1):
            url = clean_text(line)
            if url and not url.startswith("#"):
                links.append(InputLink(f"IN_{index:06d}", url, "", []))
        return links
    if suffix == ".csv":
        return read_input_csv(path)
    if suffix in {".xlsx", ".xlsm"}:
        return read_input_xlsx(path)
    raise ValueError(f"Format d'entree non supporte: {path.suffix}")


def url_field_candidates(fields: Iterable[str]) -> list[str]:
    """Retourne toutes les colonnes qui peuvent contenir un lien."""
    result = []
    for field in fields:
        key = clean_text(field).lower().replace("_", " ")
        if key in {"url", "lien", "link", "source url", "site web", "lien kompass"}:
            result.append(field)
    return result


def read_input_csv(path: Path) -> list[InputLink]:
    """Lit un CSV avec colonne url/lien/link/source_url."""
    links: list[InputLink] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        sample = handle.read(4096)
        handle.seek(0)
        has_header = csv.Sniffer().has_header(sample) if sample else True
        if has_header:
            reader = csv.DictReader(handle)
            fieldnames = [f or "" for f in (reader.fieldnames or [])]
            url_fields = url_field_candidates(fieldnames)
            url_field = url_fields[0] if url_fields else ""
            name_field = find_name_field(fieldnames)
            if not url_field:
                raise ValueError("Aucune colonne URL trouvee. Utilisez url, lien, link ou source_url.")
            for index, row in enumerate(reader, start=1):
                url = clean_text(row.get(url_field, ""))
                if not url:
                    continue
                input_id = clean_text(row.get("id", "")) or clean_text(row.get("id_ia", "")) or f"IN_{index:06d}"
                extra_urls = []
                for field in url_fields[1:]:
                    extra = normalize_url(row.get(field, ""))
                    if extra and extra != normalize_url(url):
                        extra_urls.append(extra)
                links.append(InputLink(input_id, url, clean_text(row.get(name_field, "")) if name_field else "", extra_urls))
        else:
            reader_plain = csv.reader(handle)
            for index, row in enumerate(reader_plain, start=1):
                if row and clean_text(row[0]):
                    links.append(InputLink(f"IN_{index:06d}", clean_text(row[0]), clean_text(row[1]) if len(row) > 1 else "", []))
    return links


def read_input_xlsx(path: Path) -> list[InputLink]:
    """Lit un fichier Excel avec openpyxl."""
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise RuntimeError("openpyxl est necessaire pour lire les fichiers Excel.") from exc
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb["Base"] if "Base" in wb.sheetnames else wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    headers = [clean_text(value) for value in rows[0]]
    url_indices = indices_of_fields(headers, ("url", "lien", "link", "source_url", "site web", "lien kompass"))
    url_index = url_indices[0] if url_indices else None
    name_index = index_of_field(headers, ("raison sociale", "company", "company_name", "entreprise", "nom"))
    if url_index is None:
        raise ValueError("Aucune colonne URL trouvee dans le fichier Excel.")
    links: list[InputLink] = []
    for index, row in enumerate(rows[1:], start=1):
        url = clean_text(row[url_index] if url_index < len(row) else "")
        if not url:
            continue
        name = clean_text(row[name_index] if name_index is not None and name_index < len(row) else "")
        extra_urls = []
        for extra_index in url_indices[1:]:
            extra = normalize_url(row[extra_index] if extra_index < len(row) else "")
            if extra and extra != normalize_url(url):
                extra_urls.append(extra)
        links.append(InputLink(f"IN_{index:06d}", url, name, extra_urls))
    return links


def find_url_field(fields: Iterable[str]) -> str:
    """Trouve la colonne URL dans des en-tetes CSV."""
    for field in fields:
        key = clean_text(field).lower().replace("_", " ")
        if key in {"url", "lien", "link", "source url", "site web", "lien kompass"}:
            return field
    return ""


def find_name_field(fields: Iterable[str]) -> str:
    """Trouve une colonne de nom d'entreprise si elle existe."""
    for field in fields:
        key = clean_text(field).lower().replace("_", " ")
        if key in {"raison sociale", "company", "company name", "entreprise", "nom"}:
            return field
    return ""


def index_of_field(fields: list[str], names: tuple[str, ...]) -> int | None:
    """Cherche un index dans des en-tetes."""
    normalized = [field.lower().replace("_", " ") for field in fields]
    for name in names:
        if name in normalized:
            return normalized.index(name)
    return None


def indices_of_fields(fields: list[str], names: tuple[str, ...]) -> list[int]:
    """Cherche tous les index compatibles avec des noms de colonnes."""
    normalized = [field.lower().replace("_", " ") for field in fields]
    result = []
    for index, field in enumerate(normalized):
        if field in names:
            result.append(index)
    return result


def decode_response(raw: bytes, headers: Message) -> str:
    """Decode une reponse HTTP."""
    content_type = headers.get_content_charset()
    encodings = [content_type, "utf-8", "latin-1"]
    for encoding in encodings:
        if not encoding:
            continue
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="ignore")


def fetch_html_http(url: str, timeout: int, cadence: DomainCadence) -> tuple[str, str, str, str]:
    """Telecharge une page HTML ou lit un fichier local file://."""
    normalized = normalize_url(url)
    parsed = urlparse(normalized)
    if parsed.scheme == "file":
        local_path = Path(unquote(parsed.path.lstrip("/")))
        if re.match(r"^[A-Za-z]:", str(local_path)):
            path = local_path
        else:
            path = Path(unquote(parsed.path))
        html_text = path.read_text(encoding="utf-8")
        return html_text, normalized, "200", ""
    cadence.wait(normalized)
    req = Request(
        normalized,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "fr-FR,fr;q=0.9,en;q=0.7",
        },
    )
    try:
        with urlopen(req, timeout=timeout) as response:
            raw = response.read()
            content_type = response.headers.get("Content-Type", "")
            if "text/html" not in content_type and "application/xhtml" not in content_type and len(raw) > 2_000_000:
                return "", response.geturl(), str(response.status), f"contenu_non_html:{content_type}"
            return decode_response(raw, response.headers), response.geturl(), str(response.status), ""
    except HTTPError as exc:
        return "", normalized, str(exc.code), f"HTTPError {exc.code}"
    except (URLError, TimeoutError, OSError) as exc:
        return "", normalized, "", f"{type(exc).__name__}: {exc}"


def fetch_html_drission(url: str, timeout: int, cadence: DomainCadence) -> tuple[str, str, str, str]:
    """Moteur optionnel pour pages JS, si DrissionPage est installe."""
    normalized = normalize_url(url)
    if urlparse(normalized).scheme == "file":
        return fetch_html_http(url, timeout, cadence)
    cadence.wait(normalized)
    try:
        from DrissionPage import ChromiumOptions, ChromiumPage
    except ImportError:
        return "", normalized, "", "DrissionPage non installe. Utilisez --engine http ou installez DrissionPage."
    page = None
    try:
        co = ChromiumOptions()
        co.headless(True)
        co.set_argument("--disable-gpu")
        co.set_argument("--no-sandbox")
        page = ChromiumPage(co)
        page.get(normalized, timeout=timeout)
        time.sleep(1.0)
        final_url = getattr(page, "url", normalized)
        html_text = getattr(page, "html", "") or ""
        if not html_text:
            return "", final_url, "", "page vide avec DrissionPage"
        return html_text, final_url, "200", ""
    except Exception as exc:  # noqa: BLE001
        return "", normalized, "", f"DrissionPageError: {exc}"
    finally:
        try:
            if page is not None:
                page.quit()
        except Exception:
            pass


def fetch_html(url: str, timeout: int, cadence: DomainCadence, engine: str) -> tuple[str, str, str, str]:
    """Choisit le moteur de collecte."""
    if engine == "drission":
        return fetch_html_drission(url, timeout, cadence)
    return fetch_html_http(url, timeout, cadence)


def looks_like_access_block(url: str, title: str, visible_text: str) -> str:
    """Detecte une page de blocage ou une fausse page vide."""
    lowered = clean_text(f"{title} {visible_text}").lower()
    dom = domain_of(url)
    if "kompass" not in dom:
        return ""
    patterns = [
        "captcha",
        "access denied",
        "accès refusé",
        "acces refuse",
        "problème d'accès",
        "probleme d'acces",
        "veuillez contacter kompass",
        "unusual traffic",
        "robot",
        "bot",
        "no data",
        "aucune donnée",
        "aucune donnee",
    ]
    for pattern in patterns:
        if pattern in lowered:
            return f"page_blocage_detectee:{pattern}"
    if len(visible_text) < 300:
        return "page_kompass_trop_courte_ou_vide"
    return ""


def parse_page(base_url: str, html_text: str) -> tuple[str, str, str, list[str]]:
    """Parse le HTML en titre, description, texte et liens."""
    parser = VisibleTextParser(base_url)
    parser.feed(html_text)
    return parser.title, parser.meta_description, parser.visible_text, parser.links


def is_internal_link(url: str, allowed_domain: str) -> bool:
    """Verifie si un lien reste dans le domaine autorise."""
    normalized = normalize_url(url)
    if not normalized:
        return False
    parsed = urlparse(normalized)
    if parsed.scheme not in {"http", "https"}:
        return False
    if extension_of(normalized) in IGNORED_EXTENSIONS:
        return False
    return domain_of(normalized) == allowed_domain


def link_score(url: str) -> int:
    """Score simple pour prioriser les pages utiles."""
    lowered = normalize_url(url).lower()
    score = 0
    for keyword in PAGE_KEYWORDS:
        if keyword in lowered:
            score += 5
    if "?" in lowered:
        score -= 2
    return score


def select_internal_links(links: list[str], allowed_domain: str, visited: set[str], limit: int) -> list[str]:
    """Selectionne quelques liens internes utiles."""
    candidates = []
    for link in links:
        normalized = normalize_url(link)
        if not normalized or normalized in visited:
            continue
        if not is_internal_link(normalized, allowed_domain):
            continue
        score = link_score(normalized)
        if score <= 0:
            continue
        candidates.append((score, normalized))
    candidates.sort(key=lambda item: (-item[0], len(item[1])))
    result = []
    seen = set()
    for _score, url in candidates:
        if url not in seen:
            seen.add(url)
            result.append(url)
        if len(result) >= limit:
            break
    return result


def collect_pages(link: InputLink, args: argparse.Namespace, robots: RobotsCache, cadence: DomainCadence) -> list[PageResult]:
    """Collecte la page de depart et quelques pages internes."""
    source_url = normalize_url(link.url)
    if not source_url:
        return [
            PageResult(
                input_id=link.input_id,
                source_url=link.url,
                url=link.url,
                final_url="",
                domain="",
                status="invalid_url",
                http_status="",
                robots_allowed=False,
                title="",
                meta_description="",
                text="",
                links=[],
                error="URL invalide",
                fetched_at=now_iso(),
            )
        ]
    seed_urls = [source_url]
    for extra in link.extra_urls or []:
        normalized_extra = normalize_url(extra)
        if normalized_extra and normalized_extra not in seed_urls:
            seed_urls.append(normalized_extra)
    queue: list[tuple[str, str]] = [(seed, domain_of(seed)) for seed in seed_urls]
    visited: set[str] = set()
    pages: list[PageResult] = []
    while queue and len(pages) < args.max_pages:
        current, allowed_domain = queue.pop(0)
        if current in visited:
            continue
        visited.add(current)
        is_kompass = "kompass" in domain_of(current)
        robots_allowed = robots.allowed(current)
        if not robots_allowed:
            reason = "robots.txt interdit la collecte"
            if args.kompass_authorized and is_kompass:
                reason = "robots.txt interdit la collecte; utiliser API/export/HTML local autorise pour Kompass page2"
            pages.append(
                PageResult(
                    link.input_id,
                    source_url,
                    current,
                    current,
                    domain_of(current),
                    "blocked_robots",
                    "",
                    False,
                    "",
                    "",
                    "",
                    [],
                    reason,
                    now_iso(),
                )
            )
            continue
        html_text, final_url, http_status, error = "", current, "", ""
        for attempt in range(1, args.retries + 2):
            html_text, final_url, http_status, error = fetch_html(current, args.timeout, cadence, args.engine)
            if html_text and not error:
                break
            time.sleep(min(5.0, attempt * 0.8))
        if error or not html_text:
            pages.append(
                PageResult(
                    link.input_id,
                    source_url,
                    current,
                    final_url or current,
                    domain_of(current),
                    "error",
                    http_status,
                    True,
                    "",
                    "",
                    "",
                    [],
                    error or "page vide",
                    now_iso(),
                )
            )
            continue
        title, meta_description, visible_text, links = parse_page(final_url or current, html_text)
        block_reason = looks_like_access_block(final_url or current, title, visible_text)
        if block_reason:
            pages.append(
                PageResult(
                    link.input_id,
                    source_url,
                    current,
                    final_url or current,
                    domain_of(final_url or current),
                    "blocked_access",
                    http_status,
                    robots_allowed,
                    title,
                    meta_description,
                    visible_text[: args.max_text_chars_page],
                    links,
                    block_reason,
                    now_iso(),
                )
            )
            continue
        pages.append(
            PageResult(
                link.input_id,
                source_url,
                current,
                final_url or current,
                domain_of(final_url or current),
                "ok",
                http_status,
                True,
                title,
                meta_description,
                visible_text[: args.max_text_chars_page],
                links,
                "",
                now_iso(),
            )
        )
        if domain_of(final_url or current) == allowed_domain and len(pages) < args.max_pages:
            room = args.max_pages - len(pages)
            queue.extend((url, allowed_domain) for url in select_internal_links(links, allowed_domain, visited, room * 2))
    return pages


def split_sentences(text: str) -> list[str]:
    """Decoupe un texte en phrases approximatives."""
    text = clean_text(text)
    if not text:
        return []
    parts = re.split(r"(?<=[.!?])\s+|\s+\|\s+|\n+", text)
    result = []
    for part in parts:
        part = clean_text(part)
        if len(part) >= 30:
            result.append(part)
    return result


def select_sentences(text: str, keywords: tuple[str, ...], max_chars: int = 1600) -> str:
    """Selectionne les phrases les plus utiles pour une rubrique."""
    sentences = split_sentences(text)
    scored: list[tuple[int, str]] = []
    for sentence in sentences:
        lowered = sentence.lower()
        score = sum(1 for keyword in keywords if keyword in lowered)
        if score:
            scored.append((score, sentence))
    scored.sort(key=lambda item: (-item[0], len(item[1])))
    selected = []
    used = 0
    seen = set()
    for _score, sentence in scored:
        key = re.sub(r"[^a-z0-9]+", " ", sentence.lower())[:180]
        if key in seen:
            continue
        seen.add(key)
        if used + len(sentence) > max_chars and selected:
            continue
        selected.append(sentence)
        used += len(sentence)
        if used >= max_chars:
            break
    return clean_text(" ".join(selected))[:max_chars]


def extract_siret(text: str) -> str:
    """Extrait un SIRET a 14 chiffres."""
    match = re.search(r"\b(?:SIRET\s*:?\s*)?((?:\d[\s.-]?){14})\b", text, flags=re.I)
    if not match:
        return ""
    value = re.sub(r"\D", "", match.group(1))
    return value if len(value) == 14 else ""


def extract_siren(text: str, siret: str = "") -> str:
    """Extrait un SIREN a 9 chiffres."""
    if siret:
        return siret[:9]
    match = re.search(r"\b(?:SIREN\s*:?\s*)?((?:\d[\s.-]?){9})\b", text, flags=re.I)
    if not match:
        return ""
    value = re.sub(r"\D", "", match.group(1))
    return value if len(value) == 9 else ""


def extract_naf(text: str) -> str:
    """Extrait un code NAF / APE."""
    patterns = [
        r"\b(?:NAF|APE|activité principale)\s*:?\s*([0-9]{2}\.[0-9]{2}[A-Z])\b",
        r"\b([0-9]{2}\.[0-9]{2}[A-Z])\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.I)
        if match:
            return match.group(1).upper()
    return ""


def extract_emails(text: str, site_domain: str) -> str:
    """Extrait les emails en filtrant les domaines peu utiles."""
    emails = sorted(set(re.findall(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", text, flags=re.I)))
    good = []
    for email in emails:
        dom = email.split("@", 1)[-1].lower()
        if dom in BAD_EMAIL_DOMAINS:
            continue
        good.append(email)
    good.sort(key=lambda email: 0 if site_domain and site_domain.endswith(email.split("@")[-1].lower()) else 1)
    return "; ".join(good[:8])


def extract_phones(text: str) -> str:
    """Extrait des numeros de telephone probables."""
    raw = re.findall(r"(?:\+33|0)\s?[1-9](?:[\s.-]?\d{2}){4}", text)
    phones = []
    for phone in raw:
        normalized = re.sub(r"\s+", " ", phone).strip()
        if normalized not in phones:
            phones.append(normalized)
    return "; ".join(phones[:8])


def extract_fax(text: str) -> str:
    """Extrait un fax si le libelle est visible."""
    candidates = []
    for match in re.finditer(r"\bFax\s*:?\s*((?:\+33|0)\s?[1-9](?:[\s.-]?\d{2}){4})", text, flags=re.I):
        value = clean_text(match.group(1))
        if value not in candidates:
            candidates.append(value)
    return "; ".join(candidates[:4])


def extract_capital(text: str) -> str:
    """Extrait le capital social si visible."""
    patterns = [
        r"\bcapital(?: social)?\s*:?\s*([0-9][0-9\s.,]*\s*(?:euros?|EUR|€))",
        r"\b([0-9][0-9\s.,]*\s*(?:euros?|EUR|€))\s+de capital",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.I)
        if match:
            return clean_text(match.group(1))
    return ""


def extract_effectifs(text: str) -> str:
    """Extrait une tranche ou mention d'effectifs."""
    patterns = [
        r"\b(?:effectifs?|salari[eé]s?)\s*:?\s*([0-9]{1,6}\s*(?:a|à|-)\s*[0-9]{1,6}\s*salari[eé]s?)",
        r"\b([0-9]{1,6}\s*(?:a|à|-)\s*[0-9]{1,6}\s*salari[eé]s?)\b",
        r"\b(?:effectifs?|salari[eé]s?)\s*:?\s*([0-9]{1,6})\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.I)
        if match:
            return clean_text(match.group(1)).replace(" - ", " à ")
    return ""


def extract_legal_form(text: str) -> str:
    """Extrait une forme juridique probable."""
    patterns = [
        (r"\bSASU\b|soci[eé]t[eé] par actions simplifi[eé]e unipersonnelle", "SASU"),
        (r"\bSAS\b|soci[eé]t[eé] par actions simplifi[eé]e", "SAS"),
        (r"\bSARL\b|soci[eé]t[eé] [aà] responsabilit[eé] limit[eé]e", "SARL"),
        (r"\bEURL\b", "EURL"),
        (r"\bSA\b|soci[eé]t[eé] anonyme", "SA"),
        (r"\bSCI\b|soci[eé]t[eé] civile immobili[eè]re", "SCI"),
        (r"entrepreneur individuel|entreprise individuelle", "Entrepreneur individuel"),
        (r"association loi 1901|association d[eé]clar[eé]e", "Association"),
    ]
    for pattern, label in patterns:
        if re.search(pattern, text, flags=re.I):
            return label
    return ""


def extract_role(text: str) -> str:
    """Extrait le role Kompass probable: producteur, distributeur, prestataire."""
    lowered = text.lower()
    roles = []
    for role, keywords in {
        "producteur": ("producteur", "fabricant", "fabrication", "production"),
        "distributeur": ("distributeur", "grossiste", "distribution"),
        "prestataire": ("prestataire", "services", "maintenance", "installation"),
        "importateur": ("importateur", "importation"),
        "exportateur": ("exportateur", "exportation"),
    }.items():
        if any(keyword in lowered for keyword in keywords):
            roles.append(role)
    return "; ".join(roles[:5])


def extract_website_links(text: str, links: list[str], current_domain: str) -> str:
    """Liste quelques liens web externes detectes."""
    urls = set(re.findall(r"https?://[^\s)\"']+", text))
    urls.update(links)
    result = []
    for url in urls:
        normalized = normalize_url(url)
        if not normalized:
            continue
        dom = domain_of(normalized)
        if dom and dom != current_domain and "kompass" not in dom:
            result.append(normalized)
    return "; ".join(sorted(set(result))[:8])


def page_type(url: str) -> str:
    """Typologie simple de source."""
    dom = domain_of(url)
    path = urlparse(normalize_url(url)).path.lower()
    if "kompass" in dom and "/c/" in path:
        return "kompass_detail"
    if "kompass" in dom:
        return "kompass_liste_ou_autre"
    if dom == "local_file":
        return "local_test"
    return "site_entreprise"


def extract_postal_city(text: str) -> tuple[str, str]:
    """Extrait code postal et ville si possible."""
    match = re.search(r"\b([0-9]{5})\s+([A-ZÀ-Ÿ][A-ZÀ-Ÿ' -]{2,45})\b", text)
    if match:
        return match.group(1), clean_text(match.group(2)).title()
    match = re.search(r"\b([0-9]{5})\b", text)
    return (match.group(1), "") if match else ("", "")


def extract_address(text: str) -> str:
    """Extrait une adresse probable."""
    sentences = split_sentences(text)
    for sentence in sentences:
        lowered = sentence.lower()
        if any(word in lowered for word in STREET_WORDS) and re.search(r"\b\d{5}\b", sentence):
            return sentence[:260]
    return ""


def guess_company_name(link: InputLink, title: str, domain_name: str) -> str:
    """Devine un nom d'entreprise sans inventer."""
    if link.company_hint:
        return link.company_hint
    title = clean_text(title)
    if title:
        for sep in (" | ", " - ", " – ", " — "):
            if sep in title:
                return clean_text(title.split(sep)[0])[:160]
        return title[:160]
    return domain_name


def build_company_record(link: InputLink, pages: list[PageResult]) -> dict[str, Any]:
    """Transforme les pages collectees en une ligne entreprise."""
    ok_pages = [page for page in pages if page.status == "ok"]
    first = ok_pages[0] if ok_pages else pages[0]
    full_text = "\n\n".join(
        f"SOURCE {page.final_url or page.url}: {page.title}. {page.meta_description}. {page.text}"
        for page in ok_pages
        if page.text
    )
    full_text = clean_text(full_text)
    siret = extract_siret(full_text)
    siren = extract_siren(full_text, siret)
    postal_code, city = extract_postal_city(full_text)
    domain_name = domain_of(first.final_url or first.url)
    all_links = []
    for page in ok_pages:
        all_links.extend(page.links)
    activity = select_sentences(full_text, SECTION_KEYWORDS["activity_text"])
    products = select_sentences(full_text, SECTION_KEYWORDS["products_services_text"])
    parc_machine = select_sentences(full_text, SECTION_KEYWORDS["parc_machine_text"])
    clients = select_sentences(full_text, SECTION_KEYWORDS["clients_identified_text"], max_chars=1200)
    markets = select_sentences(full_text, SECTION_KEYWORDS["markets_text"], max_chars=1200)
    certifications = select_sentences(full_text, SECTION_KEYWORDS["certifications_text"], max_chars=900)
    activities_main = select_sentences(full_text, SECTION_KEYWORDS["activities_main_text"], max_chars=1400)
    activities_secondary = select_sentences(full_text, SECTION_KEYWORDS["activities_secondary_text"], max_chars=1200)
    kompass_products = select_sentences(full_text, SECTION_KEYWORDS["kompass_products_services_text"], max_chars=1600)
    classifications = select_sentences(full_text, SECTION_KEYWORDS["classifications_text"], max_chars=1200)
    record = {
        "input_id": link.input_id,
        "source_url": normalize_url(link.url),
        "domain": domain_name,
        "source_page_type": page_type(first.final_url or first.url),
        "company_name": guess_company_name(link, first.title, domain_name),
        "page_title": first.title,
        "meta_description": first.meta_description,
        "company_description": clean_text(f"{first.meta_description}. {activity}")[:1800],
        "company_role": extract_role(full_text),
        "activity_text": activity,
        "activities_main_text": activities_main,
        "activities_secondary_text": activities_secondary,
        "products_services_text": products,
        "kompass_products_services_text": kompass_products,
        "parc_machine_text": parc_machine,
        "clients_identified_text": clients,
        "markets_text": markets,
        "clients_markets_text": clean_text(f"{clients} {markets}")[:1800],
        "certifications_text": certifications,
        "classifications_text": classifications,
        "siren": siren,
        "siret": siret,
        "naf_code": extract_naf(full_text),
        "legal_form": extract_legal_form(full_text),
        "effectifs": extract_effectifs(full_text),
        "capital": extract_capital(full_text),
        "address": extract_address(full_text),
        "postal_code": postal_code,
        "city": city,
        "emails": extract_emails(full_text, domain_name),
        "phones": extract_phones(full_text),
        "fax": extract_fax(full_text),
        "website_detected": extract_website_links(full_text, all_links, domain_name),
        "source_urls_collected": "; ".join(page.final_url or page.url for page in ok_pages),
        "detailed_business_text": clean_text(
            " ".join(
                value
                for value in [
                    activity,
                    activities_main,
                    activities_secondary,
                    products,
                    kompass_products,
                    parc_machine,
                    clients,
                    markets,
                    certifications,
                ]
                if value
            )
        )[:5000],
        "raw_text": full_text[:80_000],
        "raw_text_hash": hashlib.sha1(full_text.encode("utf-8")).hexdigest() if full_text else "",
        "scrape_status": "ok" if ok_pages else first.status,
        "http_status": first.http_status,
        "robots_allowed": int(any(page.robots_allowed for page in pages)),
        "error": "; ".join(page.error for page in pages if page.error)[:1000],
        "pages_ok": sum(1 for page in pages if page.status == "ok"),
        "pages_error": sum(1 for page in pages if page.status in {"error", "blocked_access"}),
        "pages_blocked_robots": sum(1 for page in pages if page.status == "blocked_robots"),
        "fetched_at": now_iso(),
    }
    if not record["activity_text"] and full_text:
        record["activity_text"] = full_text[:1000]
    if not record["company_description"]:
        record["company_description"] = record["activity_text"][:1200]
    return record


COMPANY_COLUMNS = [
    "input_id",
    "source_url",
    "domain",
    "source_page_type",
    "company_name",
    "page_title",
    "meta_description",
    "company_description",
    "company_role",
    "activity_text",
    "activities_main_text",
    "activities_secondary_text",
    "products_services_text",
    "kompass_products_services_text",
    "parc_machine_text",
    "clients_identified_text",
    "markets_text",
    "clients_markets_text",
    "certifications_text",
    "classifications_text",
    "siren",
    "siret",
    "naf_code",
    "legal_form",
    "effectifs",
    "capital",
    "address",
    "postal_code",
    "city",
    "emails",
    "phones",
    "fax",
    "website_detected",
    "source_urls_collected",
    "detailed_business_text",
    "raw_text",
    "raw_text_hash",
    "scrape_status",
    "http_status",
    "robots_allowed",
    "error",
    "pages_ok",
    "pages_error",
    "pages_blocked_robots",
    "fetched_at",
]

PAGE_COLUMNS = [
    "input_id",
    "source_url",
    "url",
    "final_url",
    "domain",
    "status",
    "http_status",
    "robots_allowed",
    "title",
    "meta_description",
    "text_length",
    "error",
    "fetched_at",
]


def connect_db(path: Path) -> sqlite3.Connection:
    """Ouvre SQLite avec quelques pragmas simples."""
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    init_db(conn)
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    """Cree les tables si elles n'existent pas."""
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS companies_raw (
            input_id TEXT PRIMARY KEY,
            source_url TEXT,
            domain TEXT,
            source_page_type TEXT,
            company_name TEXT,
            page_title TEXT,
            meta_description TEXT,
            company_description TEXT,
            company_role TEXT,
            activity_text TEXT,
            activities_main_text TEXT,
            activities_secondary_text TEXT,
            products_services_text TEXT,
            kompass_products_services_text TEXT,
            parc_machine_text TEXT,
            clients_identified_text TEXT,
            markets_text TEXT,
            clients_markets_text TEXT,
            certifications_text TEXT,
            classifications_text TEXT,
            siren TEXT,
            siret TEXT,
            naf_code TEXT,
            legal_form TEXT,
            effectifs TEXT,
            capital TEXT,
            address TEXT,
            postal_code TEXT,
            city TEXT,
            emails TEXT,
            phones TEXT,
            fax TEXT,
            website_detected TEXT,
            source_urls_collected TEXT,
            detailed_business_text TEXT,
            raw_text TEXT,
            raw_text_hash TEXT,
            scrape_status TEXT,
            http_status TEXT,
            robots_allowed INTEGER,
            error TEXT,
            pages_ok INTEGER,
            pages_error INTEGER,
            pages_blocked_robots INTEGER,
            fetched_at TEXT
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS pages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            input_id TEXT,
            source_url TEXT,
            url TEXT,
            final_url TEXT,
            domain TEXT,
            status TEXT,
            http_status TEXT,
            robots_allowed INTEGER,
            title TEXT,
            meta_description TEXT,
            text_length INTEGER,
            error TEXT,
            fetched_at TEXT
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS run_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT,
            input_id TEXT,
            message TEXT,
            created_at TEXT
        )
        """
    )
    conn.commit()
    migrate_company_columns(conn)


def migrate_company_columns(conn: sqlite3.Connection) -> None:
    """Ajoute les colonnes manquantes si une ancienne base existe deja."""
    existing = {row[1] for row in conn.execute("PRAGMA table_info(companies_raw)").fetchall()}
    definitions = {
        "source_page_type": "TEXT",
        "company_description": "TEXT",
        "company_role": "TEXT",
        "activities_main_text": "TEXT",
        "activities_secondary_text": "TEXT",
        "kompass_products_services_text": "TEXT",
        "clients_identified_text": "TEXT",
        "markets_text": "TEXT",
        "classifications_text": "TEXT",
        "legal_form": "TEXT",
        "effectifs": "TEXT",
        "capital": "TEXT",
        "fax": "TEXT",
        "website_detected": "TEXT",
        "detailed_business_text": "TEXT",
    }
    for column, definition in definitions.items():
        if column not in existing:
            conn.execute(f"ALTER TABLE companies_raw ADD COLUMN {column} {definition}")
    conn.commit()


def already_done(conn: sqlite3.Connection, input_id: str) -> bool:
    """Teste si une entree est deja traitee."""
    row = conn.execute("SELECT scrape_status FROM companies_raw WHERE input_id = ?", (input_id,)).fetchone()
    return bool(row and row[0] == "ok")


def save_company(conn: sqlite3.Connection, record: dict[str, Any]) -> None:
    """Insere ou remplace une entreprise."""
    placeholders = ", ".join("?" for _ in COMPANY_COLUMNS)
    columns = ", ".join(COMPANY_COLUMNS)
    updates = ", ".join(f"{col}=excluded.{col}" for col in COMPANY_COLUMNS if col != "input_id")
    conn.execute(
        f"INSERT INTO companies_raw ({columns}) VALUES ({placeholders}) "
        f"ON CONFLICT(input_id) DO UPDATE SET {updates}",
        [record.get(col, "") for col in COMPANY_COLUMNS],
    )


def save_pages(conn: sqlite3.Connection, pages: list[PageResult]) -> None:
    """Enregistre les traces pages."""
    for page in pages:
        conn.execute(
            f"INSERT INTO pages ({', '.join(PAGE_COLUMNS)}) VALUES ({', '.join('?' for _ in PAGE_COLUMNS)})",
            [
                page.input_id,
                page.source_url,
                page.url,
                page.final_url,
                page.domain,
                page.status,
                page.http_status,
                int(page.robots_allowed),
                page.title,
                page.meta_description,
                len(page.text),
                page.error,
                page.fetched_at,
            ],
        )


def log_event(conn: sqlite3.Connection, event_type: str, input_id: str, message: str) -> None:
    """Ajoute un evenement de run."""
    conn.execute(
        "INSERT INTO run_events(event_type, input_id, message, created_at) VALUES (?, ?, ?, ?)",
        (event_type, input_id, message, now_iso()),
    )


def export_csv(conn: sqlite3.Connection, out_dir: Path) -> None:
    """Exporte entreprises.csv et errors.csv."""
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = conn.execute(f"SELECT {', '.join(COMPANY_COLUMNS)} FROM companies_raw ORDER BY input_id").fetchall()
    with (out_dir / "entreprises.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(COMPANY_COLUMNS)
        writer.writerows(rows)
    with (out_dir / "errors.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["input_id", "source_url", "scrape_status", "http_status", "error", "pages_ok", "pages_error", "pages_blocked_robots"])
        for row in conn.execute(
            """
            SELECT input_id, source_url, scrape_status, http_status, error, pages_ok, pages_error, pages_blocked_robots
            FROM companies_raw
            WHERE scrape_status != 'ok' OR error != ''
            ORDER BY input_id
            """
        ):
            writer.writerow(row)


def export_excel(conn: sqlite3.Connection, out_dir: Path) -> str:
    """Exporte entreprises.xlsx si openpyxl est disponible."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill
    except ImportError:
        return "openpyxl_non_installe"
    wb = Workbook()
    ws = wb.active
    ws.title = "entreprises"
    excel_columns = [col for col in COMPANY_COLUMNS if col != "raw_text"] + ["raw_text_excerpt"]
    ws.append(excel_columns)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F4E79")
    for row in conn.execute(f"SELECT {', '.join(COMPANY_COLUMNS)} FROM companies_raw ORDER BY input_id"):
        data = dict(zip(COMPANY_COLUMNS, row))
        excel_row = [data.get(col, "") for col in excel_columns if col != "raw_text_excerpt"]
        excel_row.append(clean_text(data.get("raw_text", ""))[:5000])
        ws.append(excel_row)
    for column_cells in ws.columns:
        header = str(column_cells[0].value or "")
        width = min(max(len(header) + 2, 12), 45)
        ws.column_dimensions[column_cells[0].column_letter].width = width
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    wb.save(out_dir / "entreprises.xlsx")
    return "ok"


def write_report(conn: sqlite3.Connection, out_dir: Path, started_at: float, args: argparse.Namespace) -> None:
    """Ecrit un rapport Markdown de run."""
    total = conn.execute("SELECT COUNT(*) FROM companies_raw").fetchone()[0]
    ok = conn.execute("SELECT COUNT(*) FROM companies_raw WHERE scrape_status = 'ok'").fetchone()[0]
    errors = conn.execute("SELECT COUNT(*) FROM companies_raw WHERE scrape_status != 'ok'").fetchone()[0]
    blocked = conn.execute("SELECT COALESCE(SUM(pages_blocked_robots), 0) FROM companies_raw").fetchone()[0]
    pages_ok = conn.execute("SELECT COALESCE(SUM(pages_ok), 0) FROM companies_raw").fetchone()[0]
    elapsed = time.perf_counter() - started_at
    report = f"""# Rapport DATA Scraper MVP

Date generation: {now_iso()}

## Configuration

- Input: `{args.input}`
- Output: `{args.output}`
- SQLite: `{args.db_path}`
- Max pages par lien: {args.max_pages}
- Timeout: {args.timeout} s
- Delai par domaine: {args.delay} s
- Moteur: {args.engine}
- Workers: {args.workers}
- Retries: {args.retries}
- Kompass autorise: {args.kompass_authorized}
- Resume: {args.resume}

## Resultats

- Entreprises en base: {total}
- Statut ok: {ok}
- Statut erreur/bloque: {errors}
- Pages lues correctement: {pages_ok}
- Pages bloquees robots.txt: {blocked}
- Duree run: {round(elapsed, 2)} s

## Fichiers produits

- `entreprises.db`: base SQLite avec `companies_raw`, `pages`, `run_events`.
- `entreprises.csv`: export principal.
- `entreprises.xlsx`: export Excel si openpyxl est disponible.
- `errors.csv`: liens en erreur ou incomplets.
- `run_report.md`: ce rapport.

## Notes

- Le script respecte robots.txt et ne contourne pas les blocages.
- L'option `--kompass-authorized` doit etre utilisee uniquement si le client confirme disposer d'une autorisation explicite pour collecter les pages detail Kompass.
- Les champs activity/products/parc machine/clients/certifications sont extraits depuis le texte visible.
- Les champs clients et marches sont separes pour eviter de melanger noms de clients et domaines d'application.
- Les valeurs absentes du texte restent vides: le scraper ne les invente pas.
"""
    (out_dir / "run_report.md").write_text(report, encoding="utf-8")


def process_link(link: InputLink, args: argparse.Namespace, robots: RobotsCache, cadence: DomainCadence) -> tuple[InputLink, list[PageResult], dict[str, Any]]:
    """Traite un lien hors SQLite pour pouvoir paralleliser."""
    pages = collect_pages(link, args, robots, cadence)
    record = build_company_record(link, pages)
    return link, pages, record


def save_processed(conn: sqlite3.Connection, link: InputLink, pages: list[PageResult], record: dict[str, Any]) -> None:
    """Sauvegarde un resultat complet."""
    save_company(conn, record)
    save_pages(conn, pages)
    log_event(conn, record["scrape_status"], link.input_id, record.get("error", ""))
    conn.commit()


def run(args: argparse.Namespace) -> None:
    """Execute le pipeline."""
    started_at = time.perf_counter()
    links = read_input(args.input)
    if args.limit:
        links = links[args.start - 1 : args.start - 1 + args.limit]
    elif args.start > 1:
        links = links[args.start - 1 :]
    args.output.mkdir(parents=True, exist_ok=True)
    conn = connect_db(args.db_path)
    robots = RobotsCache(timeout=args.timeout)
    cadence = DomainCadence(delay=args.delay)
    log_event(conn, "start", "", json.dumps({"selected": len(links), "input": str(args.input)}, ensure_ascii=False))
    target_links = []
    for link in links:
        if args.resume and already_done(conn, link.input_id):
            print(json.dumps({"event": "skip", "input_id": link.input_id}, ensure_ascii=False))
            continue
        target_links.append(link)
    if args.workers <= 1:
        for index, link in enumerate(target_links, start=1):
            link, pages, record = process_link(link, args, robots, cadence)
            save_processed(conn, link, pages, record)
            if index == 1 or index % args.progress_every == 0:
                print(
                    json.dumps(
                        {
                            "event": "progress",
                            "done": index,
                            "selected": len(target_links),
                            "input_id": link.input_id,
                            "status": record["scrape_status"],
                            "pages_ok": record["pages_ok"],
                        },
                        ensure_ascii=False,
                    ),
                    flush=True,
                )
    else:
        done_count = 0
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            futures = [pool.submit(process_link, link, args, robots, cadence) for link in target_links]
            for future in as_completed(futures):
                link, pages, record = future.result()
                save_processed(conn, link, pages, record)
                done_count += 1
                if done_count == 1 or done_count % args.progress_every == 0:
                    print(
                        json.dumps(
                            {
                                "event": "progress",
                                "done": done_count,
                                "selected": len(target_links),
                                "input_id": link.input_id,
                                "status": record["scrape_status"],
                                "pages_ok": record["pages_ok"],
                            },
                            ensure_ascii=False,
                        ),
                        flush=True,
                    )
    export_csv(conn, args.output)
    excel_status = export_excel(conn, args.output)
    write_report(conn, args.output, started_at, args)
    log_event(conn, "done", "", json.dumps({"excel": excel_status}, ensure_ascii=False))
    conn.commit()
    conn.close()
    print(json.dumps({"event": "done", "output": str(args.output), "excel": excel_status}, ensure_ascii=False))


def parse_args() -> argparse.Namespace:
    """Arguments CLI."""
    parser = argparse.ArgumentParser(description="Scraper MVP G1/G2: liens -> SQLite + CSV + Excel.")
    parser.add_argument("--input", type=Path, required=True, help="CSV, TXT ou XLSX contenant les liens.")
    parser.add_argument("--output", type=Path, default=Path("output"), help="Dossier de sortie.")
    parser.add_argument("--db", type=Path, default=None, help="Chemin SQLite. Par defaut: output/entreprises.db")
    parser.add_argument("--max-pages", type=int, default=5, help="Nombre max de pages par lien.")
    parser.add_argument("--max-text-chars-page", type=int, default=25_000, help="Texte max conserve par page.")
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT)
    parser.add_argument("--delay", type=float, default=0.5, help="Delai minimal entre deux requetes meme domaine.")
    parser.add_argument("--engine", choices=["http", "drission"], default="http", help="Moteur de collecte: http ou DrissionPage.")
    parser.add_argument("--kompass-authorized", action="store_true", help="Active l'acces Kompass detail uniquement si une autorisation explicite existe.")
    parser.add_argument("--workers", type=int, default=1, help="Nombre de liens traites en parallele.")
    parser.add_argument("--retries", type=int, default=1, help="Nombre de nouvelles tentatives apres echec.")
    parser.add_argument("--start", type=int, default=1, help="Index 1-base dans le fichier d'entree.")
    parser.add_argument("--limit", type=int, default=None, help="Nombre de lignes a traiter.")
    parser.add_argument("--resume", action="store_true", help="Ignore les input_id deja traites avec statut ok.")
    parser.add_argument("--progress-every", type=int, default=10)
    args = parser.parse_args()
    args.input = args.input.resolve()
    args.output = args.output.resolve()
    args.db_path = (args.db.resolve() if args.db else args.output / "entreprises.db")
    return args


if __name__ == "__main__":
    run(parse_args())
