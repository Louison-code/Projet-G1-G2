# Guide complet du projet G1/G2

Ce guide est redige pour une personne qui decouvre le projet. Il explique le role de chaque fichier, la logique generale, l'installation et les commandes a lancer.

## 1. Objectif du projet

Ce projet est une chaine automatisee de collecte et d'analyse de donnees entreprises.

L'objectif est de:

1. Lire un fichier d'entree contenant des entreprises et des liens.
2. Collecter automatiquement les informations accessibles sur les pages web.
3. Extraire les informations administratives et metier.
4. Stocker les resultats dans une base SQL SQLite, un CSV et un Excel.
5. Envoyer automatiquement la base DATA vers le pipeline IA.
6. Utiliser un modele Mistral local pour enrichir les entreprises.
7. Produire un fichier final enrichi et une table de preuves.

Schema general:

```text
Fichier client
        ↓
Etape DATA: collecte, extraction, structuration
        ↓
entreprises.db
        ↓
Etape IA: lecture SQL, appel Mistral, enrichissement
        ↓
companies_enriched.xlsx / evidence.xlsx / ia_results.db
```

Ce n'est pas une application graphique. C'est un outil automatise en ligne de commande: une fois lance, il execute toute la chaine DATA + IA.

## 2. Structure generale du dossier

```text
Projet
├── Data
│   ├── input
│   │   └── liste URL_KOMPASS.xlsx
│   ├── samples
│   │   └── sample_company.html
│   ├── scraper_mvp.py
│   ├── config.json
│   ├── requirements.txt
│   ├── README.md
│   ├── README_CN.md
│   ├── BESOINS_CLIENT_COUVERTURE.md
│   └── BENCHMARK_PARALLELISATION.md
├── AI
│   ├── prompts
│   │   └── prompt_mistral.md
│   ├── schemas
│   │   └── schema_sortie_ia.json
│   ├── pipeline_ai_mistral.py
│   ├── requirements.txt
│   ├── README.md
│   └── README_CN.md
├── run_full_pipeline.py
├── run_full_pipeline.ps1
├── setup_environment.ps1
├── RUN_FULL_PIPELINE_README.md
├── GUIDE_COMPLET_CN.md
└── GUIDE_COMPLET_FR.md
```

## 3. Fichiers a la racine du projet

### `run_full_pipeline.py`

C'est le lanceur principal.

Il lance automatiquement:

1. `Data/scraper_mvp.py`
2. `AI/pipeline_ai_mistral.py`

Dans l'usage normal, il n'est donc pas necessaire de lancer manuellement les deux scripts separement. Le lanceur transmet automatiquement la base DATA a l'etape IA.

### `run_full_pipeline.ps1`

C'est un wrapper PowerShell pour Windows.

Il facilite le lancement du projet. S'il trouve un environnement virtuel `.venv`, il l'utilise. Sinon, il utilise le Python disponible sur la machine.

### `setup_environment.ps1`

C'est le script d'installation.

Lors de la premiere utilisation sur une machine, il faut le lancer pour:

1. Creer l'environnement virtuel `.venv`.
2. Installer les dependances DATA.
3. Installer les dependances IA.

L'environnement virtuel permet d'isoler les dependances du projet.

### `RUN_FULL_PIPELINE_README.md`

C'est une version courte des commandes de lancement.

### `GUIDE_COMPLET_CN.md`

Guide complet en chinois.

### `GUIDE_COMPLET_FR.md`

Guide complet en francais, c'est ce fichier.

## 4. Dossier Data

Le dossier `Data` correspond a la premiere etape: collecte et structuration des donnees.

### `Data/input/liste URL_KOMPASS.xlsx`

C'est le fichier d'entree client.

Il contient notamment:

- lien Kompass
- raison sociale
- localisation
- activite
- site web

Le pipeline lit ce fichier par defaut.

### `Data/scraper_mvp.py`

C'est le script principal de l'etape DATA.

Il sert a:

1. Lire un fichier Excel, CSV ou TXT.
2. Identifier les URL a traiter.
3. Visiter les pages accessibles.
4. Respecter les limitations d'acces et journaliser les blocages.
5. Extraire les informations utiles.
6. Construire une base SQLite.
7. Exporter les resultats en CSV et Excel.
8. Produire un rapport d'execution.

Champs typiquement extraits:

- nom de l'entreprise
- SIREN
- SIRET
- code NAF
- forme juridique
- effectifs
- adresse
- ville
- code postal
- emails
- telephones
- description de l'entreprise
- activite
- activites principales
- activites secondaires
- produits et services
- produits et services Kompass si disponibles
- parc machine
- clients
- marches
- certifications
- classifications
- texte metier exploitable par l'IA

### `Data/config.json`

Fichier de configuration reserve aux evolutions du projet.

Actuellement, les parametres importants sont surtout passes en ligne de commande.

### `Data/requirements.txt`

Liste des dependances Python de l'etape DATA.

Le script `setup_environment.ps1` l'utilise pour installer automatiquement les modules necessaires.

### `Data/README.md`

Documentation courte de l'etape DATA en francais.

### `Data/README_CN.md`

Documentation courte de l'etape DATA en chinois.

### `Data/BESOINS_CLIENT_COUVERTURE.md`

Document qui explique les besoins client et comment l'outil DATA y repond.

### `Data/BENCHMARK_PARALLELISATION.md`

Rapport de benchmark sur la parallelisation.

Nous avons teste 1, 4, 8 et 16 workers sur le meme echantillon de 100 entreprises.

Resultats:

- 1 worker: 420,09 secondes
- 4 workers: 165,53 secondes
- 8 workers: 125,54 secondes
- 16 workers: 130,85 secondes

Conclusion:

- 4 workers = mode prudent
- 8 workers = mode rapide recommande
- 16 workers = non recommande par defaut, car pas plus rapide sur le benchmark

### `Data/samples/sample_company.html`

Page HTML locale pour tester la logique d'extraction sans acceder a Internet.

## 5. Dossier AI

Le dossier `AI` correspond a la deuxieme etape: enrichissement par intelligence artificielle.

### `AI/pipeline_ai_mistral.py`

C'est le script principal de l'etape IA.

Il sert a:

1. Lire la base `entreprises.db` produite par DATA.
2. Construire un texte utile pour chaque entreprise.
3. Appeler le modele Mistral local via Ollama.
4. Recuperer une reponse JSON.
5. Normaliser la reponse.
6. Exporter les resultats en SQL, CSV et Excel.
7. Produire une table de preuves.
8. Produire un rapport de performance.

Champs produits par l'IA:

- `secteur_ia`
- `sous_secteur_ia`
- `domaine_production`
- `chaine_valeur`
- `produits_services`
- `technologies`
- `competences_cles`
- `parc_machine`
- `certifications_normes`
- `clients`
- `marches`
- `prix_produits`
- `potentiel_interet`
- `niveau_priorite`
- `confidence`
- `evidence_resume`

### `AI/prompts/prompt_mistral.md`

Prompt donne a Mistral.

Il definit:

- les champs attendus
- les regles de classification
- les interdictions
- la separation entre clients et marches
- la logique de confiance
- le format JSON obligatoire

### `AI/schemas/schema_sortie_ia.json`

Schema de sortie IA.

Il decrit les champs que le JSON final doit contenir.

### `AI/requirements.txt`

Dependances Python de l'etape IA.

### `AI/README.md`

Documentation courte de l'etape IA en francais.

### `AI/README_CN.md`

Documentation courte de l'etape IA en chinois.

## 6. Installation sur une nouvelle machine

### Etape 1: ouvrir PowerShell

Se placer dans le dossier du projet:

```powershell
cd C:\Users\Dou\Desktop\Projet
```

Adapter le chemin si le dossier est ailleurs.

### Etape 2: creer l'environnement Python

Lancer:

```powershell
powershell -ExecutionPolicy Bypass -File ".\setup_environment.ps1"
```

Ce script cree `.venv` puis installe les dependances.

## 7. Premier test sans Mistral

Avant de lancer un traitement complet, il faut verifier que la chaine fonctionne.

Commande:

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --limit 5 --ai-limit 5 --dry-run-ai --data-output ".\Data\output_test" --ai-output ".\AI\outputs_test" --overwrite-ai
```

Cette commande:

1. Traite seulement 5 entreprises.
2. Lance DATA.
3. Cree `Data/output_test/entreprises.db`.
4. Lance IA en mode dry-run.
5. Cree `AI/outputs_test`.

Le mode `dry-run` teste l'etape IA sans appeler Mistral.

## 8. Test court avec Mistral

Si Ollama est lance et que le modele `mistral:latest` est installe, il est possible de tester l'IA reelle.

Commande:

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --limit 10 --ai-limit 10 --data-output ".\Data\output_test_10" --ai-output ".\AI\outputs_test_10" --overwrite-ai
```

Cette commande collecte 10 entreprises puis demande a Mistral de les analyser.

## 9. Lancement complet

Commande recommandee pour traiter le fichier complet:

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --workers 8 --data-output ".\Data\output_7100" --ai-output ".\AI\outputs_7100" --overwrite-ai
```

Ce lancement:

1. Lit `Data/input/liste URL_KOMPASS.xlsx`.
2. Lance la collecte DATA avec 8 workers.
3. Cree `Data/output_7100`.
4. Transmet automatiquement `Data/output_7100/entreprises.db` a l'IA.
5. Cree `AI/outputs_7100`.

## 10. Parametres utiles

### `--input`

Fichier d'entree.

Exemple:

```powershell
--input ".\Data\input\nouveaux_liens.xlsx"
```

### `--data-output`

Dossier de sortie DATA.

Exemple:

```powershell
--data-output ".\Data\output_7100"
```

### `--ai-output`

Dossier de sortie IA.

Exemple:

```powershell
--ai-output ".\AI\outputs_7100"
```

### `--workers`

Nombre de traitements paralleles pour DATA.

Recommandation:

- 4 workers pour un mode prudent
- 8 workers pour un mode rapide

### `--limit`

Limite le nombre d'entreprises traitees par DATA.

Exemple:

```powershell
--limit 100
```

### `--ai-limit`

Limite le nombre d'entreprises traitees par l'IA.

Exemple:

```powershell
--ai-limit 20
```

### `--dry-run-ai`

Teste l'etape IA sans appeler Mistral.

### `--overwrite-ai`

Supprime les anciens resultats IA avant de regenerer les sorties.

## 11. Sorties de l'etape DATA

Si le dossier de sortie est `Data/output_7100`, les principaux fichiers sont:

### `entreprises.db`

Base SQLite de l'etape DATA.

C'est le fichier le plus important pour la suite, car l'IA le lit automatiquement.

### `entreprises.csv`

Export CSV principal.

### `entreprises.xlsx`

Export Excel principal.

### `errors.csv`

Fichier listant les erreurs, blocages et pages non exploitables.

### `run_report.md`

Rapport de run DATA.

Il resume:

- nombre d'entreprises traitees
- nombre de succes
- nombre de blocages
- nombre de pages lues
- duree du run

## 12. Sorties de l'etape IA

Si le dossier de sortie est `AI/outputs_7100`, les principaux fichiers sont:

### `ia_results.db`

Base SQLite IA.

Elle contient les tables:

- `companies_enriched`
- `evidence`
- `run_events`

### `companies_enriched.xlsx`

Fichier final enrichi.

Une entreprise par ligne.

### `companies_enriched.csv`

Version CSV du fichier final enrichi.

### `evidence.xlsx`

Table de preuves.

Elle explique sur quel texte l'IA s'appuie pour justifier ses decisions.

### `evidence.csv`

Version CSV de la table de preuves.

### `rapport_performance_ia.md`

Rapport de performance de l'etape IA.

## 13. Que signifie `blocked`

`blocked` signifie qu'une page n'a pas ete lue car l'acces automatique etait limite.

Dans ce projet, cela concerne souvent les pages detaillees Kompass.

Un blocage ne veut pas toujours dire que l'entreprise est totalement perdue:

- si Kompass est bloque mais que le site web de l'entreprise est accessible, l'entreprise peut quand meme etre traitee;
- si aucune source utile n'est accessible, l'entreprise restera pauvre en information.

L'outil ne contourne pas les limitations. Il les journalise.

## 14. Pourquoi utiliser SQL

La base SQLite permet de:

1. Structurer les donnees.
2. Garder une trace des pages lues.
3. Relier proprement DATA et IA.
4. Faciliter les traitements futurs.
5. Eviter de dependre uniquement d'un fichier Excel.

DATA produit `entreprises.db`.

IA lit `entreprises.db` puis produit `ia_results.db`.

## 15. Pourquoi c'est un outil automatise

L'utilisateur ne copie pas manuellement les fichiers entre DATA et IA.

Le lanceur:

1. lit l'entree;
2. lance la collecte;
3. cree la base DATA;
4. transmet la base a l'IA;
5. appelle Mistral;
6. exporte les fichiers finaux.

C'est donc un pipeline automatise en ligne de commande.

## 16. Utiliser un autre fichier d'entree

Placer le nouveau fichier dans:

```text
Data/input
```

Puis lancer:

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --input ".\Data\input\nouveaux_liens.xlsx" --data-output ".\Data\output_nouveau" --ai-output ".\AI\outputs_nouveau" --overwrite-ai
```

Il est recommande d'utiliser un dossier de sortie different pour chaque batch.

## 17. Problemes frequents

### `python` n'est pas reconnu

Python n'est pas installe ou n'est pas dans le PATH.

Installer Python puis relancer PowerShell.

### Module manquant, par exemple `openpyxl`

Les dependances ne sont pas installees.

Relancer:

```powershell
powershell -ExecutionPolicy Bypass -File ".\setup_environment.ps1"
```

### L'IA ne fonctionne pas

Verifier:

- Ollama est lance
- le modele `mistral:latest` est installe
- l'URL locale `http://127.0.0.1:11434` est accessible

Pour tester sans Mistral:

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --limit 5 --ai-limit 5 --dry-run-ai --overwrite-ai
```

### Certaines entreprises ont peu de donnees

Ca peut venir de:

- site web inaccessible
- timeout
- robots.txt
- texte insuffisant
- absence de site web dans le fichier client

Ces cas sont traces dans `errors.csv` et `run_report.md`.

### Le run est lent

Utiliser:

```powershell
--workers 8
```

Eviter de monter automatiquement au-dessus de 8 sans nouveau test.

## 18. Ordre conseille pour un nouvel utilisateur

Installation:

```powershell
cd C:\Users\Dou\Desktop\Projet
powershell -ExecutionPolicy Bypass -File ".\setup_environment.ps1"
```

Test sans IA reelle:

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --limit 5 --ai-limit 5 --dry-run-ai --data-output ".\Data\output_test" --ai-output ".\AI\outputs_test" --overwrite-ai
```

Test avec Mistral:

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --limit 10 --ai-limit 10 --data-output ".\Data\output_test_10" --ai-output ".\AI\outputs_test_10" --overwrite-ai
```

Run complet:

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --workers 8 --data-output ".\Data\output_7100" --ai-output ".\AI\outputs_7100" --overwrite-ai
```

## 19. Etat actuel du projet

Le projet contient:

- un pipeline DATA fonctionnel;
- un pipeline IA fonctionnel;
- un lanceur complet DATA + IA;
- un script d'installation;
- des prompts et schemas IA;
- une documentation bilingue;
- un benchmark de parallelisation.

Il reste a lancer le traitement complet sur tout le fichier client pour produire les resultats finaux complets.

En resume:

```text
L'outil est pret.
Les donnees finales completes seront produites apres lancement du pipeline complet.
```
