# Lancement en une commande

Ce script lance automatiquement les deux etapes:

1. DATA: scraping, extraction, base SQLite, CSV, Excel.
2. IA: lecture de la base SQLite, appel Mistral, resultats enrichis, preuves, base SQLite IA.

## Installation sur un autre ordinateur

Sur un autre ordinateur, il faut seulement Python et les dependances du projet.

Depuis le dossier `Projet`:

```powershell
powershell -ExecutionPolicy Bypass -File ".\setup_environment.ps1"
```

Ce script cree `.venv` et installe les dependances Python.

Selon la documentation officielle Python, `venv` cree un environnement virtuel isole pour le projet, ce qui evite de dependre de la configuration Python globale de la machine.

## Test rapide en Python pur

Depuis le dossier `Projet`:

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --limit 5 --ai-limit 5 --dry-run-ai --data-output ".\Data\output_pipeline_test" --ai-output ".\AI\outputs_pipeline_test" --overwrite-ai
```

## Test rapide avec le wrapper PowerShell

Depuis le dossier `Projet`:

```powershell
.\run_full_pipeline.ps1 -Limit 5 -AILimit 5 -DryRunAI -DataOutput ".\Data\output_pipeline_test" -AIOutput ".\AI\outputs_pipeline_test" -OverwriteAI
```

Ce test lance le scraping sur 5 entreprises et teste l'etape IA sans appeler Mistral. Le wrapper PowerShell utilise `.venv\Scripts\python.exe` si l'environnement virtuel existe, sinon il utilise `python`.

## Test avec Mistral local

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --limit 5 --ai-limit 5 --data-output ".\Data\output_pipeline_test_mistral" --ai-output ".\AI\outputs_pipeline_test_mistral" --overwrite-ai
```

Ollama doit etre lance et le modele `mistral:latest` doit etre disponible.

## Run complet recommande

```powershell
.\.venv\Scripts\python.exe .\run_full_pipeline.py --workers 8 --data-output ".\Data\output_7100" --ai-output ".\AI\outputs_7100" --overwrite-ai
```

## Parametres utiles

- `-Workers 8`: nombre de workers DATA. Le benchmark montre que 8 est le meilleur choix teste.
- `-Limit 100`: limite le nombre d'entreprises DATA pour un test.
- `-AILimit 100`: limite le nombre d'entreprises IA pour un test.
- `-DryRunAI`: teste l'etape IA sans appeler Mistral.
- `-OverwriteAI`: remplace les anciens resultats IA.

## Sorties

DATA:

- `Data/output_xxx/entreprises.db`
- `Data/output_xxx/entreprises.csv`
- `Data/output_xxx/entreprises.xlsx`
- `Data/output_xxx/errors.csv`
- `Data/output_xxx/run_report.md`

IA:

- `AI/outputs_xxx/ia_results.db`
- `AI/outputs_xxx/companies_enriched.csv`
- `AI/outputs_xxx/companies_enriched.xlsx`
- `AI/outputs_xxx/evidence.csv`
- `AI/outputs_xxx/evidence.xlsx`
- `AI/outputs_xxx/rapport_performance_ia.md`
