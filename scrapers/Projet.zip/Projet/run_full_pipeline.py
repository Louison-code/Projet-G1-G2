"""
Lanceur complet DATA + IA pour le projet G1/G2.

Ce script utilise l'interpreteur Python courant
pour lancer successivement:
1. Data/scraper_mvp.py
2. AI/pipeline_ai_mistral.py
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from datetime import datetime
from pathlib import Path


def project_root() -> Path:
    """Retourne le dossier Projet, c'est-a-dire le dossier du lanceur."""
    return Path(__file__).resolve().parent


def resolve_project_path(root: Path, value: str) -> Path:
    """Convertit un chemin relatif au projet en chemin absolu."""
    path = Path(value)
    if path.is_absolute():
        return path
    return (root / path).resolve()


def run_command(name: str, command: list[str], cwd: Path, log_path: Path) -> None:
    """Execute une commande en affichant et journalisant la sortie."""
    print()
    print(f"================ {name} ================")
    with log_path.open("a", encoding="utf-8") as log:
        log.write(f"\n================ {name} ================\n")
        log.write("Commande: " + " ".join(f'"{item}"' if " " in item else item for item in command) + "\n")
        process = subprocess.Popen(
            command,
            cwd=str(cwd),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="")
            log.write(line)
        return_code = process.wait()
        log.write(f"Code retour: {return_code}\n")
    if return_code != 0:
        raise RuntimeError(f"{name} a echoue avec le code {return_code}")


def parse_args() -> argparse.Namespace:
    """Parse les parametres du pipeline complet."""
    parser = argparse.ArgumentParser(description="Pipeline complet DATA + IA")
    parser.add_argument("--input", default=r"Data\input\liste URL_KOMPASS.xlsx", help="Fichier d'entree")
    parser.add_argument("--data-output", default=r"Data\output_full", help="Dossier de sortie DATA")
    parser.add_argument("--ai-output", default=r"AI\outputs_full", help="Dossier de sortie IA")
    parser.add_argument("--workers", type=int, default=8, help="Nombre de workers DATA")
    parser.add_argument("--max-pages", type=int, default=4, help="Pages maximum par entreprise")
    parser.add_argument("--timeout", type=int, default=12, help="Timeout HTTP DATA")
    parser.add_argument("--delay", type=float, default=0.5, help="Delai par domaine DATA")
    parser.add_argument("--limit", type=int, default=0, help="Limite DATA pour test")
    parser.add_argument("--ai-limit", type=int, default=0, help="Limite IA pour test")
    parser.add_argument("--dry-run-ai", action="store_true", help="Teste l'IA sans appeler Mistral")
    parser.add_argument("--overwrite-ai", action="store_true", help="Remplace les resultats IA existants")
    parser.add_argument("--python-exe", default=sys.executable, help="Interpreteur Python a utiliser")
    return parser.parse_args()


def main() -> int:
    """Point d'entree."""
    args = parse_args()
    root = project_root()
    logs_dir = root / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = logs_dir / f"run_full_pipeline_{stamp}.log"

    input_path = resolve_project_path(root, args.input)
    data_output = resolve_project_path(root, args.data_output)
    ai_output = resolve_project_path(root, args.ai_output)
    data_script = root / "Data" / "scraper_mvp.py"
    ai_script = root / "AI" / "pipeline_ai_mistral.py"
    data_db = data_output / "entreprises.db"
    python_exe = args.python_exe

    print("Projet G1/G2 - Pipeline complet DATA + IA")
    print(f"Racine projet: {root}")
    print(f"Python: {python_exe}")
    print(f"Input: {input_path}")
    print(f"Sortie DATA: {data_output}")
    print(f"Sortie IA: {ai_output}")
    print(f"Log: {log_path}")

    if not input_path.exists():
        raise FileNotFoundError(f"Fichier d'entree introuvable: {input_path}")
    if not data_script.exists():
        raise FileNotFoundError(f"Script DATA introuvable: {data_script}")
    if not ai_script.exists():
        raise FileNotFoundError(f"Script IA introuvable: {ai_script}")

    data_command = [
        python_exe,
        str(data_script),
        "--input",
        str(input_path),
        "--output",
        str(data_output),
        "--max-pages",
        str(args.max_pages),
        "--timeout",
        str(args.timeout),
        "--delay",
        str(args.delay),
        "--workers",
        str(args.workers),
        "--resume",
        "--progress-every",
        "10",
    ]
    if args.limit > 0:
        data_command.extend(["--limit", str(args.limit)])

    run_command("Etape DATA", data_command, root, log_path)

    if not data_db.exists():
        raise FileNotFoundError(f"La base DATA n'a pas ete produite: {data_db}")

    ai_command = [
        python_exe,
        str(ai_script),
        "--input",
        str(data_db),
        "--output",
        str(ai_output),
    ]
    if args.ai_limit > 0:
        ai_command.extend(["--limit", str(args.ai_limit)])
    if args.dry_run_ai:
        ai_command.append("--dry-run")
    if args.overwrite_ai:
        ai_command.append("--overwrite")

    run_command("Etape IA", ai_command, root, log_path)

    print()
    print("Pipeline termine avec succes.")
    print(f"Base DATA: {data_db}")
    print(f"Resultats IA: {ai_output}")
    print(f"Log: {log_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
