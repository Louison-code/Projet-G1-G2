param(
    [string]$PythonExe = "python"
)

$ErrorActionPreference = "Stop"
$ProjectRoot = $PSScriptRoot
$VenvDir = Join-Path $ProjectRoot ".venv"
$VenvPython = Join-Path $VenvDir "Scripts\python.exe"

Write-Host "Projet G1/G2 - installation environnement Python" -ForegroundColor Green
Write-Host "Racine projet: $ProjectRoot"

if (-not (Test-Path -LiteralPath $VenvPython)) {
    Write-Host "Creation de l'environnement virtuel .venv..."
    & $PythonExe -m venv $VenvDir
}

if (-not (Test-Path -LiteralPath $VenvPython)) {
    throw "Impossible de trouver le Python virtuel: $VenvPython"
}

Write-Host "Mise a jour de pip..."
& $VenvPython -m pip install --upgrade pip

Write-Host "Installation des dependances DATA..."
& $VenvPython -m pip install -r (Join-Path $ProjectRoot "Data\requirements.txt")

Write-Host "Installation des dependances IA..."
& $VenvPython -m pip install -r (Join-Path $ProjectRoot "AI\requirements.txt")

Write-Host ""
Write-Host "Installation terminee." -ForegroundColor Green
Write-Host "Python a utiliser: $VenvPython"
Write-Host "Exemple:"
Write-Host ".\.venv\Scripts\python.exe .\run_full_pipeline.py --limit 5 --ai-limit 5 --dry-run-ai --overwrite-ai"
